# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

class BillingDetail < ActiveRecord::Base
  include Redmine::SafeAttributes

  BILLING_TYPE_NOT_BILLABLE = 'not_billable'.freeze
  BILLING_TYPE_TIME_AND_MATERIALS = 'time_and_materials'.freeze
  BILLING_TYPE_PROJECT_FLAT_RATE = 'project_flat_rate'.freeze
  BILLING_TYPE_ISSUE_FLAT_RATE = 'issue_flat_rate'.freeze
    
  BILLING_TYPES = [
    BILLING_TYPE_NOT_BILLABLE,
    BILLING_TYPE_TIME_AND_MATERIALS,
    BILLING_TYPE_PROJECT_FLAT_RATE,
    BILLING_TYPE_ISSUE_FLAT_RATE
  ].freeze

  BILL_RATE_BY_USER = 'by_user'.freeze
  BILL_RATE_BY_PROJECT = 'by_project'.freeze
  BILL_RATE_BY_ISSUE = 'by_issue'.freeze
  BILL_RATE_BY_COMPANY = 'by_company'.freeze

  BILL_RATE_TYPES = [
    BILL_RATE_BY_PROJECT,
    BILL_RATE_BY_USER,
    BILL_RATE_BY_ISSUE,
    BILL_RATE_BY_COMPANY
  ].freeze

  BUDGET_TYPE_NO_BUDGET = 'no_budget'.freeze
  BUDGET_TYPE_PROJECT_FEE = 'project_fee'.freeze
  BUDGET_TYPE_ISSUES_FEE = 'issues_fee'.freeze
  BUDGET_TYPE_PROJECT_TIME = 'project_time'.freeze
  BUDGET_TYPE_ISSUES_TIME = 'issues_time'.freeze

  BUDGET_TYPES = [
    BUDGET_TYPE_NO_BUDGET,
    BUDGET_TYPE_PROJECT_FEE,
    BUDGET_TYPE_ISSUES_FEE,
    BUDGET_TYPE_PROJECT_TIME,
    BUDGET_TYPE_ISSUES_TIME
  ].freeze

  BUDGET_TYPES_WITH_DELIMITER = [
    BUDGET_TYPE_NO_BUDGET,
    :delimiter,
    BUDGET_TYPE_PROJECT_FEE,
    BUDGET_TYPE_ISSUES_FEE,
    :delimiter,
    BUDGET_TYPE_PROJECT_TIME,
    BUDGET_TYPE_ISSUES_TIME
  ].freeze

  BILLING_SETTINGS_ATTRIBUTES = (BillingSettingsAttributes::PROJECT_SETTINGS_ATTRIBUTES + BillingSettingsAttributes::ISSUE_SETTINGS_ATTRIBUTES).uniq.freeze

  belongs_to :billable, polymorphic: true
  has_many :expense_issue_links
  has_many :expenses, through: :expense_issue_links

  Rails.version > '7.0' ? serialize(:settings, type: Hash) : serialize(:settings, Hash)

  # Define getters
  BILLING_SETTINGS_ATTRIBUTES.each do |name|
    define_method("#{name}") { settings[name] }
  end

  # Define setters
  BILLING_SETTINGS_ATTRIBUTES.each do |name|
    define_method("#{name}=") do |val|
      settings[name] = val
    end
  end

  # Validations for issue billing settings
  validates :budget, presence: true, numericality: true,
            if: ->(x) { x.issue_settings? && x.billable.allowed_to_edit?(:budget) }

  validates :bill_rate, numericality: true, allow_blank: true, if: ->(x) { x.issue_settings? }

  validates :issue_cost, presence: true, numericality: true,
            if: ->(x) { x.issue_settings? && x.billable.allowed_to_edit?(:issue_cost) }

  # Validations for project billing settings
  validates :project_cost, presence: true, numericality: true,
            if: ->(x) { x.project_settings? && x.billable.allowed_to_edit?(:project_cost) }

  validates :bill_rate, numericality: true,
            if: ->(x) { x.project_settings? && x.billable.allowed_to_edit?(:bill_rate) }

  validates :budget, presence: true, numericality: true,
            if: ->(x) { x.project_settings? && x.fixed_budget_settings? }

  validate :validate_attribute_values, if: ->(x) { x.project_settings? }

  before_save :convert_numerical_attributes_to_f

  BILLING_SETTINGS_ATTRIBUTES.each do |attr|
    safe_attributes attr.to_s, if: ->(x, _user) { x.billable.allowed_attribute?(attr) }
  end

  def project_settings?
    billable_type == 'Project'
  end

  def issue_settings?
    billable_type == 'Issue'
  end

  def fixed_budget_settings?
    budget_type == BUDGET_TYPE_PROJECT_FEE || budget_type == BUDGET_TYPE_PROJECT_TIME
  end

  def nullify_billing_settings_extra_attributes
    if billing_type != BILLING_TYPE_PROJECT_FLAT_RATE && project_cost
      settings.delete(:project_cost)
    end

    if billing_type != BILLING_TYPE_ISSUE_FLAT_RATE && issue_cost
      settings.delete(:issue_cost)
    end

    if billing_type != BILLING_TYPE_TIME_AND_MATERIALS && bill_rate_type
      settings.delete(:bill_rate_type)
    end

    if bill_rate_type != BILL_RATE_BY_PROJECT && bill_rate
      settings.delete(:bill_rate)
    end

    unless fixed_budget_settings?
      settings.delete(:budget) if budget
      settings.delete(:monthly_budget) if monthly_budget
    end
  end
  def assign_issue_expenses(expenses_ids = [])
    return unless RedmineBudgets.contacts_invoices_pro_plugin_installed?

    self.expenses = Expense.where(id: expenses_ids)
  end

  private

  def convert_numerical_attributes_to_f
    [:project_cost, :issue_cost, :budget, :bill_rate].each do |attr|
      settings[attr] = settings[attr].to_f if settings[attr].present?
    end
  end

  def valid_budget_type_values
    @valid_budget_type_values ||=
      if billing_type == BILLING_TYPE_NOT_BILLABLE
        [BUDGET_TYPE_NO_BUDGET, BUDGET_TYPE_PROJECT_TIME, BUDGET_TYPE_ISSUES_TIME]
      else
        BUDGET_TYPES
      end
  end

  def validate_attribute_values
    if billing_type && BILLING_TYPES.exclude?(billing_type)
      errors.add(:billable_type, :inclusion)
    end

    if bill_rate_type && BILL_RATE_TYPES.exclude?(bill_rate_type)
      errors.add(:bill_rate_type, :inclusion)
    end

    if budget_type && valid_budget_type_values.exclude?(budget_type)
      errors.add(:budget_type, :inclusion)
    end
  end
end
