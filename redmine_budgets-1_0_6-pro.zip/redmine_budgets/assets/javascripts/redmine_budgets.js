function toggleBlockGroup(groupName, value) {
  $('.' + groupName).hide();
  $('.' + groupName + '.' + value).show();
};

function toggleProjectCostInfo(billingType, budgetType) {
  if ($('#billing_settings_billing_type').val() === billingType &&
      $('#billing_settings_budget_type').val() === budgetType)
  {
    $('#project-cost').hide();
    $('#project-cost-info').show();
  } else {
    $('#project-cost-info').hide();
    $('#project-cost').show();
  }
};

function toggleBudgetTypeOptions(display, optionValues) {
  if (display) {
    $.each(optionValues, function (index, value) {
      $("#billing_settings_budget_type [value=" + value + "]").prop('disabled', false);
    });
  } else {
    $.each(optionValues, function (index, value) {
      var $option = $("#billing_settings_budget_type [value=" + value + "]");
      $option.prop('disabled', true);
      if ($option.is(':selected')) {
        $('#billing_settings_budget_type :first').attr('selected', 'selected').trigger('change');
      }
    });
  }
};
