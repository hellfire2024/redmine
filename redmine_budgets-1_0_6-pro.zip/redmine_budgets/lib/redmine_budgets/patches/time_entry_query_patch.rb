# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require_dependency 'time_entry_query'

module RedmineBudgets
  module Patches
    module TimeEntryQueryPatch
      def self.included(base)
        base.class_eval do
          include RedmineBudgets::Utils::UserRatesCalculation
          include InstanceMethods

          alias_method :initialize_without_budgets, :initialize
          alias_method :initialize, :initialize_with_budgets

          alias_method :available_columns_without_budgets, :available_columns
          alias_method :available_columns, :available_columns_with_budgets

          alias_method :initialize_available_filters_without_budgets, :initialize_available_filters
          alias_method :initialize_available_filters, :initialize_available_filters_with_budgets
        end
      end

      class QueryCostsColumn < QueryColumn
        include RedmineBudgets::Utils::UserRatesCalculation

        def value_object(object)
          if User.current.allowed_to?(:view_costs, object.project)
            time_entry_costs object
          else
            l(:label_hidden)
          end
        end
      end

      module InstanceMethods
        def initialize_with_budgets(attributes = nil, *args)
          initialize_without_budgets(attributes, args)

          available_columns.each do |column|
            column.cost_rates_by_user_id = nil if column.is_a?(QueryCostsColumn)
          end
        end

        def available_columns_with_budgets
          return @available_columns if @available_columns

          @available_columns = available_columns_without_budgets
          if User.current.allowed_to?(:view_costs, project, global: true)
            @available_columns << QueryCostsColumn.new(:costs, totalable: true)
          end

          @available_columns
        end

        def initialize_available_filters_with_budgets
          initialize_available_filters_without_budgets
          add_available_filter 'costs', type: :float
          add_available_filter(
              "billable",
              :name => l(:label_budgets_billable),
              :type => :list,
              :values => [[l(:general_text_Yes), '1'], [l(:general_text_No), '0']]
          )
        end

        def sql_for_costs_field(field, operator, value)
          @sql_for_costs_field ||= begin
            filtered_time_entries = TimeEntry.all.select do |time_entry|
              available_by_costs_filter?(time_entry, operator, value)
            end

            if filtered_time_entries.any?
              "(#{TimeEntry.table_name}.id IN (#{filtered_time_entries.map(&:id).join(',')}))"
            else
              '1=0'
            end
          end
        end
        def sql_for_billable_field(field, operator, value)
          if value.first == '1'

            issue_ids = Issue.by_project(project)
                            .eager_load(:billing_detail)
                            .where
                            .not(id: BillingDetail
                                         .where(:settings => [:billing_type => "not_billable"]).pluck(:billable_id)).pluck(:id)

            time_entries_ids = TimeEntry.where(issue_id: issue_ids).pluck(:id).join(',')
          else
            issue_ids = Issue.by_project(project)
                            .eager_load(:billing_detail)
                            .where(id: BillingDetail
                                         .where(:settings => [:billing_type => "not_billable"]).pluck(:billable_id)).pluck(:id)

            time_entries_ids = TimeEntry.where(issue_id: issue_ids).pluck(:id).join(',')
          end

          if operator == '='
            time_entries_ids.blank? ? '1=0' : "#{TimeEntry.table_name}.id IN (#{time_entries_ids})"
          elsif operator == '!'
            time_entries_ids.blank? ? '1=0' : "#{TimeEntry.table_name}.id NOT IN (#{time_entries_ids})"
          end
        end

        def total_for_costs(scope)
          total =
            if scope.group_values.any?
              base_scope
                .joins(joins_for_order_statement(group_by_statement))
                .to_a
                .group_by(&group_by.to_sym)
                .inject({}) { |h, (group, time_entries)| h[group] = costs_sum(time_entries); h }
            else
              costs_sum(scope.to_a)
            end

          map_total(total) { |t| t.to_f.round(2) }
        end

        private

        # May return true, false or nil
        def available_by_costs_filter?(time_entry, operator, value)
          cost = time_entry_costs(time_entry)
          case operator
          when '='
            cost && cost == value.first.to_f
          when '>='
            cost && cost >= value.first.to_f
          when '<='
            cost && cost <= value.first.to_f
          when '><'
            cost && (cost >= value.first.to_f && cost <= value.second.to_f)
          when '!*'
            cost.blank?
          when '*'
            cost.present?
          end
        end

        def costs_sum(time_entries)
          time_entries.sum { |x| time_entry_costs(x) }
        end
      end
    end
  end
end

unless TimeEntryQuery.included_modules.include?(RedmineBudgets::Patches::TimeEntryQueryPatch)
  TimeEntryQuery.send(:include, RedmineBudgets::Patches::TimeEntryQueryPatch)
end
