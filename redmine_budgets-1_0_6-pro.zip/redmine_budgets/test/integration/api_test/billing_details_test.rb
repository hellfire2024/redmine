# encoding: utf-8
#
# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../../test_helper', __FILE__)

class Redmine::ApiTest::BillingDetailsTest < ActiveRecord::VERSION::MAJOR >= 4 ? Redmine::ApiTest::Base : ActionController::IntegrationTest

  fixtures :projects,
           :users,
           :roles,
           :members,
           :member_roles,
           :issues,
           :issue_statuses,
           :versions,
           :trackers,
           :projects_trackers,
           :issue_categories,
           :enabled_modules,
           :enumerations,
           :attachments,
           :workflows,
           :custom_fields,
           :custom_values,
           :custom_fields_projects,
           :custom_fields_trackers,
           :time_entries,
           :journals,
           :journal_details,
           :queries

  create_fixtures(Redmine::Plugin.find(:redmine_budgets).directory + '/test/fixtures/', [:billing_details])

  def setup
    @issue = Issue.find(1)
    @new_issue = Issue.find(2)
    @project = Project.find(1)
    @new_project = Project.find(2)
    Setting.rest_api_enabled = '1'
  end

  # === Getting Project BillingDetail ===

  test "GET /projects/:project_id/billing_details/:id.xml should return billing_details of the project" do
    compatible_api_request :get, "/projects/#{@project.id}/billing_details/1", { format: 'xml' }, credentials('admin')
    assert_response :success
    assert_match /application\/(x-)*xml/, @response.content_type
    assert_select 'id'
    assert_select 'billable_type', 'Project'
  end

  test "GET /projects/:project_id/billing_details/:id.json should return billing_details of the project" do
    compatible_api_request :get, "/projects/#{@project.id}/billing_details/1", { format: 'json' }, credentials('admin')
    assert_response :success
    json = ActiveSupport::JSON.decode(response.body)
    assert_match /application\/json/, @response.content_type
    assert json['billing_detail']['id']
    assert_equal json['billing_detail']['billable_type'], 'Project'
  end

  # === Getting Issue BillingDetail ===

  test "GET /issues/:issues_id/billing_details/:id.xml should return billing_detail of the issues" do
    compatible_api_request :get, "/issues/#{@issue.id}/billing_details/2", { format: 'xml' }, credentials('admin')
    assert_response :success
    assert_match /application\/(x-)*xml/, @response.content_type
    assert_select 'id'
    assert_select 'billable_type', 'Issue'
  end

  test "GET /issues/:issues_id/billing_details/:id.json should return billing_detail of the issues" do
    compatible_api_request :get, "/issues/#{@issue.id}/billing_details/2", { format: 'json' }, credentials('admin')
    assert_response :success
    json = ActiveSupport::JSON.decode(response.body)
    assert_match /application\/json/, @response.content_type
    assert json['billing_detail']['id']
    assert_equal json['billing_detail']['billable_type'], 'Issue'
  end

  # === Creating Project BillingDetail ===

  test "POST /projects/:project_id/billing_details.xml should create a billing_detail" do
    payload = {
        :billing_settings => {
            :billing_type => "#{BillingDetail::BILLING_TYPE_NOT_BILLABLE}"
        }
    }

    assert_difference('BillingDetail.count') do
      compatible_api_request :post, "/projects/#{@new_project.id}/billing_details.xml", payload, credentials('admin')
    end
    assert_response :success

    billing_detail = BillingDetail.last
    assert_equal BillingDetail::BILLING_TYPE_NOT_BILLABLE, billing_detail.billing_type
  end

  test "POST /projects/:project_id/billing_details.json should create a billing_detail" do
    payload = {
        :billing_settings => {
            :billing_type => "#{BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS}",
            :project_cost => '',
            :bill_rate_type => "#{BillingDetail::BILL_RATE_BY_USER}",
            :bill_rate => '',
            :budget_type => "#{BillingDetail::BUDGET_TYPE_PROJECT_FEE}",
            :budget => '2500.0',
            :monthly_budget => '1'
        }
    }

    assert_difference('BillingDetail.count') do
      compatible_api_request :post, "/projects/#{@new_project.id}/billing_details.json", payload, credentials('admin')
    end
    assert_response :success

    billing_detail = BillingDetail.last
    assert billing_detail.project_settings?
    assert_equal BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS, billing_detail.billing_type
    assert_nil billing_detail.project_cost
    assert_equal BillingDetail::BILL_RATE_BY_USER, billing_detail.bill_rate_type
    assert_equal BillingDetail::BUDGET_TYPE_PROJECT_FEE, billing_detail.budget_type
    assert_equal 2500.0, billing_detail.budget
    assert_equal '1', billing_detail.monthly_budget
  end

  # === Creating Issue BillingDetail ===

  test "POST /issues/:issue_id/billing_details.xml should create a billing_detail" do
    assert_difference('BillingDetail.count') do
      compatible_api_request :post, "/issues/#{@new_issue.id}/billing_details.xml", {}, credentials('admin')
    end
    assert_response :success

    billing_detail = BillingDetail.last
    assert billing_detail.issue_settings?
    assert_equal BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS, billing_detail.billing_type
  end

  test "POST /issues/:issue_id/billing_details.json should create a billing_detail" do
    assert_difference('BillingDetail.count') do
      compatible_api_request :post, "/issues/#{@new_issue.id}/billing_details.json", {}, credentials('admin')
    end
    assert_response :success

    billing_detail = BillingDetail.last
    assert_equal BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS, billing_detail.billing_type

    assert billing_detail.issue_settings?
  end

  # === Updating Project BillingDetail ===

  test "PUT /projects/:project_id/billing_details.xml should update a billing_detail" do
    old_billing_detail = BillingDetail.find(1)

    compatible_api_request :put, "/projects/#{@project.id}/billing_details/1.xml", {}, credentials('admin')
    assert_response :success

    updated_billing_detail = BillingDetail.find(1)

    assert_equal old_billing_detail.id, updated_billing_detail.id
    assert_equal BillingDetail::BILLING_TYPE_NOT_BILLABLE, updated_billing_detail.billing_type
  end

  test "PUT /projects/:project_id/billing_details.json should update a billing_detail" do
    old_billing_detail = BillingDetail.find(1)

    compatible_api_request :put, "/projects/#{@project.id}/billing_details/1.json", {}, credentials('admin')
    assert_response :success

    updated_billing_detail = BillingDetail.find(1)

    assert_equal old_billing_detail.id, updated_billing_detail.id
    assert_equal BillingDetail::BILLING_TYPE_NOT_BILLABLE, updated_billing_detail.billing_type
  end

  # === Updating Issue BillingDetail ===

  test "PUT /issues/:issue_id/billing_details.xml should update a billing_detail" do
    old_billing_detail = BillingDetail.find(2)

    compatible_api_request :put, "/issues/#{@issue.id}/billing_details/2.xml", {}, credentials('admin')
    assert_response :success

    updated_billing_detail = BillingDetail.find(2)

    assert_equal old_billing_detail.id, updated_billing_detail.id
    assert_equal BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS, updated_billing_detail.billing_type
  end

  test "PUT /issues/:issue_id/billing_details.json should update a billing_detail" do
    old_billing_detail = BillingDetail.find(2)

    compatible_api_request :put, "/issues/#{@issue.id}/billing_details/2.json", {}, credentials('admin')
    assert_response :success

    updated_billing_detail = BillingDetail.find(2)

    assert_equal old_billing_detail.id, updated_billing_detail.id
    assert_equal BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS, updated_billing_detail.billing_type
  end

  # === Deleting Project BillingDetail ===

  test "DELETE /projects/:id/billing_details/:id.xml" do
    assert_difference('BillingDetail.count', -1) do
      compatible_api_request :delete, "/projects/#{@project.id}/billing_details/1", { format: 'xml' }, credentials('admin')
      assert_response :success
      assert %w[200 204].include?(response.code)
      assert_equal '', response.body
    end
    assert_nil BillingDetail.find_by_id(1)
  end

  test "DELETE /projects/:id/billing_details/:id.json" do
    assert_difference('BillingDetail.count', -1) do
      compatible_api_request :delete, "/projects/#{@project.id}/billing_details/1", { format: 'json' }, credentials('admin')
      assert_response :success
      assert %w[200 204].include?(response.code)
      assert_equal '', response.body
    end
    assert_nil BillingDetail.find_by_id(1)
  end

  # === Deleting Issue BillingDetail ===

  test "DELETE /issues/:id/billing_details/:id.xml" do
    assert_difference('BillingDetail.count', -1) do
      compatible_api_request :delete, "/issues/#{@issue.id}/billing_details/2", { format: 'xml' }, credentials('admin')
      assert_response :success
      assert %w[200 204].include?(response.code)
      assert_equal '', response.body
    end
    assert_nil BillingDetail.find_by_id(2)
  end

  test "DELETE /issues/:id/billing_details/:id.json" do
    assert_difference('BillingDetail.count', -1) do
      compatible_api_request :delete, "/issues/#{@issue.id}/billing_details/2", { format: 'json' }, credentials('admin')
      assert_response :success
      assert %w[200 204].include?(response.code)
      assert_equal '', response.body
    end
    assert_nil BillingDetail.find_by_id(2)
  end

  # === Handling Exceptions ===

  test "GET /projects/:id/billing_details/:id.xml with not exist id should return not found" do
    compatible_api_request :get, "/projects/#{@project.id}/billing_details/15", {format: 'xml' }, credentials('admin')
    assert_equal '404', response.code
  end

  test "GET /projects/:id/billing_details/:id.json with not exist id should return not found" do
    compatible_api_request :get, "/projects/#{@project.id}/billing_details/15", { format: 'json' }, credentials('admin')
    assert_equal '404', response.code
  end

  test "GET /issues/:id/billing_details/:id.xml with not exist id should return not found" do
    compatible_api_request :get, "/issues/#{@issue.id}/billing_details/15", {format: 'xml' }, credentials('admin')
    assert_equal '404', response.code
  end

  test "GET /issues/:id/billing_details/:id.json with not exist id should return not found" do
    compatible_api_request :get, "/issues/#{@issue.id}/billing_details/15", { format: 'json' }, credentials('admin')
    assert_equal '404', response.code
  end
end
