# encoding: utf-8
#
# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../../test_helper', __FILE__)

class Redmine::ApiTest::UserRatesTest < Redmine::ApiTest::Base

  fixtures :projects,
           :users,
           :roles,
           :members,
           :member_roles,
           :issues,
           :issue_statuses,
           :versions,
           :trackers,
           :projects_trackers,
           :issue_categories,
           :enabled_modules,
           :enumerations,
           :attachments,
           :workflows,
           :custom_fields,
           :custom_values,
           :custom_fields_projects,
           :custom_fields_trackers,
           :time_entries,
           :journals,
           :journal_details,
           :queries

  create_fixtures(Redmine::Plugin.find(:redmine_budgets).directory + '/test/fixtures/', [:user_rates])

  def setup
    @user = User.first.id
    Setting.rest_api_enabled = '1'
  end

  # === Getting UserRate ===

  test "GET /users/:id/rates.xml should contain total count" do
    compatible_api_request :get, "/users/#{@user}/rates", { format: 'xml' }, credentials('admin')
    assert_response :success
    assert_select 'user_rates[type=array][total_count]'
  end

  test "GET /users/:id/rates.xml with nometa param should not contain total count" do
    compatible_api_request :get, "/users/#{@user}/rates", { format: 'xml', nometa: '1' }, credentials('admin')
    assert_response :success
    assert_select 'user_rates[type=array]:not([total_count])'
  end

  test "GET /users/:id/rates.xml should have xml media type" do
    compatible_api_request :get, "/users/#{@user}/rates", { format: 'xml' }, credentials('admin')
    assert_response :success
    assert_match /application\/(x-)*xml/, @response.content_type
  end

  test "GET /users/:id/rates.json should contain total count" do
    compatible_api_request :get, "/users/#{@user}/rates", { format: 'json' }, credentials('admin')
    assert_response :success
    json = ActiveSupport::JSON.decode(response.body)
    assert json['total_count']
  end

  test "GET /users/:id/rates.json with nometa param should not contain total count" do
    compatible_api_request :get, "/users/#{@user}/rates", { format: 'json', nometa: '1' }, credentials('admin')
    assert_response :success
    json = ActiveSupport::JSON.decode(response.body)
    assert_nil json['total_count']
  end

  test "GET /users/:id/rates.json should have json media type" do
    compatible_api_request :get, "/users/#{@user}/rates", { format: 'json' }, credentials('admin')
    assert_response :success
    assert_match /application\/json/, @response.content_type
  end

  test "GET /users/:id/rates/:id.xml should return user_rate" do
    compatible_api_request :get, "/users/#{@user}/rates/1", { format: 'xml' }, credentials('admin')
    assert_response :success
    assert_match /application\/(x-)*xml/, @response.content_type
    assert_select 'id'
  end

  test "GET /users/:id/rates/:id.json should return user_rate" do
    compatible_api_request :get, "/users/#{@user}/rates/1", { format: 'json' }, credentials('admin')
    assert_response :success
    json = ActiveSupport::JSON.decode(response.body)
    assert_match /application\/json/, @response.content_type
    assert json['user_rate']['id']
  end

  # === Creating UserRates ===

  test "POST /users/:id/rates.xml should create a user_rate" do
    payload = {
        :user_rate => {
            :rate_type => "#{UserRate::COST_RATE}",
            :rate => "100",
            :from_date => "2020-02-01 00:00:00",
            :project_id => "1",
            :user_id => "4"
        }
    }

    assert_difference('UserRate.count') do
      compatible_api_request :post, "/users/#{@user}/rates.xml", payload, credentials('admin')
    end
    user_rate = UserRate.last
    assert_equal UserRate::COST_RATE, user_rate.rate_type
    assert_equal 100, user_rate.rate
    assert_equal '2020-02-01 00:00:00'.try(:to_date), user_rate.from_date.try(:to_date)
    assert_equal 1, user_rate.project_id
    assert_equal 4, user_rate.user_id

    assert_response :created
    assert_match /application\/(x-)*xml/, @response.content_type
    assert_select 'user_rate > id', :text => user_rate.id.to_s
  end

  test "POST /users/:id/rates.json should create a user_rate" do
    payload = {
        :user_rate => {
            :rate_type => "#{UserRate::COST_RATE}",
            :rate => "100",
            :from_date => "2020-02-01 00:00:00",
            :project_id => "1",
            :user_id => "4"
        }
    }
    assert_difference('UserRate.count') do
      compatible_api_request :post, "/users/#{@user}/rates.json", payload, credentials('admin')
    end
    user_rate = UserRate.last
    assert_equal UserRate::COST_RATE, user_rate.rate_type
    assert_equal 100, user_rate.rate
    assert_equal '2020-02-01 00:00:00'.try(:to_date), user_rate.from_date.try(:to_date)
    assert_equal 1, user_rate.project_id
    assert_equal 4, user_rate.user_id

    assert_response :created
    assert_match /application\/json/, @response.content_type
    json = ActiveSupport::JSON.decode(response.body)
    assert_equal json['user_rate']['id'], user_rate.id
  end

  # === Updating UserRates ===

  test "PUT /users/:id/rates/:id.xml should update user_rate" do
    payload = {
        :user_rate => {
            :rate => "50"
        }
    }
    compatible_api_request :put, "/users/#{@user}/rates/1.xml", payload, credentials('admin')
    assert_response :success
    user_rate = UserRate.find(1)
    assert_equal 50, user_rate.rate
  end

  test "PUT /users/:id/rates/:id.json should update user_rate" do
    payload = {
        :user_rate => {
            :rate => "50"
        }
    }
    compatible_api_request :put, "/users/#{@user}/rates/1.json", payload, credentials('admin')
    user_rate = UserRate.find(1)
    assert_equal 50, user_rate.rate
  end

  # === Deleting UserRates ===

  test "DELETE /users/:id/rates/:id.xml" do
    assert_difference('UserRate.count', -1) do
      compatible_api_request :delete, "/users/#{@user}/rates/1", { format: 'xml' }, credentials('admin')
      assert %w[200 204].include?(response.code)
      assert_equal '', response.body
    end
    assert_nil UserRate.find_by_id(1)
  end

  test "DELETE /users/:id/rates/:id.json" do
    assert_difference('UserRate.count', -1) do
      compatible_api_request :delete, "/users/#{@user}/rates/1", { format: 'json' }, credentials('admin')
      assert %w[200 204].include?(response.code)
      assert_equal '', response.body
    end
    assert_nil UserRate.find_by_id(1)
  end

  # === Handling Exceptions ===

  test "GET /users/:id/rates/:id.xml with not exist id should return not found" do
    compatible_api_request :get, "/users/#{@user}/rates/15", {format: 'xml' }, credentials('admin')
    assert_equal '404', response.code
  end

  test "GET /users/:id/rates/:id.json with not exist id should return not found" do
    compatible_api_request :get, "/users/#{@user}/rates/15", { format: 'json' }, credentials('admin')
    assert_equal '404', response.code
  end

  test "PUT /users/:id/rates/:id.xml with failed update" do
    payload = {
        :user_rate => {
            :rate_type => ''
        }
    }
    compatible_api_request :put, "/users/#{@user}/rates/1.xml", payload, credentials('admin')
    assert_response :unprocessable_entity
    assert_select 'errors error', :text => "Rate type cannot be blank"
  end

  test "PUT /users/:id/rates/:id.json with failed update" do
    payload = {
        :user_rate => {
            :rate_type => ''
        }
    }
    compatible_api_request :put, "/users/#{@user}/rates/1.json", payload, credentials('admin')
    assert_response :unprocessable_entity
    json = ActiveSupport::JSON.decode(response.body)
    assert json['errors'].include?("Rate type cannot be blank")
  end

end
