# encoding: utf-8
#
# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class ProjectTest < ActiveSupport::TestCase
  fixtures :projects, :roles, :members, :member_roles, :users,
           :trackers, :enumerations, :issue_statuses, :enabled_modules

  create_fixtures(redmine_budgets_fixtures_directory, [:issues, :time_entries, :user_rates, :billing_details])

  def setup
    Setting.plugin_redmine_budgets = {}
    @project = Project.find(1)
  end

  def test_should_allowed_to_edit_bill_rate_type
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS
    assert @project.allowed_to_edit?(:bill_rate_type)
  end

  def test_should_not_allowed_to_edit_bill_rate_type
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE
    assert !@project.allowed_to_edit?(:bill_rate_type)
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE
    assert !@project.allowed_to_edit?(:bill_rate_type)
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE
    assert !@project.allowed_to_edit?(:bill_rate_type)
  end
  def test_should_allowed_to_edit_bill_rate
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_PROJECT
    }
    assert @project.allowed_to_edit?(:bill_rate)
  end

  def test_should_not_allowed_to_edit_bill_rate
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE
    assert !@project.allowed_to_edit?(:bill_rate)
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE
    assert !@project.allowed_to_edit?(:bill_rate)

    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE
        assert !@project.allowed_to_edit?(:bill_rate)
  end
  def test_should_allowed_to_edit_project_cost
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }
    assert @project.allowed_to_edit?(:project_cost)
  end

  def test_should_not_allowed_to_edit_project_cost
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE
    assert !@project.allowed_to_edit?(:project_cost)

    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS
    assert !@project.allowed_to_edit?(:project_cost)

    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE
    assert !@project.allowed_to_edit?(:project_cost)

    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_FEE
    }
    assert !@project.allowed_to_edit?(:project_cost)
  end

  def test_on_billing_type_not_billable_and_budget_type_no_budget
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 0,
      non_billable_hours: 93.5,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: nil,

      budget: nil,
      remaining_budget: 0,
      remaining_budget_progress: 0,

      money_budget: nil,
      spent_money: nil,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: nil,
      spent_hours: 93.5,
      spent_hours_progress: 100,
      remaining_hours: 0,
      remaining_hours_progress: 0,

      profit: nil,
      profit_progress: nil
    }
  end

  def test_on_billing_type_not_billable_and_budget_type_project_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE,
      project_cost: 1000,
      budget_type: BillingDetail::BUDGET_TYPE_PROJECT_TIME,
      budget: 1000
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 0,
      non_billable_hours: 93.5,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: nil,

      budget: 1000,
      remaining_budget: 906.5,
      remaining_budget_progress: 90.65,

      money_budget: nil,
      spent_money: nil,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: 1000,
      spent_hours: 93.5,
      spent_hours_progress: 9.35,
      remaining_hours: 906.5,
      remaining_hours_progress: 90.65,

      profit: nil,
      profit_progress: nil
    }
  end

  def test_on_billing_type_not_billable_and_budget_type_issues_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_TIME
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 0,
      non_billable_hours: 93.5,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: nil,

      budget: nil,
      remaining_budget: 108,
      remaining_budget_progress: 53.59801488833747,

      money_budget: nil,
      spent_money: nil,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: 201.5,
      spent_hours: 93.5,
      spent_hours_progress: 46.40198511166253,
      remaining_hours: 108,
      remaining_hours_progress: 53.59801488833747,

      profit: nil,
      profit_progress: nil
    }
  end
  def test_on_billing_type_time_and_materials_and_budget_type_no_budget
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_PROJECT,
      bill_rate: 100,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 9350,

      budget: nil,
      remaining_budget: 0,
      remaining_budget_progress: 0,

      money_budget: nil,
      spent_money: 9350,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: nil,
      spent_hours: 93.5,
      spent_hours_progress: 100,
      remaining_hours: 0,
      remaining_hours_progress: 0,

      profit: 7981.25,
      profit_progress: 85.36096256684492
    }
  end

  def test_on_billing_type_time_and_materials_and_budget_type_project_fee
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_PROJECT,
      bill_rate: 100,
      budget_type: BillingDetail::BUDGET_TYPE_PROJECT_FEE,
      budget: 10000
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 9350,

      budget: 10000,
      remaining_budget: 650,
      remaining_budget_progress: 6.5,

      money_budget: 10000,
      spent_money: 9350,
      spent_money_progress: 93.5,
      remaining_money: 650,
      remaining_money_progress: 6.5,

      hours_budget: nil,
      spent_hours: 93.5,
      spent_hours_progress: 100,
      remaining_hours: 0,
      remaining_hours_progress: 0,

      profit: 7981.25,
      profit_progress: 85.36096256684492
    }
  end

  def test_on_billing_type_time_and_materials_and_budget_type_project_fee_and_monthly_budget
    travel_to Date.new(2017, 4, 10) do
      set_billing_settings_for @project, {
        billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
        bill_rate_type: BillingDetail::BILL_RATE_BY_PROJECT,
        bill_rate: 100,
        budget_type: BillingDetail::BUDGET_TYPE_PROJECT_FEE,
        budget: 3000,
        monthly_budget: '1'
      }

      check_attributes_for @project, {
        total_spent_hours: 93.5,
        billable_hours: 93.5,
        non_billable_hours: 0,

        total_costs: 1368.75,
        costs: 1368.75,
        billable_amount: 9350,

        budget: 3000,
        remaining_budget: -1500,
        remaining_budget_progress: -50,

        money_budget: 3000,
        spent_money: 4500,
        spent_money_progress: 150,
        remaining_money: -1500,
        remaining_money_progress: -50,

        hours_budget: nil,
        spent_hours: 45,
        spent_hours_progress: 100,
        remaining_hours: 0,
        remaining_hours_progress: 0,

        profit: 7981.25,
        profit_progress: 85.36096256684492
      }
    end
  end

  def test_on_billing_type_time_and_materials_and_budget_type_issues_fee
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_PROJECT,
      bill_rate: 100,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_FEE
    }

    issues = @project.billable_issues.to_a
    set_billing_settings_for issues.first, budget: 5000
    set_billing_settings_for issues.second, budget: 5000

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 9350,

      budget: nil,
      remaining_budget: 650,
      remaining_budget_progress: 6.5,

      money_budget: 10000,
      spent_money: 9350,
      spent_money_progress: 93.5,
      remaining_money: 650,
      remaining_money_progress: 6.5,

      hours_budget: nil,
      spent_hours: 93.5,
      spent_hours_progress: 100,
      remaining_hours: 0,
      remaining_hours_progress: 0,

      profit: 7981.25,
      profit_progress: 85.36096256684492
    }
  end

  def test_on_billing_type_time_and_materials_and_budget_type_project_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_PROJECT,
      bill_rate: 100,
      budget_type: BillingDetail::BUDGET_TYPE_PROJECT_TIME,
      budget: 1000
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 9350,

      budget: 1000,
      remaining_budget: 906.5,
      remaining_budget_progress: 90.65,

      money_budget: nil,
      spent_money: 9350,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: 1000,
      spent_hours: 93.5,
      spent_hours_progress: 9.35,
      remaining_hours: 906.5,
      remaining_hours_progress: 90.65,

      profit: 7981.25,
      profit_progress: 85.36096256684492
    }
  end

  def test_on_billing_type_time_and_materials_and_budget_type_project_time_and_monthly_budget
    travel_to Date.new(2017, 4, 10) do
      set_billing_settings_for @project, {
        billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
        bill_rate_type: BillingDetail::BILL_RATE_BY_PROJECT,
        bill_rate: 100,
        budget_type: BillingDetail::BUDGET_TYPE_PROJECT_TIME,
        budget: 1000,
        monthly_budget: '1'
      }

      check_attributes_for @project, {
        total_spent_hours: 93.5,
        billable_hours: 93.5,
        non_billable_hours: 0,

        total_costs: 1368.75,
        costs: 1368.75,
        billable_amount: 9350,

        budget: 1000,
        remaining_budget: 955,
        remaining_budget_progress: 95.5,

        money_budget: nil,
        spent_money: 4500,
        spent_money_progress: 100,
        remaining_money: 0,
        remaining_money_progress: 0,

        hours_budget: 1000,
        spent_hours: 45,
        spent_hours_progress: 4.5,
        remaining_hours: 955,
        remaining_hours_progress: 95.5,

        profit: 7981.25,
        profit_progress: 85.36096256684492
      }
    end
  end

  def test_on_billing_type_time_and_materials_and_budget_type_issues_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_PROJECT,
      bill_rate: 100,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_TIME
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 9350,

      budget: nil,
      remaining_budget: 108,
      remaining_budget_progress: 53.59801488833747,

      money_budget: nil,
      spent_money: 9350,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: 201.5,
      spent_hours: 93.5,
      spent_hours_progress: 46.40198511166253,
      remaining_hours: 108,
      remaining_hours_progress: 53.59801488833747,

      profit: 7981.25,
      profit_progress: 85.36096256684492
    }
  end

  def test_on_billing_type_time_and_materials_and_budget_type_no_budget_and_bill_rate_type_by_user
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_USER,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 2183.75,

      budget: nil,
      remaining_budget: 0,
      remaining_budget_progress: 0,

      money_budget: nil,
      spent_money: 2183.75,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: nil,
      spent_hours: 93.5,
      spent_hours_progress: 100,
      remaining_hours: 0,
      remaining_hours_progress: 0,

      profit: 815,
      profit_progress: 37.32112192329708
    }
  end
  def test_on_billing_type_time_and_materials_and_budget_type_no_budget_and_bill_rate_type_by_issue
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_ISSUE,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }

    @project.billable_issues.each do |issue|
      set_billing_settings_for(issue, bill_rate: 10) if issue.spent_time > 0
    end

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 87.5,
      non_billable_hours: 6,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 875,

      budget: nil,
      remaining_budget: 0,
      remaining_budget_progress: 0,

      money_budget: nil,
      spent_money: 875,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: nil,
      spent_hours: 93.5,
      spent_hours_progress: 100,
      remaining_hours: 0,
      remaining_hours_progress: 0,

      profit: -493.75,
      profit_progress: -56.42857142857143
    }
  end

  def test_on_billing_type_time_and_materials_and_budget_type_no_budget_and_bill_rate_type_by_company
    with_budgets_settings 'company_bill_rate' => 10 do
      set_billing_settings_for @project, {
        billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
        bill_rate_type: BillingDetail::BILL_RATE_BY_COMPANY,
        budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
      }

      check_attributes_for @project, {
        total_spent_hours: 93.5,
        billable_hours: 93.5,
        non_billable_hours: 0,

        total_costs: 1368.75,
        costs: 1368.75,
        billable_amount: 935,

        budget: nil,
        remaining_budget: 0,
        remaining_budget_progress: 0,

        money_budget: nil,
        spent_money: 935,
        spent_money_progress: 100,
        remaining_money: 0,
        remaining_money_progress: 0,

        hours_budget: nil,
        spent_hours: 93.5,
        spent_hours_progress: 100,
        remaining_hours: 0,
        remaining_hours_progress: 0,

        profit: -433.75,
        profit_progress: -46.3903743315508
      }
    end
  end

  ##
  # tests for BILLING_TYPE_PROJECT_FLAT_RATE

  def test_on_billing_type_project_flat_rate_and_budget_type_no_budget
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
      project_cost: 1000,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 1000,

      budget: nil,
      remaining_budget: 0,
      remaining_budget_progress: 0,

      money_budget: nil,
      spent_money: nil,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: nil,
      spent_hours: 93.5,
      spent_hours_progress: 100,
      remaining_hours: 0,
      remaining_hours_progress: 0,

      profit: -368.75,
      profit_progress: -36.875
    }
  end

  def test_on_billing_type_project_flat_rate_and_budget_type_project_fee
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
      project_cost: 1000,
      budget_type: BillingDetail::BUDGET_TYPE_PROJECT_FEE,
      budget: 1000
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 1000,

      budget: 1000,
      remaining_budget: -368.75,
      remaining_budget_progress: -36.875,

      money_budget: 1000,
      spent_money: 1368.75,
      spent_money_progress: 136.875,
      remaining_money: -368.75,
      remaining_money_progress: -36.875,

      hours_budget: nil,
      spent_hours: 93.5,
      spent_hours_progress: 100,
      remaining_hours: 0,
      remaining_hours_progress: 0,

      profit: -368.75,
      profit_progress: -36.875
    }
  end

  def test_on_billing_type_project_flat_rate_and_budget_type_project_fee_and_monthly_budget
    travel_to Date.new(2017, 4, 10) do
      set_billing_settings_for @project, {
        billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
        project_cost: 2000,
        budget_type: BillingDetail::BUDGET_TYPE_PROJECT_FEE,
        budget: 1000,
        monthly_budget: '1'
      }

      check_attributes_for @project, {
        total_spent_hours: 93.5,
        billable_hours: 93.5,
        non_billable_hours: 0,

        total_costs: 1368.75,
        costs: 1368.75,
        billable_amount: 2000,

        budget: 1000,
        remaining_budget: 178.75,
        remaining_budget_progress: 17.875,

        money_budget: 1000,
        spent_money: 821.25,
        spent_money_progress: 82.125,
        remaining_money: 178.75,
        remaining_money_progress: 17.875,

        hours_budget: nil,
        spent_hours: 45,
        spent_hours_progress: 100,
        remaining_hours: 0,
        remaining_hours_progress: 0,

        profit: 631.25,
        profit_progress: 31.5625
      }
    end
  end

  def test_on_billing_type_project_flat_rate_and_budget_type_issues_fee
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_FEE
    }

    issues = @project.billable_issues.to_a
    set_billing_settings_for issues.first, budget: 1000
    set_billing_settings_for issues.second, budget: 500

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 1500,

      budget: nil,
      remaining_budget: 131.25,
      remaining_budget_progress: 8.75,

      money_budget: 1500,
      spent_money: 1368.75,
      spent_money_progress: 91.25,
      remaining_money: 131.25,
      remaining_money_progress: 8.75,

      hours_budget: nil,
      spent_hours: 93.5,
      spent_hours_progress: 100,
      remaining_hours: 0,
      remaining_hours_progress: 0,

      profit: 131.25,
      profit_progress: 8.75
    }
  end

  def test_on_billing_type_project_flat_rate_and_budget_type_project_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
      project_cost: 1500,
      budget_type: BillingDetail::BUDGET_TYPE_PROJECT_TIME,
      budget: 100
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 1500,

      budget: 100,
      remaining_budget: 6.5,
      remaining_budget_progress: 6.5,

      money_budget: nil,
      spent_money: nil,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: 100,
      spent_hours: 93.5,
      spent_hours_progress: 93.5,
      remaining_hours: 6.5,
      remaining_hours_progress: 6.5,

      profit: 131.25,
      profit_progress: 8.75
    }
  end

  def test_on_billing_type_project_flat_rate_and_budget_type_project_time_and_monthly_budget
    travel_to Date.new(2017, 4, 10) do
      set_billing_settings_for @project, {
        billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
        project_cost: 1500,
        budget_type: BillingDetail::BUDGET_TYPE_PROJECT_TIME,
        budget: 100,
        monthly_budget: '1'
      }

      check_attributes_for @project, {
        total_spent_hours: 93.5,
        billable_hours: 93.5,
        non_billable_hours: 0,

        total_costs: 1368.75,
        costs: 1368.75,
        billable_amount: 1500,

        budget: 100,
        remaining_budget: 55,
        remaining_budget_progress: 55,

        money_budget: nil,
        spent_money: nil,
        spent_money_progress: 100,
        remaining_money: 0,
        remaining_money_progress: 0,

        hours_budget: 100,
        spent_hours: 45,
        spent_hours_progress: 45,
        remaining_hours: 55,
        remaining_hours_progress: 55,

        profit: 131.25,
        profit_progress: 8.75
      }
    end
  end

  def test_on_billing_type_project_flat_rate_and_budget_type_issues_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
      project_cost: 1000,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_TIME
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 1000,

      budget: nil,
      remaining_budget: 108,
      remaining_budget_progress: 53.59801488833747,

      money_budget: nil,
      spent_money: nil,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: 201.5,
      spent_hours: 93.5,
      spent_hours_progress: 46.40198511166253,
      remaining_hours: 108,
      remaining_hours_progress: 53.59801488833747,

      profit: -368.75,
      profit_progress: -36.875
    }
  end

  ##
  # tests for BILLING_TYPE_ISSUE_FLAT_RATE

  def test_on_billing_type_issue_flat_rate_and_budget_type_no_budget
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 0,

      budget: nil,
      remaining_budget: 0,
      remaining_budget_progress: 0,

      money_budget: nil,
      spent_money: nil,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: nil,
      spent_hours: 93.5,
      spent_hours_progress: 100,
      remaining_hours: 0,
      remaining_hours_progress: 0,

      profit: -1368.75,
      profit_progress: -100
    }
  end

  def test_on_billing_type_issue_flat_rate_and_budget_type_project_fee
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_PROJECT_FEE,
      budget: 1000
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 0,

      budget: 1000,
      remaining_budget: -368.75,
      remaining_budget_progress: -36.875,

      money_budget: 1000,
      spent_money: 1368.75,
      spent_money_progress: 136.875,
      remaining_money: -368.75,
      remaining_money_progress: -36.875,

      hours_budget: nil,
      spent_hours: 93.5,
      spent_hours_progress: 100,
      remaining_hours: 0,
      remaining_hours_progress: 0,

      profit: -1368.75,
      profit_progress: -100
    }
  end

  def test_on_billing_type_issue_flat_rate_and_budget_type_project_fee_and_monthly_budget
    travel_to Date.new(2017, 4, 10) do
      set_billing_settings_for @project, {
        billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
        budget_type: BillingDetail::BUDGET_TYPE_PROJECT_FEE,
        budget: 1000,
        monthly_budget: '1'
      }

      check_attributes_for @project, {
        total_spent_hours: 93.5,
        billable_hours: 93.5,
        non_billable_hours: 0,

        total_costs: 1368.75,
        costs: 1368.75,
        billable_amount: 0,

        budget: 1000,
        remaining_budget: 178.75,
        remaining_budget_progress: 17.875,

        money_budget: 1000,
        spent_money: 821.25,
        spent_money_progress: 82.125,
        remaining_money: 178.75,
        remaining_money_progress: 17.875,

        hours_budget: nil,
        spent_hours: 45,
        spent_hours_progress: 100,
        remaining_hours: 0,
        remaining_hours_progress: 0,

        profit: -1368.75,
        profit_progress: -100
      }
    end
  end

  def test_on_billing_type_issue_flat_rate_and_budget_type_issues_fee
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_FEE
    }

    issues = @project.billable_issues.to_a
    set_billing_settings_for issues.first, billing_type: 'issue_flat_rate', budget: 1000, issue_cost: 1000
    set_billing_settings_for issues.second, billing_type: 'issue_flat_rate', budget: 500, issue_cost: 500

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 1500,

      budget: nil,
      remaining_budget: 131.25,
      remaining_budget_progress: 8.75,

      money_budget: 1500,
      spent_money: 1368.75,
      spent_money_progress: 91.25,
      remaining_money: 131.25,
      remaining_money_progress: 8.75,

      hours_budget: nil,
      spent_hours: 93.5,
      spent_hours_progress: 100,
      remaining_hours: 0,
      remaining_hours_progress: 0,

      profit: 131.25,
      profit_progress: 8.75
    }
  end

  def test_on_billing_type_issue_flat_rate_and_budget_type_project_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_PROJECT_TIME,
      budget: 100
    }

    issues = @project.billable_issues.to_a
    set_billing_settings_for issues.first, billing_type: 'issue_flat_rate', issue_cost: 1000
    set_billing_settings_for issues.second, billing_type: 'issue_flat_rate', issue_cost: 500

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 1500,

      budget: 100,
      remaining_budget: 6.5,
      remaining_budget_progress: 6.5,

      money_budget: nil,
      spent_money: nil,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: 100,
      spent_hours: 93.5,
      spent_hours_progress: 93.5,
      remaining_hours: 6.5,
      remaining_hours_progress: 6.5,

      profit: 131.25,
      profit_progress: 8.75
    }
  end

  def test_on_billing_type_issue_flat_rate_and_budget_type_project_time_and_monthly_budget
    travel_to Date.new(2017, 4, 10) do
      set_billing_settings_for @project, {
        billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
        budget_type: BillingDetail::BUDGET_TYPE_PROJECT_TIME,
        budget: 100,
        monthly_budget: '1'
      }

      issues = @project.billable_issues.to_a
      set_billing_settings_for issues.first, billing_type: 'issue_flat_rate', issue_cost: 1000
      set_billing_settings_for issues.second, billing_type: 'issue_flat_rate', issue_cost: 500

      check_attributes_for @project, {
        total_spent_hours: 93.5,
        billable_hours: 93.5,
        non_billable_hours: 0,

        total_costs: 1368.75,
        costs: 1368.75,
        billable_amount: 1500,

        budget: 100,
        remaining_budget: 55,
        remaining_budget_progress: 55,

        money_budget: nil,
        spent_money: nil,
        spent_money_progress: 100,
        remaining_money: 0,
        remaining_money_progress: 0,

        hours_budget: 100,
        spent_hours: 45,
        spent_hours_progress: 45,
        remaining_hours: 55,
        remaining_hours_progress: 55,

        profit: 131.25,
        profit_progress: 8.75
      }
    end
  end

  def test_on_billing_type_issue_flat_rate_and_budget_type_issues_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_TIME
    }

    issues = @project.billable_issues.to_a
    set_billing_settings_for issues.first, billing_type: 'issue_flat_rate', issue_cost: 1000
    set_billing_settings_for issues.second, billing_type: 'issue_flat_rate', issue_cost: 500

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 1500,

      budget: nil,
      remaining_budget: 108,
      remaining_budget_progress: 53.59801488833747,

      money_budget: nil,
      spent_money: nil,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: 201.5,
      spent_hours: 93.5,
      spent_hours_progress: 46.40198511166253,
      remaining_hours: 108,
      remaining_hours_progress: 53.59801488833747,

      profit: 131.25,
      profit_progress: 8.75
    }
  end
end
