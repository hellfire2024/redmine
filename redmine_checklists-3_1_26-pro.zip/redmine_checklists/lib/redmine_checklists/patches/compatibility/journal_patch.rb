# This file is a part of Redmine Checklists (redmine_checklists) plugin,
# issue checklists management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_checklists is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_checklists is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_checklists.  If not, see <http://www.gnu.org/licenses/>.

require_dependency 'journal'

module RedmineChecklists
  module Patches
    module JournalPatch
      def self.included(base) # :nodoc:
        base.send(:include, InstanceMethods)
        base.class_eval do
          after_create_commit :send_checklist_notification

          alias_method :send_notification_without_checklist, :send_notification
          alias_method :send_notification, :send_notification_with_checklist
        end
      end

      module InstanceMethods
        def send_checklist_notification
          detail = detail_for_attribute('checklist')
          deliver_checklist_notification if notification_option_activated? &&
                                            detail.present? &&
                                            !JournalChecklistHistory.new(detail.old_value, detail.value).empty_diff?
        end

        private

        def notification_option_activated?
          Setting.notified_events.include?('issue_updated') || Setting.notified_events.include?('checklist_updated')
        end

        def deliver_checklist_notification
          (notified_watchers | notified_users).each do |user|
            Mailer.issue_edit(user, self).deliver
          end
        end

        def send_notification_with_checklist
          send_notification_without_checklist unless detail_for_attribute('checklist').present?
        end
      end
    end
  end
end

unless Journal.included_modules.include?(RedmineChecklists::Patches::JournalPatch)
  Journal.send(:include, RedmineChecklists::Patches::JournalPatch)
end
