# Helpdesk plugin

### API

API request #index
```
  GET /helpdesk_tickets.xml or /helpdesk_tickets.json
```

API request #index with filters
```
  GET /helpdesk_tickets.xml?issue_id=1,2,3 or /helpdesk_tickets.json?issue_id=3,1,2
  GET /helpdesk_tickets.xml?contact_id=1,2,3 or /helpdesk_tickets.json?contact_id=3,1,2
```

API request #show
```
  GET /helpdesk_tickets/<issue_id>.xml or /helpdesk_tickets/<issue_id>.json
```

To get contact with tickets related to it
```
  GET /contacts/<contact_id>.json?include=tickets
```

API request #create
Create a ticket without sending an auto answer email
```
  POST /helpdesk_tickets.json?key=<your_api_key>
    {
      "helpdesk_ticket": {
        "issue": {
          "project_id": "support",
          "subject": "test helpdesk api",
          "description": "ticket description"
        },
        "contact": {
          "email": "test@example.com",
          "first_name": "John"
        }
      }
    }
```

Create a ticket with sending an auto answer email
```
  POST /helpdesk_tickets.json?key=<your_api_key>
    {
      "helpdesk_ticket": {
        "issue": {
          "project_id": "support",
          "subject": "test helpdesk api",
          "description": "ticket description"
        },
        "contact": {
          "email": "test@example.com",
          "first_name": "John"
        },
        "send_as": "auto_answer"
      }
    }
```
parameter send_as: "auto_answer", "inital_message"

Old version API request #create
```
  POST /helpdesk/create_ticket.json?key=<your_api_key>
    {
      "ticket": {
        "issue": {
          "project_id": "support",
          "tracker_id": 1,
          "subject": "New ticket subject",
          "description": "New ticket description",
          "assigned_to_id": 1
        },
        "contact": {
          "email": "test@example.com",
          "first_name": "John",
          "custom_fields: {
            type": "array",
            "custom_field: {
              "id": 1,
              "value": "Test"
            }
          }
        }
      }
    }
```

Send email reply to an existed Helpdesk ticket
```
  POST /helpdesk/email_note.json
    {
      "message": {
        "issue_id": 1,
        "status_id": 2,
        "content": "New replay to ticket"
      }
    }
```

Update ticket
```
  PUT /helpdesk_tickets/<ticket_id>.json?key=<your_api_key>
    {
      "helpdesk_ticket": {
        "from_address": "new_email@mail.com"
      }
    }
```
