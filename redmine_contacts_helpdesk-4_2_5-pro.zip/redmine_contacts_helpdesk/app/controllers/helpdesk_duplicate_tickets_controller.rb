# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class HelpdeskDuplicateTicketsController < ApplicationController

  before_action  :find_optional_project, :authorize, except: :search
  before_action :find_helpdesk_ticket, only: [:index, :search, :merge]
  before_action :find_duplicate, only: :merge
  def index
    @helpdesk_duplicate_tickets = @issue.helpdesk_ticket.duplicates
  end

  def search
    @helpdesk_duplicate_tickets = []
    q = (params[:q] || params[:term]).to_s.strip
    if q.present?
      @helpdesk_duplicate_tickets = HelpdeskTicket.find_duplicate(params)
    else
      @helpdesk_duplicate_tickets = @issue.helpdesk_ticket.duplicates
    end
    render :layout => false, :partial => 'helpdesk_tickets_list'
  end

  def merge
    if HelpdeskTicket.custom_fields_validation(@duplicate)
      flash[:warning] = l(:notice_missing_custom_fields)
    end

    if @issue.helpdesk_ticket.merge_into(@duplicate.helpdesk_ticket)
      flash[:notice] = l(:notice_successful_merged)
      redirect_to issue_path(@duplicate)
    else
      flash[:error] = l(:notice_impossible_to_merge)
      redirect_to params[:back_url] || project_issues_path(@issue.project)
    end
  end

  private

  def find_helpdesk_ticket
    @issue = Issue.find_by(id: params[:id])

    render_404 unless @issue && @issue.is_ticket?
  end

  def find_duplicate
    @duplicate = Issue.find_by(id: params.fetch(:duplicate_id, nil))

    render_404 unless @duplicate && @duplicate.is_ticket?
  end
end
