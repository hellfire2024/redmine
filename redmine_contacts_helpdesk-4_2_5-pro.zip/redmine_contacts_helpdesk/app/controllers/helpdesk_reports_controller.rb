# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class HelpdeskReportsController < ApplicationController
  menu_item :issues

  helper :helpdesk
  helper :queries
  include QueriesHelper

  before_action :find_optional_project
  before_action :authorize_global
  before_action :find_query

  def show
    return render_404 unless @query

    if @query.valid?
      @collector = HelpdeskDataCollectorManager.new.collect_data(@query)
    end
  end

  private

  def find_query
    report_query_class =
      case params[:report]
      when 'first_response_time'
        HelpdeskReportsFirstResponseQuery
      when 'busiest_time_of_day'
        HelpdeskReportsBusiestTimeQuery
      when 'customer_satisfaction'
        HelpdeskReportsCustomerSatisfactionQuery
      end
    return unless report_query_class

    if params[:set_filter] || session["helpdesk_reports_#{params[:report]}"].blank?
      @query = report_query_class
                 .new(:name => params[:report], :project => @project)
                 .build_from_params(params)

      session["helpdesk_reports_#{params[:report]}"] = {
        :project_id => @query.project_id,
        :filters => @query.filters
      }
    else
      @query = report_query_class.new(
        :name => params[:report],
        :project => @project,
        :filters => session["helpdesk_reports_#{params[:report]}"][:filters])
    end
  end
end
