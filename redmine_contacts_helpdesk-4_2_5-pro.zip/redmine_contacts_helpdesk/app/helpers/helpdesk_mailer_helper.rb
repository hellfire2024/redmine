# encoding: utf-8
#
# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

# encoding: utf-8
# include RedCloth

module HelpdeskMailerHelper
  def textile(text)
    Redmine::WikiFormatting.to_html(Setting.text_formatting, text)
  end

  def message_sender(email)
    return nil unless email
    sender = email.reply_to.try(:first) || email.from_addrs.try(:first)
    sender.to_s.strip[0, 255]
  end

  def contact_from_email(email, project, logger = nil)
    from = (email.header['reply-to'].to_s.present? ? email.header['reply-to'] : email.header['from']).to_s.strip[0, 255]
    addr, name = from, nil
    if match_result = from.match(/^"?(.+?)"?\s*<(.+@.+)>$/)
      addr, name = match_result[2], match_result[1]
    elsif match_result = from.match(/(\S+@\S+)/)
      addr = match_result[1]
    end
    HelpdeskMailSupport.create_contact_from_address(addr, name, project, logger)
  end
end
