# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class CannedResponse < ApplicationRecord
  include Redmine::SafeAttributes

  attr_accessor :deleted_attachment_ids

  safe_attributes(
    'name',
    'content',
    'deleted_attachment_ids',
    'project'
  )
  safe_attributes(
    'is_public',
    if: lambda do |cr, user|
      return true if user.admin?

      user.allowed_to?(:manage_public_canned_responses, cr.project)
    end
  )

  belongs_to :project
  belongs_to :user

  acts_as_attachable

  validates_presence_of :name, :content
  validates_length_of :name, :maximum => 255

  after_save :delete_selected_attachments

  scope :visible, lambda { |*args|
    user = args.shift || User.current
    base = Project.allowed_to_condition(user, :view_helpdesk_tickets, *args)
    user_id = user.logged? ? user.id : 0

    eager_load(:project).where("(#{CannedResponse.table_name}.project_id IS NULL OR (#{base})) AND (#{CannedResponse.table_name}.is_public = ? OR #{CannedResponse.table_name}.user_id = ?)", true, user_id)
  }

  scope :in_project_or_public, lambda {|project|
    where("(#{CannedResponse.table_name}.project_id IS NULL) OR #{CannedResponse.table_name}.project_id = ?", project)
  }

  # Returns true if the query is visible to +user+ or the current user.
  def visible?(user = User.current)
    (project.nil? || user.allowed_to?(:view_helpdesk_tickets, project)) && (is_public? || user_id == user.id)
  end

  def deleted_attachment_ids
    Array(@deleted_attachment_ids).map(&:to_i)
  end

  def delete_selected_attachments
    if deleted_attachment_ids.present?
      objects = attachments.where(id: deleted_attachment_ids.map(&:to_i))
      attachments.delete(objects)
    end
  end
end
