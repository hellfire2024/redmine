# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class HelpdeskMailMessenger::AutoAnswerMessage < HelpdeskMailMessenger
  def project
    object.project
  end

  def issue
    object
  end

  def build_email
    set_headers

    @email_stylesheet = HelpdeskSettings['helpdesk_helpdesk_css', project].to_s.html_safe
    @email_body = HelpdeskMailSupport.apply_text_macro(HelpdeskSettings['helpdesk_first_answer_template', project], contact, issue)

    validate

    mail from:        from_address.to_s,
         to:          to_address.to_s,
         cc:          HelpdeskSettings["helpdesk_cc_address", issue.project.id].to_s + cc_addresses,
         bcc:         HelpdeskSettings["helpdesk_bcc_address", issue.project.id].to_s + bcc_addresses,
         subject:     HelpdeskMailSupport.apply_text_macro(HelpdeskSettings['helpdesk_first_answer_subject', project], contact, issue) || "Helpdesk auto answer [Case ##{issue.id}]",
         in_reply_to: "<#{issue.helpdesk_ticket.try(:message_id)}>" do |format|
      format.text(content_transfer_encoding: content_transfer_encoding) { render 'email_layout' }
      format.html(content_transfer_encoding: content_transfer_encoding) { render 'email_layout' } unless RedmineHelpdesk.add_plain_text_mail?
    end
  end

  private

  def set_headers
    headers['X-Redmine-Ticket-ID'] = issue.id.to_s
    headers['X-Auto-Response-Suppress'] = 'oof'
  end
end
