# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class HelpdeskMailMessenger::AutocloseMessage < HelpdeskMailMessenger
  def project
    object.project
  end

  def issue
    object
  end

  def build_email
    set_headers

    @email_stylesheet = HelpdeskSettings['helpdesk_helpdesk_css', project].to_s.html_safe
    @email_body = HelpdeskMailSupport.apply_text_macro(HelpdeskSettings['helpdesk_autoclose_template', project], contact, issue)
    @email_body = I18n.t('label_helpdesk_autoclosed_ticket') unless @email_body.present?

    validate

    mail from:        from_address.to_s,
         to:          to_address.to_s,
         cc:          issue.helpdesk_ticket.try(:cc_address).to_s,
         subject:     HelpdeskMailSupport.apply_text_macro(HelpdeskSettings['helpdesk_autoclose_subject', project], contact, issue) || "Helpdesk autoclose message [Case ##{issue.id}]",
         in_reply_to: "<#{issue.helpdesk_ticket.try(:message_id)}>" do |format|
      format.text(content_transfer_encoding: content_transfer_encoding) { render 'email_layout' }
      format.html(content_transfer_encoding: content_transfer_encoding) { render 'email_layout' } unless RedmineHelpdesk.add_plain_text_mail?
    end
  end

  private

  def set_headers
    headers['X-Redmine-Ticket-ID'] = issue.id.to_s
  end

  def validate
    raise MissingInformation.new(l(:text_helpdesk_message_body_cant_be_blank)) if @email_body.blank?
    raise MissingInformation.new(l(:text_helpdesk_from_address_cant_be_blank)) if from_address.blank?
    raise MissingInformation.new(l(:text_helpdesk_recipients_cant_be_blank)) if to_address.blank? && cc_address.blank? && bcc_address.blank?
  end
end
