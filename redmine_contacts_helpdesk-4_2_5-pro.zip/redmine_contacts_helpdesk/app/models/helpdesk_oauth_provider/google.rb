# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class HelpdeskOauthProvider::Google < HelpdeskOauthProvider
  BASE_URL = 'https://accounts.google.com/o/oauth2/v2/auth'.freeze
  TOKEN_URL = 'https://oauth2.googleapis.com/token'.freeze
  MAILBOX_URL = 'https://gmail.googleapis.com/gmail/v1/users/<email>'.freeze
  FOLDERS_URL = MAILBOX_URL + '/labels'.freeze
  MESSAGES_URL = MAILBOX_URL + '/messages'.freeze
  SENDMAIL_URL = MESSAGES_URL + '/send'.freeze
  SCOPE = 'https://www.googleapis.com/auth/gmail.modify'.freeze

  def authorize_url(state_secret)
    params = {
      client_id: RedmineHelpdesk.settings['helpdesk_oauth_google_client_id'],
      scope: SCOPE,
      redirect_uri: redirect_uri,
      access_type: 'offline',
      response_type: 'code'.freeze,
      response_mode: 'query'.freeze,
      state: state_secret,
    }

    BASE_URL + '?' + params.to_query
  end

  def receive_tokens(code)
    params = {
      client_id: RedmineHelpdesk.settings['helpdesk_oauth_google_client_id'],
      client_secret: RedmineHelpdesk.settings['helpdesk_oauth_google_secret'],
      scope: SCOPE,
      redirect_uri: redirect_uri,
      code: code,
      grant_type: 'authorization_code'.freeze,
    }

    code, data = execute(:FPOST, TOKEN_URL, params)
    logged_error("HelpdeskOauthProvider::Google#receive_tokens error:\nCode: #{code}\nBody: #{data}") unless is_ok?(code)
    write_tokens(data['access_token'], data['refresh_token']) if is_ok?(code) && data
  end

  def update_token
    return if HelpdeskSettings['helpdesk_google_refresh_token', project].blank?

    params = {
      client_id: RedmineHelpdesk.settings['helpdesk_oauth_google_client_id'],
      client_secret: RedmineHelpdesk.settings['helpdesk_oauth_google_secret'],
      refresh_token: HelpdeskSettings['helpdesk_google_refresh_token', project],
      grant_type: 'refresh_token'.freeze,
    }

    code, data = execute(:FPOST, TOKEN_URL, params)
    logged_error("HelpdeskOauthProvider::Google#update_token error:\nCode: #{code}\nBody: #{data}") unless is_ok?(code)
    if !is_ok?(code) || data.empty?
      reset_token
    else
      write_tokens(data['access_token'], HelpdeskSettings['helpdesk_google_refresh_token', project])
    end
  end

  def folders
    return [] if HelpdeskSettings[:helpdesk_username, project.id].blank?

    Rails.cache.fetch("google_folders_#{project.id}", expires_in: 1.minute) do
      params = {}
      folders_url = FOLDERS_URL.gsub('<email>', HelpdeskSettings[:helpdesk_username, project.id])

      code, data = execute(:GET, folders_url, params)
      return [] if !is_ok?(code) || !data || !data['labels']

      [['INBOX', 'INBOX']] + data['labels'].filter { |fld| fld['type'] == 'user'}.sort_by { |fld| fld['name'] }.map do |fld|
        full_path = fld['name'].split('/')
        [
          '--' * (full_path.size - 1) + ' ' + full_path.last,
          fld['id']
        ]
      end
    end
  end

  def messages(folder = nil)
    message_ids = new_message_ids(folder)
    message_ids.map do |mid|
      [mid, message_raw(mid)]
    end.to_h
  end

  def move_message(mid, folder)
    params = {
      removeLabelIds: ['INBOX'],
      addLabelIds: [folder]
    }

    read_url = message_full_url(mid) + '/modify'
    code, data = execute(:JPOST, read_url, params)
    is_ok?(code) ? data : ''
  end

  def read_message(mid)
    params = {
      removeLabelIds: ['UNREAD'],
    }

    read_url = message_full_url(mid) + '/modify'
    code, data = execute(:JPOST, read_url, params)
    is_ok?(code) ? data : ''
  end

  def send_message(encoded_message)
    params = {
      raw: encoded_message
    }

    sendmail_url = SENDMAIL_URL.gsub('<email>', HelpdeskSettings[:helpdesk_username, project.id])
    code, data = execute(:RFPOST, sendmail_url, params)
    logged_error("HelpdeskOauthProvider::Microsoft#send_message error:\nCode: #{code}\nBody: #{data}") unless is_ok?(code)
    raise SendMailError, data unless is_ok?(code)

    data
  end

  private

  def access_token_name
    :helpdesk_google_access_token
  end

  def refresh_token_name
    :helpdesk_google_refresh_token
  end

  def message_full_url(mid)
    MESSAGES_URL.gsub('<email>', HelpdeskSettings[:helpdesk_username, project.id]) + "/#{mid}"
  end

  def new_message_ids(folder)
    params = {
      maxResults: 500,
      labelIds: [folder, "UNREAD"],
      g_labels: true,
    }

    _code, data = execute_with_pages(:GET, MESSAGES_URL.gsub('<email>', HelpdeskSettings[:helpdesk_username, project.id]), params)
    (data || []).map { |mes| mes['id'] }
  end

  def message_raw(mid)
    params = {
      format: 'raw'
    }

    code, data = execute(:GET, message_full_url(mid), params)
    is_ok?(code) ? Base64.urlsafe_decode64(data['raw']) : ''
  end

  def execute_with_pages(type, url, params = {})
    total_data = []
    page_url = url
    page_params = params
    next_page = true

    while next_page
      next_page = false
      code, data = execute(type, page_url, page_params)
      if is_ok?(code) && data
        total_data += data['messages'] if data['messages']
        if data['nextPageToken']
          next_page = true
          page_params = page_params.merge(pageToken: data['nextPageToken'])
        end
      end
    end
    [code.to_i, total_data]
  end
end
