# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class HelpdeskOauthProvider::Microsoft < HelpdeskOauthProvider
  BASE_URL = 'https://login.microsoftonline.com/<tenant_id>/oauth2/v2.0/authorize'.freeze
  TOKEN_URL = 'https://login.microsoftonline.com/<tenant_id>/oauth2/v2.0/token'.freeze
  MAILBOX_URL = 'https://graph.microsoft.com/v1.0/users/<email>'.freeze
  FOLDERS_URL = MAILBOX_URL + '/mailFolders'.freeze
  MESSAGES_URL = MAILBOX_URL + '/mailFolders/<mail_folder>/messages'.freeze
  SENDMAIL_URL = MAILBOX_URL + '/sendMail'.freeze
  SCOPE = 'openid offline_access mail.readwrite mail.send mail.readwrite.shared mail.send.shared'.freeze

  def authorize_url(state_secret)
    params = {
      client_id: RedmineHelpdesk.settings['helpdesk_oauth_outlook_client_id'],
      scope: SCOPE,
      redirect_uri: redirect_uri,
      response_type: 'code'.freeze,
      response_mode: 'query'.freeze,
      state: state_secret,
    }

    clarified_url(BASE_URL) + '?' + params.to_query
  end

  def receive_tokens(code)
    params = {
      client_id: RedmineHelpdesk.settings['helpdesk_oauth_outlook_client_id'],
      client_secret: RedmineHelpdesk.settings['helpdesk_oauth_outlook_secret'],
      scope: SCOPE,
      redirect_uri: redirect_uri,
      code: code,
      grant_type: 'authorization_code'.freeze,
    }

    code, data = execute(:FPOST, clarified_url(TOKEN_URL), params)
    logged_error("HelpdeskOauthProvider::Microsoft#receive_tokens error:\nCode: #{code}\nBody: #{data}") unless is_ok?(code)
    write_tokens(data['access_token'], data['refresh_token']) if is_ok?(code) && data
  end

  def update_token
    return if HelpdeskSettings['helpdesk_outlook_refresh_token', project].blank?

    params = {
      client_id: RedmineHelpdesk.settings['helpdesk_oauth_outlook_client_id'],
      client_secret: RedmineHelpdesk.settings['helpdesk_oauth_outlook_secret'],
      refresh_token: HelpdeskSettings['helpdesk_outlook_refresh_token', project],
      grant_type: 'refresh_token'.freeze,
    }

    code, data = execute(:FPOST, clarified_url(TOKEN_URL), params)
    logged_error("HelpdeskOauthProvider::Microsoft#update_token error:\nCode: #{code}\nBody: #{data}") unless is_ok?(code)
    if !is_ok?(code) || data.empty?
      reset_token
    else
      write_tokens(data['access_token'], data['refresh_token'])
    end
  end

  def folders
    return [] if HelpdeskSettings[:helpdesk_username, project.id].blank?

    Rails.cache.fetch("outlook_folders_#{project.id}", expires_in: 1.minute) do
      folders_for(nil, 0).flatten.map {|fld| [fld[:name], fld[:id]]}
    end
  end

  def messages(folder = nil)
    message_ids = new_message_ids(folder)
    message_ids.map do |mid|
      [mid, message_raw(mid)]
    end.to_h
  end

  def move_message(mid, folder)
    params = {
      destinationId: folder
    }

    move_url = message_full_url + "/#{mid}/move"
    code, data = execute(:JPOST, move_url, params)
    is_ok?(code) ? data : ''
  end

  def read_message(mid)
    params = {
      isRead: true,
    }

    read_url = message_full_url + "/#{mid}"
    code, data = execute(:PATCH, read_url, params)
    is_ok?(code) ? data : ''
  end

  def send_message(encoded_message)
    params = {
      raw: true,
      body: encoded_message
    }

    sendmail_url = SENDMAIL_URL.gsub('<email>', HelpdeskSettings[:helpdesk_username, project.id])
    code, data = execute(:TPOST, sendmail_url, params)
    logged_error("HelpdeskOauthProvider::Microsoft#send_message error:\nCode: #{code}\nBody: #{data}") unless is_ok?(code)
    raise SendMailError, data unless is_ok?(code)

    data
  end

  private

  def access_token_name
    :helpdesk_outlook_access_token
  end

  def refresh_token_name
    :helpdesk_outlook_refresh_token
  end

  def clarified_url(url)
    tenant_id = RedmineHelpdesk.settings['helpdesk_outlook_tenant_id'].presence || 'common'
    url.gsub('<tenant_id>', tenant_id)
  end

  def message_full_url(folder = nil)
    message_url = MESSAGES_URL
    message_url = folder ? message_url.gsub('<mail_folder>', folder) : message_url.gsub('/mailFolders/<mail_folder>', '')
    message_url.gsub('<email>', HelpdeskSettings[:helpdesk_username, project.id])
  end

  def new_message_ids(folder)
    params = {
      count: true,
      filter: 'IsRead eq false',
      select: 'id',
      '$orderby': 'createdDateTime',
      '$top': 100
    }

    code, data = execute_with_pages(:GET, message_full_url(folder), params)
    (data || []).map { |mes| mes['id'] }
  end

  def message_raw(mid)
    params = {
      raw: true
    }
    raw_url = message_full_url + "/#{mid}/$value"
    code, data = execute(:GET, raw_url, params)
    is_ok?(code) ? data : ''
  end

  def folders_for(fid, level)
    params = {
      '$top': 100
    }

    folders_url = FOLDERS_URL.gsub('<email>', HelpdeskSettings[:helpdesk_username, project.id])
    folders_url += "/#{fid}/childFolders" if fid.present?

    code, data = execute_with_pages(:GET, folders_url, params)
    return [] if !is_ok?(code) || !data

    subfolders = data.map do |folder|
      {
        name: '--' * level + ' ' + folder['displayName'],
        id: folder['id'],
        descendants: folder['childFolderCount']
      }
    end
    subfolders.map { |item| [item, item[:descendants] > 0 ? folders_for(item[:id], level + 1) : []] }
  end

  def execute_with_pages(type, url, params = {})
    total_data = []
    page_url = url
    page_params = params
    next_page = true

    while next_page
      next_page = false
      code, data = execute(type, page_url, page_params)
      if is_ok?(code) && data
        total_data += data['value'] if data['value']
        if data['@odata.nextLink']
          next_page = true
          page_url = data['@odata.nextLink']
          page_params = {}
        end
      end
    end
    [code.to_i, total_data]
  end
end
