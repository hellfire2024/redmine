# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class HelpdeskTicket < ApplicationRecord
  include Redmine::SafeAttributes
  include RedmineHelpdesk::Concerns::Viewable
  include RedmineHelpdesk::Concerns::HelpdeskTicketsVisible

  HELPDESK_EMAIL_SOURCE = 0
  HELPDESK_WEB_SOURCE = 1
  HELPDESK_PHONE_SOURCE = 2
  HELPDESK_TWITTER_SOURCE = 3
  HELPDESK_CONVERSATION_SOURCE = 4

  SEND_AS_NOTIFICATION = 1
  SEND_AS_MESSAGE = 2

  safe_attributes 'vote', 'vote_comment', 'from_address',
                  'to_address', 'cc_address', 'ticket_date',
                  'message_id', 'is_incoming', 'customer', 'issue', 'source', 'contact_id', 'ticket_time'

  attr_accessor :ticket_time
  attr_accessor :is_send_mail

  belongs_to :customer, class_name: 'Contact', foreign_key: 'contact_id'
  belongs_to :issue
  has_one :message_file, class_name: 'Attachment', as: :container, dependent: :destroy
  has_many :journals, through: :issue

  acts_as_attachable view_permission: :view_issues, delete_permission: :edit_issues

  acts_as_activity_provider type: 'helpdesk_tickets',
                            timestamp: "#{table_name}.ticket_date",
                            author_key: "#{Issue.table_name}.author_id",
                            scope: joins(issue: :project)

  acts_as_event datetime: :ticket_date,
                project_key: "#{Project.table_name}.id",
                url: Proc.new { |o| { controller: 'issues', action: 'show', id: o.issue_id } },
                type: Proc.new { |o| 'icon icon-email' + (o.issue.closed? ? ' closed' : '') if o.issue },
                title: Proc.new { |o| "##{o.issue.id} (#{o.issue.status}): #{o.issue.subject}" if o.issue },
                author: Proc.new { |o|  o.customer },
                description: Proc.new { |o| o.issue.description if o.issue }

  accepts_nested_attributes_for :customer

  before_save :calculate_metrics
  validates_presence_of :customer, :ticket_date
  after_commit :set_ticket_private, on: :create

  def self.joined_model
    :issue
  end

  def initialize(attributes = nil, *args)
    super
    if new_record?
      # set default values for new records only
      self.ticket_date ||= Time.now
      self.source ||= HelpdeskTicket::HELPDESK_EMAIL_SOURCE
    end
  end

  def to_s
    l(:label_helpdesk_string, subject: issue.subject, author: customer)
  end

  def ticket_time
    self.ticket_date.strftime("%H:%M") unless self.ticket_date.blank?
  end

  def ticket_time=(val)
    if !self.ticket_date.blank? && val.to_s.gsub(/\s/, '').match(/^(\d{1,2}):(\d{1,2})$/)
      timezone_name = ticket_date.time_zone.name if ticket_date.respond_to?(:time_zone) && ticket_date.time_zone
      timezone = timezone_name || Time.zone.name
      self.ticket_date = ActiveSupport::TimeZone.new(timezone)
                                                .local_to_utc(self.ticket_date.utc)
                                                .in_time_zone(timezone)
                                                .change(hour: $1.to_i % 24, min: $2.to_i % 60)
    end
  end

  def default_to_address
    return last_response_address if last_journal_message && last_journal_message.is_incoming?

    address = from_address.blank? ? '' : from_address.downcase.strip
    (customer.emails.include?(address) ? address : customer.primary_email).downcase
  end

  def last_reply_customer
    return customer unless default_to_address

    customer.primary_email == default_to_address ? customer : Contact.find_by_emails([default_to_address]).first
  end

  def cc_addresses
    @cc_addresses = ((issue.contacts ? issue.contacts.map(&:primary_email) : []) | cc_address.to_s.split(',')).compact.uniq
  end

  def project
    issue.project if issue
  end

  def author
    issue.author if issue
  end

  def customer_name
    customer.name if customer
  end

  def responses
    @responses ||= JournalMessage.joins(:journal).
                                  where(:journals => { :journalized_id => issue_id }).
                                  order("#{JournalMessage.table_name}.message_date ASC")
  end

  def reaction_date
    @reaction_date ||= issue
      .journals
      .eager_load(:journal_message)
      .where("#{JournalMessage.table_name}.journal_id IS NULL
              OR #{JournalMessage.table_name}.is_incoming IS NULL
              OR #{JournalMessage.table_name}.is_incoming = ?", false)
      .order(:created_on)
      .first
      .try(:created_on)
      .try(:utc)
  end

  def response_addresses
    responses.where(:is_incoming => true).map { |response| response.from_address }.uniq
  end

  def first_response_date
    @first_response_date ||= responses.select { |r| !r.is_incoming? }.first.try(:message_date).try(:utc)
  end

  def last_response_time
    @last_response_time ||= last_journal_message && last_journal_message.is_incoming? && !issue.closed? ? last_journal_message.message_date.utc : nil
  end

  def last_response_address
    response_addresses.last
  end

  def last_agent_response
    @last_agent_response ||= responses.select { |r| !r.is_incoming? }.last
  end

  def last_journal_message
    @last_journal_message ||= responses.last
  end

  def last_customer_response
    @last_customer_response ||= responses.select { |r| r.is_incoming? }.last
  end

  def average_response_time
  end

  def ticket_source_name
    case self.source
    when HelpdeskTicket::HELPDESK_EMAIL_SOURCE then l(:label_helpdesk_tickets_email)
    when HelpdeskTicket::HELPDESK_PHONE_SOURCE then l(:label_helpdesk_tickets_phone)
    when HelpdeskTicket::HELPDESK_WEB_SOURCE then l(:label_helpdesk_tickets_web)
    when HelpdeskTicket::HELPDESK_TWITTER_SOURCE then l(:label_helpdesk_tickets_twitter)
    when HelpdeskTicket::HELPDESK_CONVERSATION_SOURCE then l(:label_helpdesk_tickets_conversation)
    else ''
    end
  end

  def ticket_source_icon
    case self.source
    when HelpdeskTicket::HELPDESK_EMAIL_SOURCE then 'icon-email'
    when HelpdeskTicket::HELPDESK_PHONE_SOURCE then 'icon-call'
    when HelpdeskTicket::HELPDESK_WEB_SOURCE then 'icon-web'
    when HelpdeskTicket::HELPDESK_TWITTER_SOURCE then 'icon-twitter'
    else 'icon-helpdesk'
    end
  end

  def content
    issue.description if issue
  end

  def customer_email
    customer.primary_email if customer
  end

  def last_message
    @last_message ||= JournalMessage.eager_load(:journal => :issue).where(:issues => { :id => issue.id }).order("#{Journal.table_name}.created_on ASC").last || self
  end

  def last_message_date
    last_message.is_a?(HelpdeskTicket) ? self.ticket_date : last_message.message_date if last_message
  end

  def ticket_date
    return nil if super.blank?

    zone = User.current.time_zone
    zone ? super.in_time_zone(zone) : (super.utc? ? super.localtime : super)
  end

  def token
    secret = Rails.application.secret_key_base || Rails.application.config.secret_token
    Digest::MD5.hexdigest("#{issue.id}:#{self.ticket_date.utc}:#{secret}")
  end

  def calculate_metrics
    self.reaction_time = reaction_date - ticket_date.utc if reaction_date && ticket_date
    self.first_response_time = first_response_date - ticket_date.utc if first_response_date && ticket_date
    self.resolve_time = self.issue.closed? ? self.issue.closed_on - ticket_date.utc : nil if ticket_date && issue.closed_on && last_agent_response
    self.last_agent_response_at = last_agent_response.message_date if last_agent_response
    self.last_customer_response_at = last_customer_response.message_date if last_customer_response
  end

  def self.vote_message(vote)
    case vote.to_i
    when 0
      l(:label_helpdesk_mark_notgood)
    when 1
      l(:label_helpdesk_mark_justok)
    when 2
      l(:label_helpdesk_mark_awesome)
    else
      ''
    end
  end

  def update_vote(new_vote, comment = nil)
    old_vote = vote
    old_vote_comment = vote_comment
    if update(vote: new_vote, vote_comment: comment)
      if old_vote != vote || old_vote_comment != vote_comment
        journal = Journal.new(:journalized => issue, :user => User.current)
        journal.details << JournalDetail.new(:property => 'attr',
                                             :prop_key => 'vote',
                                             :old_value => old_vote,
                                             :value => vote) if old_vote != vote
        journal.details << JournalDetail.new(:property => 'attr',
                                             :prop_key => 'vote_comment',
                                             :old_value => old_vote_comment,
                                             :value => vote_comment) if old_vote_comment != vote_comment
        journal.save
      end
    end
  end

  def self.autoclose(project)
    return unless RedmineHelpdesk.autoclose_tickets_after > 0

    pids = [project.id] + project.children.select { |ch| ch.module_enabled?(:contacts_helpdesk) }.map(&:id)
    issues = Issue.includes(:journals, :helpdesk_ticket).where(project_id: pids).
                                                         where(status_id: RedmineHelpdesk.autoclose_from_status)
    issues.find_each do |issue|
      last_event = [issue.created_on, (issue.journals.order(:created_on).last.try(:created_on) || Time.now)].max
      next if last_event > Time.now - RedmineHelpdesk.autoclose_time_interval

      issue.init_journal(User.anonymous)
      issue.current_journal.notes = I18n.t('label_helpdesk_autoclosed_ticket')
      issue.status_id = RedmineHelpdesk.autoclose_to_status
      issue.save

      HelpdeskMailer.autoclose_message(issue.customer, issue)
    end
  end

  def set_ticket_private
    return unless RedmineHelpdesk.assign_contact_user?

    if RedmineHelpdesk.create_private_tickets?
      issue.persisted? ? issue.reload.update(is_private: true) : issue.is_private = true
    end
  end

  def self.send_reply_by_issue(issue, params = {})
    unless params.empty?
      issue.helpdesk_ticket.is_send_mail = params[:helpdesk][:is_send_mail]
      issue.current_journal.build_journal_message
      if params[:journal_message]
        message_params = params.respond_to?(:to_unsafe_hash) ? params.to_unsafe_hash['journal_message'] : params[:journal_message]
        journal_params = message_params.merge(Hash[message_params.slice('to_address', 'cc_address', 'bcc_address').map { |k, v| [k, v.join(',')] }])
        issue.current_journal.journal_message.safe_attributes = journal_params
        issue.current_journal.journal_message.save
      end

      issue.current_journal.journal_message.to_address ||= issue.customer.primary_email
      issue.current_journal.is_send_note = true
      issue.current_journal.notes = HelpdeskMailSupport.apply_text_macro(issue.current_journal.notes, issue.customer, issue, User.current)
    end
  end

  def duplicates(limit=10)
    issue = self.issue

    cond = <<-SQL
        ((1=1) 
          AND LOWER(#{HelpdeskTicket.table_name}.from_address) LIKE LOWER(?)
          AND #{Issue.table_name}.id <> #{issue.id}
        )
    SQL
    scope = Issue.visible.joins(:helpdesk_ticket).where(cond, self.from_address.to_s.strip)
    @duplicates ||= scope.limit(limit)
  end

  def self.custom_fields_validation(ticket)
    target_issue = ticket.is_a?(Issue) ? ticket : ticket.issue
    return if target_issue.custom_field_values.count.zero?

    required_custom_fields = {}
    ticket.custom_field_values.each do |cfv|
      required_custom_fields[cfv.custom_field.name] = cfv.validate_value unless cfv.validate_value.blank?
    end
    required_custom_fields.present?
  end

  def merge_into(ticket)
    @source_ticket = self.issue
    @target_ticket = ticket.issue

    begin
      @target_ticket.description = "#{@target_ticket.description}\n-----\n\n#{@source_ticket.description}"
      @target_ticket.journals << @source_ticket.journals
      source_addresses = @source_ticket.helpdesk_ticket.cc_addresses
      source_addresses << @source_ticket.helpdesk_ticket.from_address
      source_addresses << @source_ticket.customer.emails
      source_addresses = source_addresses.flatten.uniq
      target_addresses = @target_ticket.helpdesk_ticket.cc_addresses | [@source_ticket.helpdesk_ticket.from_address]
      target_addresses = target_addresses.flatten.uniq
      @target_ticket.helpdesk_ticket.cc_address = (target_addresses | source_addresses).join(',')

      Issue.transaction do
        @target_ticket.save!
        @target_ticket.reload
        @source_ticket.reload
        @source_ticket.destroy
      end
    rescue
      # Should it be registered in the log?
      false
    end

    true
  end

  def self.find_duplicate(params, limit=10)
    query = params[:q].strip
    issues = []
    condition = <<-SQL
LOWER(#{Issue.table_name}.subject) LIKE LOWER(:search)
OR LOWER(#{HelpdeskTicket.table_name}.from_address) LIKE LOWER(:search)
OR LOWER(#{Contact.table_name}.email) LIKE LOWER(:search)
    SQL

    scope = Issue.joins(helpdesk_ticket: :customer)
    scope = scope.where("#{Issue.table_name}.id <> ?", params[:id].to_i) if params[:id].present?
    if query =~ /\A#?(\d+)\z/
      issues << scope.where("#{Issue.table_name}.id = #{$1.to_i}").first
    end
    scope = scope.where(condition, search: "%#{query}%")
    issues += scope.visible.order(id: :desc).limit(limit).to_a
    issues.compact!
    issues.uniq
  end
end
