# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class HelpdeskTicketQuery < Query
  self.queried_class = HelpdeskTicket
  self.view_permission = :view_helpdesk_tickets

  def initialize(attributes=nil, *args)
    super attributes
    self.filters ||= { }
  end

  def initialize_available_filters
    add_available_filter "ticket_date", :type => :date_past
  end

  def build_from_params(params, defaults={})
    super
    @params = params
    self
  end

  def tickets(options = {})
    scope = base_scope
    scope = scope.joins(issue: { journals: :journal_message }) if @params[:include] && (%w[journals] & @params[:include].split(',')).any?
    scope = scope.where("contact_id IN (?)", @params[:contact_id].split(',')) if @params[:contact_id]
    scope = scope.where("issue_id IN (?)", @params[:issue_id].split(',')) if @params[:issue_id]
    scope = scope.where("source = ?", @params[:source]) if @params[:source]
    scope = scope.where("from_address = ?", @params[:from_address]) if @params[:from_address]
    scope = scope.where("message_id = ?", @params[:message_id]) if @params[:message_id]
    scope.limit(options[:limit])
         .offset(options[:offset])
  end

  def tickets_count
    tickets.count
  end

  private

  def base_scope
    HelpdeskTicket.where(statement)
  end
end
