# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class JournalMessage < ApplicationRecord
  include Redmine::SafeAttributes
  include RedmineHelpdesk::Concerns::Viewable
  include RedmineHelpdesk::Concerns::HelpdeskTicketsVisible

  belongs_to :contact
  belongs_to :journal
  has_one :message_file, class_name: 'Attachment', as: :container, dependent: :destroy

  safe_attributes 'source', 'from_address', 'to_address', 'bcc_address', 'cc_address', 'message_id', 'is_incoming', 'message_date', 'contact', 'journal'

  acts_as_attachable view_permission: :view_issues,
                     delete_permission: :edit_issues

  acts_as_activity_provider type: 'helpdesk_tickets',
                            permission: :view_helpdesk_tickets,
                            timestamp: "#{table_name}.message_date",
                            author_key: "#{Journal.table_name}.user_id",
                            scope: eager_load({ journal: [{ issue: [:project, :tracker] }, :details, :user] }, :contact)

  acts_as_event title: Proc.new { |o| "#{o.journal.issue.tracker} ##{o.journal.issue.id}: #{o.journal.issue.subject}" if o.journal && o.journal.issue },
                datetime: :message_date,
                group: :helpdesk_ticket,
                project_key: "#{Project.table_name}.id",
                url: Proc.new { |o| { controller: 'issues', action: 'show', id: o.journal.issue.id, anchor: "change-#{o.id}" } if o.journal },
                type: Proc.new { |o| ('icon' + (o.is_incoming? ? ' icon-email' : ' icon-email-to')) },
                author: Proc.new { |o|  o.is_incoming? ? o.contact : o.journal.user },
                description: Proc.new { |o| o.journal.notes if o.journal }

  validates_presence_of :contact, :journal, :message_date

  def self.joined_model
    :journal
  end

  def project
    journal.project
  end

  def contact_name
    contact.name
  end

  def contact_email
    contact.emails.first
  end

  def helpdesk_ticket
    journal.issue.helpdesk_ticket
  end

  def content
    journal.notes
  end
end
