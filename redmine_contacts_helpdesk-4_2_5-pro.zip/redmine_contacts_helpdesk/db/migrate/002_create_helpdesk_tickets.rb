# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class CreateHelpdeskTickets < ActiveRecord::Migration[4.2]
  def self.up
    create_table :helpdesk_tickets do |t|
      t.references :contact
      t.references :issue
      t.integer :source, :null => false, :default => HelpdeskTicket::HELPDESK_EMAIL_SOURCE
      t.string :from_address
      t.string :to_address
      t.datetime :ticket_date
    end
    add_index :helpdesk_tickets, [:issue_id, :contact_id]

    remove_index :contact_journals, [:journal_id, :contact_id]
    rename_table :contact_journals, :journal_messages
    add_index :journal_messages, [:journal_id, :contact_id]

    change_table :journal_messages do |t|
      t.remove :created_at, :updated_at
      t.integer :source, :null => false, :default => HelpdeskTicket::HELPDESK_EMAIL_SOURCE
      t.string :from_address
      t.string :to_address
      t.string :bcc_address
      t.string :cc_address
      t.datetime :message_date
    end

    JournalMessage.where(:is_incoming => true).update_all("from_address = email")
    JournalMessage.where(:is_incoming => false).update_all("to_address = email")

    remove_column :journal_messages, :email
    Attachment.where(:container_type => 'ContactJournal').update_all(:container_type => 'JournalMessage')

  end

  def self.down
    Attachment.where(:container_type => 'JournalMessage').update_all(:container_type => 'ContactJournal')
    drop_table :helpdesk_tickets
    add_column :journal_messages, :email, :string

    JournalMessage.where(:is_incoming => true).update_all("email = from_address")
    JournalMessage.where(:is_incoming => false).update_all("email = to_address")

    change_table :journal_messages do |t|
      t.timestamps
      t.remove :source, :from_address, :to_address, :bcc_address, :cc_address, :message_date
    end

    rename_table :journal_messages, :contact_journals

  end
end

