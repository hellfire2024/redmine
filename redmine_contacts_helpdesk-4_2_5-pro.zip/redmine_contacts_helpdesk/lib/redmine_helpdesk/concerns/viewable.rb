# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

module RedmineHelpdesk
  module Concerns
    module Viewable
      extend ActiveSupport::Concern

      included do
        before_create :calculate_view_id

        scope :not_viewed, -> { where(viewed_on: nil) }
      end

      def viewed?
        RedmineHelpdesk.add_readmark? && viewed_on.present?
      end

      def calculate_view_id
        return view_id if view_id
        loop do
          self.view_id = SecureRandom.urlsafe_base64(16, false)
          break if self.class.where(view_id: view_id).empty?
        end
        view_id
      end
    end
  end
end
