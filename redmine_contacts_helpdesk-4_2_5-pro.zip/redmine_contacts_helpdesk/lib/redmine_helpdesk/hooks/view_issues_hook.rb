# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

module RedmineHelpdesk
  module Hooks
    class ViewIssuesHook < Redmine::Hook::ViewListener
      render_on :view_issues_edit_notes_bottom, :partial => 'issues/send_response'
      render_on :view_issues_context_menu_end, partial: 'context_menus/merge_tickets'

      def view_issues_sidebar_issues_bottom(context = {})
        context[:controller].send(:render_to_string, { :partial => 'issues/helpdesk_reports', :locals => context }) +
          context[:controller].send(:render_to_string, { :partial => 'issues/helpdesk_customer_profile', :locals => context })
      end

      def view_issues_show_details_bottom(context={})
        ticket_data = context[:controller].send(:render_to_string, {partial: 'issues/ticket_data', :locals => context})
        merge_ticket = context[:controller].send(:render_to_string, {partial: 'issues/dropdown_merge_link', locals: {}})
        context[:issue].is_ticket? ? ticket_data + merge_ticket : ticket_data
      end

      render_on :view_issues_form_details_top, :partial => 'issues/ticket_data_form'
    end
  end
end
