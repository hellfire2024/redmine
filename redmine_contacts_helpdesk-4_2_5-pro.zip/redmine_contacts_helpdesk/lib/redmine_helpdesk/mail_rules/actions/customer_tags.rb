# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

module RedmineHelpdesk
  module MailRules
    module Actions
      class CustomerTags < BaseAction
        def field
          'customer_tags'
        end

        def options
          {
            type: :contact_tags,
            name: l(:label_helpdesk_mail_rule_action_contact_tags)
          }
        end

        def apply(container, operator, value)
          return if container.nil? || container.contact.nil?
          container.contact.tag_list = splitted_values(value)
          container.contact.save
        end

        def values(rule_instance = nil)
          return [] unless rule_instance

          rule_instance.action_values_for(field)
        end
      end
    end
  end
end

HelpdeskMailRule.add_action(RedmineHelpdesk::MailRules::Actions::CustomerTags)
