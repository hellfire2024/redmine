# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

module RedmineHelpdesk
  module MailRules
    module Actions
      class Watchers < BaseAction
        def field
          'watchers'
        end

        def options
          {
            type: :assignee,
            name: l(:label_helpdesk_mail_rule_action_watchers)
          }
        end

        def values(rule_instance = nil)
          return [] unless rule_instance

          assignee_classes = ['User']
          assignee_classes << 'Group' if Setting.issue_group_assignment?
          ::Principal.where(type: assignee_classes)
                     .where(id: rule_instance.action_values_for(field)).map { |user| [user.name, user.id.to_s] }
        end

        def label_for(action_options)
          ::Principal.where(id: action_options[:values]).map(&:name).join(', ')
        end

        def apply(container, operator, value)
          return if container.nil? || container.issue.nil?

          container.issue.watcher_user_ids = value
          container.issue.send(:send_notification)
        end
      end
    end
  end
end

HelpdeskMailRule.add_action(RedmineHelpdesk::MailRules::Actions::Watchers)
