# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

module RedmineHelpdesk
  module MailRules
    module Conditions
      class ContactTags < BaseCondition
        def field
          'contact_tags'
        end

        def options
          {
            type: :contact_tags,
            name: l(:label_helpdesk_mail_rule_condition_contact_tags)
          }
        end

        def check(container, operator, values)
          contact = container.try(:contact)
          return false if contact.nil? || !contact.is_a?(::Contact)
          tags = contact.tag_list.sort
          values = splitted_values(values).sort
          case operator
          when '='
            tags == values
          when '~'
            (values - tags).empty?
          when '!', '!~'
            (tags - values) == tags
          when '!*'
            tags.empty?
          when '*'
            tags.present?
          else
            false
          end
        end

        def values(rule_instance = nil)
          return [] unless rule_instance

          rule_instance.condition_values_for(field)
        end
      end
    end
  end
end

HelpdeskMailRule.add_condition(RedmineHelpdesk::MailRules::Conditions::ContactTags)
