# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

module RedmineHelpdesk
  module Patches
    module MailHandlerPatch
      def self.included(base)
        base.send(:include, InstanceMethods)

        base.class_eval do
          alias_method :receive_issue_reply_without_helpdesk, :receive_issue_reply
          alias_method :receive_issue_reply, :receive_issue_reply_with_helpdesk
          alias_method :cleanup_body_without_helpdesk, :cleanup_body
          alias_method :cleanup_body, :cleanup_body_with_helpdesk
          alias_method :dispatch_without_helpdesk, :dispatch
          alias_method :dispatch, :dispatch_with_helpdesk
          alias_method :add_attachments_without_helpdesk, :add_attachments
          alias_method :add_attachments, :add_attachments_with_helpdesk
          alias_method 'accept_attachment?_without_helpdesk', :accept_attachment?
          alias_method :accept_attachment?, 'accept_attachment?_with_helpdesk'

          private :receive_issue_reply
        end
      end

      module InstanceMethods
        def substitution_method(method, email = nil, user = nil, *args)
          @email = email if email
          @user = user if user
          args.blank? ? send(method) : send(method, *args)
        end

        private

        def receive_issue_reply_with_helpdesk(issue_id, from_journal = nil)
          journal = receive_issue_reply_without_helpdesk(issue_id, from_journal)
          helpdesk_receive_issue_reply(issue_id, journal, from_journal)
        end

        def dispatch_with_helpdesk
          if email_tag
            tag_issue = Issue.where(:id => email_tag[/\+(\d+)@/, 1].to_i).first
            return dispatch_without_helpdesk unless tag_issue
            receive_issue_reply(tag_issue.id)
          else
            dispatch_without_helpdesk
          end
        rescue MailHandler::MissingInformation => e
          logger.error "#{email && email.message_id}: missing information from #{user}: #{e.message}" if logger
          false
        rescue MailHandler::UnauthorizedAction => e
          logger.error "#{email && email.message_id}: unauthorized attempt from #{user}" if logger
          false
        rescue Exception => e
          # TODO: send a email to the user
          logger.error "#{email && email.message_id}: dispatch error #{e.message}" if logger
          false
        end

        def email_tag
          (email.to.present? && email.to.find { |email| email.match(/\+\d+@/) }) ||
            (email.cc.present? && email.cc.find { |email| email.match(/\+\d+@/) })
        end

        def helpdesk_receive_issue_reply(_issue_id, journal, _from_journal = nil)
          return unless journal
          return journal if journal.notes.blank?
          project = journal.issue.project
          return journal unless journal.user.allowed_to?(:send_response, journal.issue.project) && journal.issue.customer

          unless HelpdeskSettings['send_note_by_default', project]
            regexp = /^@@sendmail@@\s*$/
            return journal unless journal.notes.match(regexp)
            journal.notes = journal.notes.gsub(regexp, '')
          end

          contact = journal.issue.customer
          begin
            if msg = HelpdeskMailer.issue_response(contact, journal)
              JournalMessage.create(:to_address => msg.to_addrs.first.to_s.slice(0, 255),
                                    :is_incoming => false,
                                    :message_date => Time.now,
                                    :message_id => msg.message_id.to_s.slice(0, 255),
                                    :source => HelpdeskTicket::HELPDESK_EMAIL_SOURCE,
                                    :cc_address => msg.cc.join(', ').to_s.slice(0, 255),
                                    :bcc_address => msg.bcc.join(', ').to_s.slice(0, 255),
                                    :contact => contact,
                                    :journal => journal)
              journal.issue.assigned_to = User.current unless journal.issue.assigned_to
              unless ContactsSetting[:helpdesk_answered_status, journal.issue.project_id].blank?
                # journal.details.new({
                #                                 property: "attr",
                #                                 prop_key: "status_id",
                #                                 old_value: journal.issue.status_id,
                #                                 value: ContactsSetting[:helpdesk_answered_status, journal.issue.project_id]
                #                             }).save
                journal.issue.status_id = ContactsSetting[:helpdesk_answered_status, journal.issue.project_id]
              end
              journal.issue.save
              HelpdeskLogger.info "#{msg.message_id}: Replay sent to #{contact.name} - [#{contact.emails.first}]" if HelpdeskLogger
            end
          rescue Exception => e
            HelpdeskLogger.info "Error of replay sending to #{contact.name} - [#{contact.emails.first}], #{e.message}" if HelpdeskLogger
          end

          journal.save!
          journal
        end

        def cleanup_body_with_helpdesk(body)
          cleanup_body_without_helpdesk(body.gsub("\r", '')).gsub('&#13;', '')
        end

        def add_attachments_with_helpdesk(obj)
          @attachment_object = obj
          add_attachments_without_helpdesk(obj)
          @attachment_object = nil
        end

        define_method('accept_attachment?_with_helpdesk') do |attachment|
          return if  @attachment_object && @attachment_object.attachments.where(digest: HelpdeskMailSupport.attachment_digest(attachment.body.to_s)).any?

          send('accept_attachment?_without_helpdesk', attachment)
        end
      end
    end
  end
end

unless MailHandler.included_modules.include?(RedmineHelpdesk::Patches::MailHandlerPatch)
  MailHandler.send(:include, RedmineHelpdesk::Patches::MailHandlerPatch)
end
