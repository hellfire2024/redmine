# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

require_dependency 'queries_helper'

module RedmineHelpdesk
  module Patches
    module ProjectsHelperPatch
      def self.included(base)
        base.send(:include, InstanceMethods)

        base.class_eval do
          alias_method :project_settings_tabs_without_helpdesk, :project_settings_tabs
          alias_method :project_settings_tabs, :project_settings_tabs_with_helpdesk
        end
      end

      module InstanceMethods
        def project_settings_tabs_with_helpdesk
          tabs = project_settings_tabs_without_helpdesk

          helpdesk_tabs = []
          helpdesk_tabs.push({ :name => 'helpdesk',
                               :action => :edit_helpdesk_settings,
                               :partial => 'projects/settings/helpdesk_settings',
                               :label => :label_helpdesk })
          helpdesk_tabs.push({ :name => 'helpdesk_template',
                               :action => :edit_helpdesk_settings,
                               :partial => 'projects/settings/helpdesk_template',
                               :label => :label_helpdesk_template })

          helpdesk_tabs.each { |tab| tabs << tab if User.current.allowed_to?(tab[:action], @project) }

          if User.current.allowed_to?(:manage_canned_responses, @project) || User.current.allowed_to?(:manage_public_canned_responses, @project)
            tabs.push({ :name => 'helpdesk_canned_responses',
                                 :action => :manage_canned_responses,
                                 :partial => 'projects/settings/helpdesk_canned_responses',
                                 :label => :label_helpdesk_canned_response_plural })
          end

          tabs
        end
      end
    end
  end
end

unless ProjectsHelper.included_modules.include?(RedmineHelpdesk::Patches::ProjectsHelperPatch)
  ProjectsHelper.send(:include, RedmineHelpdesk::Patches::ProjectsHelperPatch)
end
