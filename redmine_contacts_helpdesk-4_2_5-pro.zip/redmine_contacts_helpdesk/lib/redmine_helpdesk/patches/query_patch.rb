# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

module RedmineHelpdesk
  module Patches
    module QueryPatch
      def self.included(base)
        base.class_eval do
          operators_by_filter_type[:date_with_labels] = ["=", "t", "nd", "da"]
          operators["da"] = :label_helpdesk_days_after
        end
      end
    end
  end
end

unless Query.included_modules.include?(RedmineHelpdesk::Patches::QueryPatch)
  Query.send(:include, RedmineHelpdesk::Patches::QueryPatch)
end
