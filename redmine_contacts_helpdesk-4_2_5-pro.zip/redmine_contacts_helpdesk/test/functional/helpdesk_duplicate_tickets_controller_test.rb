# encoding: utf-8
#
# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class HelpdeskDuplicateTicketsControllerTest < ActionController::TestCase
  fixtures :projects,
           :users,
           :roles,
           :members,
           :member_roles,
           :issues,
           :issue_statuses,
           :versions,
           :trackers,
           :projects_trackers,
           :issue_categories,
           :enabled_modules,
           :enumerations,
           :attachments,
           :workflows,
           :custom_fields,
           :custom_values,
           :custom_fields_projects,
           :custom_fields_trackers,
           :time_entries,
           :journals,
           :journal_details,
           :queries

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts).directory + '/test/fixtures/', [:contacts,
                                                                                                                    :contacts_projects,
                                                                                                                    :deals,
                                                                                                                    :notes,
                                                                                                                    :tags,
                                                                                                                    :taggings,
                                                                                                                    :queries])

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts_helpdesk).directory + '/test/fixtures/', [:journal_messages,
                                                                                                                             :helpdesk_tickets])

  def setup
    RedmineHelpdesk::TestCase.prepare
    User.current = nil
  end

  def test_show_merge_tickets_page
    @request.session[:user_id] = 1
    issue = Issue.find(1)

    assert_not_nil issue.helpdesk_ticket

    compatible_request :get, :index, id: issue.id, project_id: issue.project.id
    assert_response :success
    assert_match /#{issue.subject}/, @response.body
    assert_match /#{issue.helpdesk_ticket.from_address}/, @response.body
  end

  def test_should_not_show_merge_tickets_page_without_permissions
    @request.session[:user_id] = 2
    issue = Issue.find(1)

    assert_not_nil issue.helpdesk_ticket

    compatible_request :get, :index, id: issue.id, project_id: issue.project.id
    assert_response 403
  end

  def test_should_not_show_merge_tickets_page_without_ticket
    @request.session[:user_id] = 1
    issue = Issue.find(3)

    assert_nil issue.helpdesk_ticket

    compatible_request :get, :index, id: issue.id, project_id: issue.project.id
    assert_response 404
  end

  def test_should_show_default_duplicates_by_contact_email
    @request.session[:user_id] = 1
    issue = Issue.find(1)
    compatible_request :get, :index, id: issue.id, project_id: issue.project.id
    assert_response :success
    assert_select 'div.source-ticket-head h3', text: "#{issue.subject}"
    assert_select 'div.target-ticket span.target-ticket-subject', count: 2
  end

  def test_search_should_return_result_by_issue_id
    @request.session[:user_id] = 1
    source_ticket = Issue.find(1)
    target_ticket = Issue.find(2)

    compatible_request :get, :search, id: source_ticket.id, q: target_ticket.id
    assert_response :success
    assert_select "li#ticket-#{target_ticket.id} span.target-ticket-subject", text: "#{target_ticket.subject}", count: 1
  end

  def test_search_should_return_result_by_email
    @request.session[:user_id] = 1
    source_ticket = Issue.find(1)
    target_ticket = Issue.find(2)

    compatible_request :get, :search, id: source_ticket.id, q: target_ticket.helpdesk_ticket.from_address
    assert_response :success
    assert_select "li#ticket-#{target_ticket.id} span.target-ticket-subject", text: "#{target_ticket.subject}", count: 1
  end

  def test_search_should_return_result_by_issue_subject
    @request.session[:user_id] = 1
    source_ticket = Issue.find(1)
    target_ticket = Issue.find(2)

    compatible_request :get, :search, id: source_ticket.id, q: target_ticket.subject.first(10)
    assert_response :success
    assert_select "li#ticket-#{target_ticket.id} span.target-ticket-subject", text: "#{target_ticket.subject}", count: 1
  end

  def test_should_merge_tickets
    @request.session[:user_id] = 1
    source_ticket = Issue.find(1)
    target_ticket = Issue.find(2)

    merged_journals_count = source_ticket.journals.count + target_ticket.journals.count
    merged_addresses = []
    merged_addresses << source_ticket.helpdesk_ticket.from_address
    merged_addresses += source_ticket.helpdesk_ticket.cc_addresses
    merged_addresses += source_ticket.helpdesk_ticket.customer.emails
    merged_addresses.uniq!
    merged_description = "#{target_ticket.description}\r\n-----\r\n\r\n#{source_ticket.description}"

    assert_difference 'Issue.count', -1 do
      assert_no_difference 'Journal.count' do
        compatible_request :post, :merge,
                           id: source_ticket.id,
                           duplicate_id: target_ticket.id,
                           project_id:  source_ticket.project.id
      end
    end
    assert_redirected_to controller: 'issues', action: 'show', id: target_ticket.id

    assert_equal merged_journals_count, target_ticket.reload.journals.count
    assert_equal merged_description, target_ticket.reload.description
    assert_equal merged_addresses.sort, target_ticket.reload.helpdesk_ticket.cc_addresses.sort
  end

  def test_should_not_merge_tickets_without_permissions
    @request.session[:user_id] = 2
    source_ticket = Issue.find(1)
    target_ticket = Issue.find(2)

    assert_not_nil source_ticket.helpdesk_ticket
    assert_not_nil target_ticket.helpdesk_ticket

    compatible_request :post, :merge,
                       id: source_ticket.id,
                       duplicate_id: target_ticket.id,
                       project_id:  source_ticket.project.id
    assert_response 403
  end
end
