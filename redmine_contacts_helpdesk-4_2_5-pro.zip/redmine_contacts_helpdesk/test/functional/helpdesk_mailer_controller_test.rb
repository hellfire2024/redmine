# encoding: utf-8
#
# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

# Re-raise errors caught by the controller.
# class HelpdeskMailerController; def rescue_action(e) raise e end; end

class HelpdeskMailerControllerTest < ActionController::TestCase
  include RedmineHelpdesk::TestHelper

  fixtures :projects,
           :users,
           :roles,
           :members,
           :member_roles,
           :issues,
           :issue_statuses,
           :versions,
           :trackers,
           :projects_trackers,
           :issue_categories,
           :enabled_modules,
           :enumerations,
           :attachments,
           :workflows,
           :custom_fields,
           :custom_values,
           :custom_fields_projects,
           :custom_fields_trackers,
           :time_entries,
           :journals,
           :journal_details,
           :queries

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts).directory + '/test/fixtures/', [:contacts,
                                                                                                                    :contacts_projects,
                                                                                                                    :deals,
                                                                                                                    :notes,
                                                                                                                    :tags,
                                                                                                                    :taggings,
                                                                                                                    :queries])

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts_helpdesk).directory + '/test/fixtures/', [:journal_messages,
                                                                                                                             :helpdesk_mail_rules])

  FIXTURES_PATH = File.dirname(__FILE__) + '/../fixtures/helpdesk_mailer'

  def setup
    RedmineHelpdesk::TestCase.prepare
    User.current = nil

    # Enable API and set a key
    Setting.mail_handler_api_enabled = 1
    Setting.mail_handler_api_key = 'secret'
  end

  def test_should_create_issue
    compatible_request :post, :index, :key => 'secret', :issue => { :project_id => 'ecookbook', :status => 'Closed', :tracker => 'Bug', :assigned_to => 'jsmith' }, :email => IO.read(File.join(FIXTURES_PATH, 'new_issue_new_contact.eml'))
    assert_response 201
    assert_not_nil Contact.find_by_first_name('New')
  end

  def test_should_create_issue_from_mailhandler
    compatible_request :post, :index, :key => 'secret', :issue => { :project => 'ecookbook', :status => 'Closed', :tracker => 'Bug', :priority => 'low' }, :email => IO.read(File.join(FIXTURES_PATH, 'new_issue_new_contact.eml'))
    assert_response 201
    assert_not_nil Contact.find_by_first_name('New')
  end

  def test_should_use_project_helpdesk_settings_for_issue
    # Project settings
    ContactsSetting['helpdesk_answer_from', Project.find('ecookbook').id] = 'test@email.from'
    ContactsSetting['helpdesk_send_notification', Project.find('ecookbook').id] = 1
    ContactsSetting['helpdesk_assigned_to', Project.find('ecookbook').id] = 2
    ContactsSetting[:helpdesk_issue_due_date, Project.find('ecookbook').id] = Date.today + 5
    ActionMailer::Base.deliveries.clear
    @request.session[:user_id] = 1

    compatible_request :post, :index, :key => 'secret', :issue => { :project => 'ecookbook' }, :email => IO.read(File.join(FIXTURES_PATH, 'new_issue_new_contact.eml'))
    assert_response 201

    issue = Issue.last
    assert_equal 'Normal', issue.priority.name
    assert_equal Date.today + 5, issue.due_date
    assert_equal User.find(2).login, issue.assigned_to.login
    contact = issue.customer
    assert_equal 'New', contact.first_name
  end

  def test_should_get_mail
    compatible_request :post, :get_mail, :key => 'secret'
    assert_response :ok
  end

  def test_should_change_state_for_ticket_on_reply
    project = Project.find_by_identifier('subproject1')
    issue = Issue.find(5)

    ContactsSetting['helpdesk_reopen_status', project.id] = IssueStatus.where(:name => 'Feedback').first.id

    assert_not_equal 'Feedback', issue.status.name
    compatible_request :post, :index, :key => 'secret', :issue => { :project => 'subproject1' }, :email => IO.read(File.join(FIXTURES_PATH, 'reply_from_contact.eml'))

    issue.reload
    assert_equal 'Feedback', issue.status.name
  end

  def test_should_apply_mail_rules_on_create_issue
    compatible_request :post, :index, :key => 'secret', :issue => { :project_id => 'ecookbook', :status => 'New', :tracker => 'Bug', :assigned_to => 'admin' }, :email => IO.read(File.join(FIXTURES_PATH, 'new_with_email_rule_text.eml'))
    assert_response 201

    issue = Issue.last
    assert_equal IssueStatus.find(5), issue.status
    assert_equal IssuePriority.find(6), issue.priority
    assert_equal User.find(3), issue.assigned_to
  end

  def test_should_receive_email_without_content_type
    compatible_request :post, :index, :key => 'secret', :issue => { :project => 'ecookbook' }, :email => IO.read(File.join(FIXTURES_PATH, 'email_without_content_type.eml'))

    issue = Issue.last
    assert_equal 'New', issue.status.name
    assert_equal 'Excessive emailing - SRV some1.domen.host-NGINX', issue.subject
  end

  def test_should_replace_inline_images_from_ms_office_inside_email_body
    compatible_request :post, :index, :key => 'secret', :issue => { :project => 'ecookbook' }, :email => IO.read(File.join(FIXTURES_PATH, 'new_issue_with_inline_img_msoffice.eml'))

    issue = Issue.last
    assert_match /!image001.png!/, issue.description
    assert_match /!image002.png!/, issue.description
  end

  def test_should_replace_two_inline_images_from_ms_office_inside_email_body
    compatible_request :post, :index, :key => 'secret', :issue => { :project => 'ecookbook' }, :email => IO.read(File.join(FIXTURES_PATH, 'new_issue_with_two_inline_imgs_msoffice.eml'))

    issue = Issue.last
    assert_match /!image001.png!/, issue.description
    assert_match /!image002.png!/, issue.description
  end

  def test_should_replace_inline_images_from_gmail_inside_email_body
    compatible_request :post, :index, :key => 'secret', :issue => { :project => 'ecookbook' }, :email => IO.read(File.join(FIXTURES_PATH, 'new_issue_with_inline_img_gmail.eml'))

    issue = Issue.last
    assert_match /!image.png!/, issue.description
  end

  def test_should_replace_two_inline_images_from_gmail_inside_email_body
    compatible_request :post, :index, :key => 'secret', :issue => { :project => 'ecookbook' }, :email => IO.read(File.join(FIXTURES_PATH, 'new_issue_with_two_inline_imgs_gmail.eml'))

    issue = Issue.last
    assert_match /!image 1.png!/, issue.description
    assert_match /!image2.png!/, issue.description
  end

  def test_should_replace_inline_images_inside_webpart_email_body
    with_helpdesk_settings('helpdesk_html_body_prefer' => 1) do
      compatible_request :post, :index, :key => 'secret', :issue => { :project => 'ecookbook' }, :email => IO.read(File.join(FIXTURES_PATH, 'new_issue_with_inline_img_msoffice.eml'))

      issue = Issue.last
      assert_match /"image001.png"/, issue.description
      assert_match /"image002.png"/, issue.description
    end
  end
end
