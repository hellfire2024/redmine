# encoding: utf-8
#
# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class HelpdeskTicketsControllerTest < ActionController::TestCase

  fixtures :projects,
           :users,
           :roles,
           :members,
           :member_roles,
           :issues,
           :issue_statuses,
           :versions,
           :trackers,
           :projects_trackers,
           :issue_categories,
           :enabled_modules,
           :enumerations,
           :attachments,
           :workflows,
           :custom_fields,
           :custom_values,
           :custom_fields_projects,
           :custom_fields_trackers,
           :time_entries,
           :journals,
           :journal_details,
           :queries

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts).directory + '/test/fixtures/', [:contacts,
                                                                                                                    :contacts_projects,
                                                                                                                    :deals,
                                                                                                                    :notes,
                                                                                                                    :tags,
                                                                                                                    :taggings,
                                                                                                                    :queries])

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts_helpdesk).directory + '/test/fixtures/', [:journal_messages,
                                                                                                                             :helpdesk_tickets])

  def setup
    RedmineHelpdesk::TestCase.prepare
    @issue1 = Issue.find(1)
    @issue2 = Issue.find(2)
    @admin = User.find(1)
  end

  def test_should_get_edit
    @request.session[:user_id] = 1
    compatible_xhr_request :get, :edit, :issue_id => 1, :id => 1
    assert_response 200
  end

  def test_should_create_ticket
    @request.session[:user_id] = 1
    compatible_request :put, :update, :helpdesk_ticket => { :contact_id => 1, :source => '0', :ticket_date => '2013-01-01' },
                                      :time => { :hour => 21, :minute => 12 },
                                      :issue_id => 1,
                                      :id => 1
    assert_redirected_to :controller => 'issues', :action => 'show', :id => '1'
    assert_not_nil HelpdeskTicket.find_by_from_address(Contact.find(1).primary_email)
  end

  def test_should_destroy
    @request.session[:user_id] = 1
    compatible_request :delete, :destroy, id: HelpdeskTicket.find(3).issue_id
    assert_response :redirect
    assert_nil HelpdeskTicket.find_by_id(3)
  end

  def test_should_update_cutomer_profile
    @request.session[:user_id] = 1
    ticket = HelpdeskTicket.find(2)
    compatible_request :put, :update, helpdesk_ticket: { contact_id: 1, source: '2', ticket_date: '2013-01-01' },
                                      issue_id: ticket.issue_id,
                                      id: ticket.issue_id
    assert_redirected_to controller: 'issues', action: 'show', id: ticket.issue_id
    ticket.reload
    assert_equal Contact.find(1).primary_email, ticket.from_address
    assert_equal 2, ticket.issue_id
    assert_equal 2, ticket.source
  end

  def test_should_update_cutomer_profile_with_non_primary_email
    @request.session[:user_id] = 1
    ticket = HelpdeskTicket.find(2)
    contact = Contact.find(2)
    compatible_request :put, :update, helpdesk_ticket: { from_address: contact.emails.last, source: '2', ticket_date: '2013-01-01' },
                                      issue_id: ticket.issue_id,
                                      id: ticket.issue_id
    assert_redirected_to controller: 'issues', action: 'show', id: ticket.issue_id
    ticket.reload
    assert_equal contact.emails.last, ticket.from_address
    assert_equal 2, ticket.issue_id
    assert_equal 2, ticket.source
  end

  def test_bulk_edit_reply_page_should_have_form
    prepare_bulk_edit_reply_page

    assert_select 'form#message-form'
  end

  def test_bulk_edit_reply_page_should_have_issues_and_recipients
    prepare_bulk_edit_reply_page

    assert_select '#customer_to_email', 2
  end

  def test_bulk_edit_reply_page_should_have_sender_address
    prepare_bulk_edit_reply_page

    assert_select 'input#from' do
      assert_select '[value=?]', HelpdeskSettings[:helpdesk_answer_from, @project]
    end
  end

  def test_send_reply_page_should_have_hidden_fields
    prepare_bulk_edit_reply_page

    assert_select 'input[type=hidden][name=?]', 'helpdesk[is_send_mail]'
    assert_select 'input[type=hidden][name=?]', 'issue[custom_field_values]'
    assert_select 'input[type=hidden][name=?]', 'journal_message[to_address][]'
  end

  def test_bulk_update_reply_should_create_journal_records
    note = 'Bulk reply with sending mail'
    params = prepare_to_mailing(note)

    assert_difference 'Journal.count', 2 do
      compatible_request :post, :bulk_update_reply, params
      assert_response :redirect
    end
  end

  def test_bulk_update_reply_should_create_journal_message_records
    note = 'Bulk reply with sending mail'
    params = prepare_to_mailing(note)

    assert_difference('JournalMessage.count', 2) do
      compatible_request :post, :bulk_update_reply, params
      assert_response :redirect
    end
  end

  def test_bulk_update_reply_should_create_journal_message_records_with_cc
    note = 'Bulk reply with sending mail'
    params = prepare_to_mailing(note, cc = 'mail1@mail.com')

    assert_difference('JournalMessage.count', 2) do
      compatible_request :post, :bulk_update_reply, params
      assert_response :redirect
    end
  end
  def test_bulk_update_reply_should_create_journal_message_records_with_bcc
    note = 'Bulk reply with sending mail'
    params = prepare_to_mailing(note, bcc = 'mail1@mail.com')

    assert_difference('JournalMessage.count', 2) do
      compatible_request :post, :bulk_update_reply, params
      assert_response :redirect
    end
  end
  def test_bulk_update_reply_should_create_journal_message_records_with_cc_and_bcc
    note = 'Bulk reply with sending mail'
    params = prepare_to_mailing(note, cc = 'mail1@mail.com', bcc = 'mail2@mail.com')

    assert_difference('JournalMessage.count', 2) do
      compatible_request :post, :bulk_update_reply, params
      assert_response :redirect
    end
  end

  def test_bulk_update_reply_should_create_note
    ActionMailer::Base.deliveries.clear
    note = 'Bulk reply with sending mail'
    params = prepare_to_mailing(note)

    compatible_request :post, :bulk_update_reply, params
    assert_response :redirect

    assert_equal note, Journal.where({journalized_id: @issue1.id, journalized_type: 'Issue'}).last.notes
    assert_equal note, Journal.where({journalized_id: @issue2.id, journalized_type: 'Issue'}).last.notes
  end

  def test_bulk_update_reply_should_send_replies_to_contact
    ActionMailer::Base.deliveries.clear
    user = @admin
    note = "Hello, %%NAME%%\r\n Bye, %%NOTE_AUTHOR.FIRST_NAME%%"
    params = prepare_to_mailing(note)

    compatible_request :post, :bulk_update_reply, params
    assert_response :redirect

    # anonymous user
    assert_equal "Hello, Ivan\r\n Bye, #{user.firstname}", Journal.where({journalized_id: @issue1.id, journalized_type: 'Issue'}).last.notes
    assert_equal user, Journal.where({journalized_id: @issue1.id, journalized_type: 'Issue'}).last.user

    mail = last_ticket_mail
    assert_mail_body_match "Hello, Ivan\r\n Bye, #{user.firstname}", mail
    assert_equal @issue1.customer.primary_email, mail.to.first.downcase
  end

  def test_bulk_update_reply_should_send_replies_to_cc
    ActionMailer::Base.deliveries.clear
    note = "Hello, %%NAME%%\r\n Bye, %%NOTE_AUTHOR.FIRST_NAME%%"
    user = @admin
    params = prepare_to_mailing(note, cc = 'mail1@mail.com', bcc = '')

    compatible_request :post, :bulk_update_reply, params
    assert_response :redirect

    mail = last_ticket_mail
    assert_mail_body_match "Hello, Ivan\r\n Bye, #{user.firstname}", mail
    assert_equal @issue1.customer.primary_email, mail.to.first.downcase
    assert_equal 'mail1@mail.com', mail.cc.first
  end

  def test_bulk_update_reply_should_send_replies_to_bcc
    ActionMailer::Base.deliveries.clear
    note = "Hello, %%NAME%%\r\n Bye, %%NOTE_AUTHOR.FIRST_NAME%%"
    user = @admin
    params = prepare_to_mailing(note, cc = '', bcc = 'mail2@mail.com')

    compatible_request :post, :bulk_update_reply, params
    assert_response :redirect

    mail = last_ticket_mail
    assert_mail_body_match "Hello, Ivan\r\n Bye, #{user.firstname}", mail
    assert_equal @issue1.customer.primary_email, mail.to.first.downcase
    assert_equal 'mail2@mail.com', mail.bcc.first
  end

  private

  def prepare_bulk_edit_reply_page
    @request.session[:user_id] = @admin.id

    @project = Project.find('ecookbook')
    params = {
        ids: [@issue1.id, @issue2.id],
        project_id: @project.id
    }
    compatible_request :get, :bulk_edit_reply, params
    assert_response :success
  end

  def prepare_to_mailing(note, cc = '', bcc = '')
    @request.session[:user_id] = @admin.id
    {
        ids: [@issue1.id, @issue2.id],
        helpdesk: {
            is_send_mail: '1'
        },
        issue: {
            custom_field_values: ''
        },
        journal_message: {
            cc_address: [cc],
            bcc_address: [bcc]
        },
        from: "#{User.current.mail}",
        notes: note
    }
  end

  def last_ticket_mail
    ActionMailer::Base.deliveries.detect { |m| m['X-Redmine-Ticket-ID'] }
  end
end
