# encoding: utf-8
#
# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class HelpdeskWidgetControllerTest < ActionController::TestCase
  fixtures :projects,
           :users,
           :roles,
           :members,
           :member_roles,
           :issues,
           :issue_statuses,
           :versions,
           :trackers,
           :projects_trackers,
           :issue_categories,
           :enabled_modules,
           :enumerations,
           :attachments,
           :workflows,
           :custom_fields,
           :custom_values,
           :custom_fields_projects,
           :custom_fields_trackers,
           :time_entries,
           :journals,
           :journal_details,
           :queries

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts_helpdesk).directory + '/test/fixtures/', [:helpdesk_mail_rules])

  def setup
    RedmineHelpdesk::TestCase.prepare
  end

  def test_should_create_ticket
    compatible_request :post, :create_ticket, "username"=>"TestUser", "email"=>"tester@example.com",
                                              "issue"=>{"subject"=>"test widget", "description"=>"test widget"},
                                              "project_id"=>"ecookbook", "tracker_id"=>"1", "privacy_policy"=>"1"

    assert_response 200
    issue = Issue.last
    assert_equal 'test widget', issue.subject
    assert_equal 'tester@example.com', issue.helpdesk_ticket.from_address
  end

  def test_should_apply_mail_rule001_on_create_ticket
    compatible_request :post, :create_ticket, "username"=>"TestUser", "email"=>"tester@example.com",
                                              "issue"=>{"subject"=>"test widget", 
                                              "description"=>"Lorem ipsum dolor sit amet. *RULE_TEXT* . Duis id diam."},
                                              "project_id"=>"ecookbook", "tracker_id"=>"1", "privacy_policy"=>"1"

    assert_response 200
    issue = Issue.last
    assert_equal IssueStatus.find(5), issue.status
    assert_equal IssuePriority.find(6), issue.priority
    assert_equal User.find(3), issue.assigned_to
  end

  def test_should_apply_mail_rule004_on_create_ticket
    compatible_request :post, :create_ticket, "username"=>"TestUser", "email"=>"tester@example.com",
                                              "issue"=>{"subject"=>"dsdfsd LETTER ", 
                                              "description"=>"Lorem ipsum dolor sit amet. Duis id diam."},
                                              "project_id"=>"ecookbook", "tracker_id"=>"1", "privacy_policy"=>"1"
    assert_response 200
    issue = Issue.last
    assert_equal User.find(1), issue.assigned_to
  end

  def test_should_apply_mail_rule003_on_create_ticket
    compatible_request :post, :create_ticket, "username"=>"TestUser", "email"=>"tester@example.com",
                                              "issue"=>{"subject"=>"dsdfsd LETTER subject ", 
                                              "description"=>"Lorem ipsum dolor sit amet. Duis id diam."},
                                              "project_id"=>"ecookbook", "tracker_id"=>"1", "privacy_policy"=>"1"
    assert_response 200
    issue = Issue.last
    assert_equal 3, issue.project_id
    assert_equal 2, issue.tracker_id
  end
end
