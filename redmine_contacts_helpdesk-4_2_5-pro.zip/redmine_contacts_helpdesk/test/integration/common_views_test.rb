# encoding: utf-8
#
# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class RedmineHelpdesk::CommonViewsTest < Redmine::ApiTest::Base
  fixtures :projects,
           :users,
           :roles,
           :members,
           :member_roles,
           :issues,
           :issue_statuses,
           :versions,
           :trackers,
           :projects_trackers,
           :issue_categories,
           :enabled_modules,
           :enumerations,
           :attachments,
           :workflows,
           :custom_fields,
           :custom_values,
           :custom_fields_projects,
           :custom_fields_trackers,
           :time_entries,
           :journals,
           :journal_details,
           :queries

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts).directory + '/test/fixtures/', [:contacts,
                                                                                                                    :contacts_projects,
                                                                                                                    :deals,
                                                                                                                    :notes,
                                                                                                                    :tags,
                                                                                                                    :taggings,
                                                                                                                    :queries])

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts_helpdesk).directory + '/test/fixtures/', [:journal_messages,
                                                                                                                             :canned_responses,
                                                                                                                             :helpdesk_tickets])

  def setup
    RedmineHelpdesk::TestCase.prepare
  end

  test "View project settings" do
    log_user("admin", "admin")
    compatible_request :get, "/projects/ecookbook/settings"
    assert_response :success
  end

  test "View helpdesk plugin settings" do
    log_user("admin", "admin")
    compatible_request :get, "/settings/plugin/redmine_contacts_helpdesk"
    assert_response :success
  end

  test "View helpdesk plugin settings with hidden tab" do
    log_user("admin", "admin")
    compatible_request :get, "/settings/plugin/redmine_contacts_helpdesk?hidden=true"
    assert_response :success
  end

  test "View issue" do
    log_user("admin", "admin")
    compatible_request :get, "/issues/1"
    assert_response :success
  end

  test "View issues" do
    log_user("admin", "admin")
    compatible_request :get, "/issues"
    assert_response :success
  end

  test "View project issues" do
    log_user("admin", "admin")
    compatible_request :get, "/projects/ecookbook/issues"
    assert_response :success
  end

  test "Can view helpdesk reports with permissons" do
    log_user("admin", "admin")
    get "/projects/ecookbook"
    assert response.body.match /Helpdesk reports/
  end

  test "Can not view helpdesk reports without permissons" do
    log_user("jsmith", "jsmith")
    get "/projects/ecookbook"
    assert_no_match %r{Helpdesk reports}, response.body
  end
end
