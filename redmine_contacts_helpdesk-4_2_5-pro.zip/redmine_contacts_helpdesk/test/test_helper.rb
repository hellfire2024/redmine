# encoding: utf-8
#
# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path(File.dirname(__FILE__) + '/../../../test/test_helper')
require File.expand_path(File.dirname(__FILE__) + '/../../redmine_contacts/test/test_helper')
include RedmineContacts::TestHelper

# Engines::Testing.set_fixture_path

module RedmineHelpdesk

  module TestHelper
    HELPDESK_FIXTURES_PATH = File.dirname(__FILE__) + '/fixtures/helpdesk_mailer'

    def submit_email(filename, options = {})
      raw = IO.read(File.join(HELPDESK_FIXTURES_PATH, filename))
      MailHandler.receive(raw, options)
    end

    def raw_helpdesk_email(filename)
      IO.read(File.join(HELPDESK_FIXTURES_PATH, filename))
    end

    def submit_helpdesk_email(filename, options = {})
      raw = raw_helpdesk_email(filename)
      HelpdeskMailer.receive(raw, options)
    end

    def helpdesk_uploaded_file(filename, mime)
      file_path = "plugins/redmine_contacts_helpdesk/test/fixtures/helpdesk_mailer/#{filename}"
      fixture_file_upload(Redmine::VERSION.to_s < '4' ? "../../#{file_path}" : File.join(Rails.root, file_path), mime, true)
    end

    def last_email
      mail = ActionMailer::Base.deliveries.last
      assert_not_nil mail
      mail
    end

    def with_helpdesk_settings(options, &block)
      original_settings = Setting['plugin_redmine_contacts_helpdesk']
      Setting['plugin_redmine_contacts_helpdesk'] = original_settings.merge(Hash[options.map {|k,v| [k, v]}])
      yield
    ensure
      Setting['plugin_redmine_contacts_helpdesk'] = original_settings
    end

    def with_helpdesk_project_settings(project, options, &block)
      project_id = project.is_a?(Project) ? project.id : project
      original_settings = Setting['plugin_redmine_contacts']
      helpdesk_settings = original_settings['projects'] || {}
      helpdesk_settings[project_id] = Hash[options.map {|k,v| [k, v]}]
      Setting[:plugin_redmine_contacts] = original_settings.merge('projects' => helpdesk_settings)
      Setting['plugin_redmine_contacts'] = original_settings.merge('projects' => helpdesk_settings)
      yield
    ensure
      Setting[:plugin_redmine_contacts] = original_settings
      Setting['plugin_redmine_contacts'] = original_settings
    end
  end

  class TestCase
    def self.create_fixtures(fixtures_directory, table_names, _class_names = {})
      ActiveRecord::FixtureSet.create_fixtures(fixtures_directory, table_names, _class_names = {})
    end

    def self.prepare
      Role.where(:id => [1, 2, 3, 4]).each do |r|
        r.permissions << :view_contacts
        r.save
      end
      Role.where(:id => [1, 2]).each do |r|
        r.permissions << :edit_contacts
        r.save
      end

      Role.where(:id => [1, 2, 3]).each do |r|
        r.permissions << :view_deals
        r.save
      end
      Project.where(:id => [1, 2, 3, 4]).each do |project|
        EnabledModule.create(:project => project, :name => 'contacts')
        EnabledModule.create(:project => project, :name => 'deals')
        EnabledModule.create(:project => project, :name => 'contacts_helpdesk')
      end
    end

    def assert_error_tag(options = {})
      assert_tag({ :attributes => { :id => 'errorExplanation' } }.merge(options))
    end
  end
end
