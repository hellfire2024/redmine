# encoding: utf-8
#
# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

# encoding: utf-8
require File.expand_path('../../test_helper', __FILE__)

class HelpdeskMailMessengerTest < ActiveSupport::TestCase
  fixtures :projects,
           :users,
           :roles,
           :members,
           :member_roles,
           :issues,
           :issue_statuses,
           :versions,
           :trackers,
           :projects_trackers,
           :issue_categories,
           :enabled_modules,
           :enumerations,
           :attachments,
           :workflows,
           :custom_fields,
           :custom_values,
           :custom_fields_projects,
           :custom_fields_trackers,
           :time_entries,
           :journals,
           :journal_details,
           :queries,
           :email_addresses

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts).directory + '/test/fixtures/', [:contacts,
                                                                                                                    :contacts_projects,
                                                                                                                    :deals,
                                                                                                                    :notes,
                                                                                                                    :tags,
                                                                                                                    :taggings,
                                                                                                                    :queries])

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts_helpdesk).directory + '/test/fixtures/', [:journal_messages,
                                                                                                                             :helpdesk_tickets])

  include RedmineHelpdesk::TestHelper

  def setup
    RedmineHelpdesk::TestCase.prepare
    ActionMailer::Base.deliveries.clear
    Setting.host_name = 'mydomain.foo'
    Setting.protocol = 'http'
    Setting.plain_text_mail = '0'
  end

  def test_should_build_initial_email_for_send_to_outlook 
    with_helpdesk_settings('helpdesk_send_protocol' => 'outlook') do
      contact = Contact.find(1)
      issue = Issue.find(1)

      email = HelpdeskMailMessenger::InitialMessage.prepare_email(contact, issue)

      assert_equal contact.email, email.to[0]
      assert_equal 2, email.parts.size
      assert_equal '7bit', email.content_transfer_encoding
    end
  end

  def test_should_build_auto_answer_email_for_send_to_outlook 
    with_helpdesk_settings('helpdesk_send_protocol' => 'outlook') do
      contact = Contact.find(1)
      issue = Issue.find(1)

      email = HelpdeskMailMessenger::AutoAnswerMessage.prepare_email(contact, issue)

      assert_equal contact.email, email.to[0]
      assert_equal 2, email.parts.size
      assert_equal '7bit', email.content_transfer_encoding
    end
  end

  def test_should_build_autoclose_email_for_send_to_outlook 
    with_helpdesk_settings('helpdesk_send_protocol' => 'outlook') do
      contact = Contact.find(1)
      issue = Issue.find(1)

      email = HelpdeskMailMessenger::AutocloseMessage.prepare_email(contact, issue)

      assert_equal contact.email, email.to[0]
      assert_equal 2, email.parts.size
      assert_equal '7bit', email.content_transfer_encoding
    end
  end

  def test_should_build_issue_response_email_for_send_to_outlook 
    with_helpdesk_settings('helpdesk_send_protocol' => 'outlook') do
      contact = Contact.find(1)
      journal = Journal.find(1)

      email = HelpdeskMailMessenger::IssueResponseMessage.prepare_email(contact, journal)

      assert_equal contact.email, email.to[0]
      assert_equal 2, email.parts.size
      assert_equal '7bit', email.content_transfer_encoding
    end
  end
end
