# encoding: utf-8
#
# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class MailHandlerPatchTest < ActiveSupport::TestCase
  fixtures :projects,
           :users,
           :roles,
           :members,
           :member_roles,
           :issues,
           :issue_statuses,
           :versions,
           :trackers,
           :projects_trackers,
           :issue_categories,
           :enabled_modules,
           :enumerations,
           :attachments,
           :workflows,
           :custom_fields,
           :custom_values,
           :custom_fields_projects,
           :custom_fields_trackers,
           :time_entries,
           :journals,
           :journal_details,
           :queries,
           :email_addresses

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts).directory + '/test/fixtures/', [:contacts,
                                                                                                                    :contacts_projects,
                                                                                                                    :deals,
                                                                                                                    :notes,
                                                                                                                    :tags,
                                                                                                                    :taggings,
                                                                                                                    :queries])

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts_helpdesk).directory + '/test/fixtures/', [:journal_messages,
                                                                                                                             :helpdesk_tickets])

  include RedmineHelpdesk::TestHelper

  def setup
    RedmineHelpdesk::TestCase.prepare

    ActionMailer::Base.deliveries.clear
    Setting.host_name = 'mydomain.foo'
    Setting.protocol = 'http'
    Setting.plain_text_mail = '0'

    Setting.notified_events = Redmine::Notifiable.all.collect(&:name)
  end

  def test_send_mail_to_contact
    issue = Issue.find(5)
    contact = Contact.find(1)
    issue.helpdesk_ticket = HelpdeskTicket.new(:customer => contact,
                                               :issue => issue,
                                               :from_address => contact.primary_email,
                                               :ticket_date => Time.now)
    issue.save!
    with_helpdesk_settings('send_note_by_default' => false) do
      journal = submit_email('reply_from_mail.eml')
      assert_instance_of Journal, journal
      assert !journal.new_record?
      assert last_email.to.include?(contact.emails.first)
      assert !last_email.parts.first.body.to_s.blank?
      journal.reload
      assert_no_match /^@@sendmail@@\s*/, journal.notes
      assert_match /This is a reply from mail/, journal.notes
    end
  end

  def test_send_mail_to_contact_by_default
    issue = Issue.find(5)
    contact = Contact.find(1)
    issue.helpdesk_ticket = HelpdeskTicket.new(:customer => contact,
                                               :issue => issue,
                                               :from_address => contact.primary_email,
                                               :ticket_date => Time.now)
    issue.save!
    with_helpdesk_settings('send_note_by_default' => true) do
      journal = submit_email('reply_from_mail_by_default.eml')
      assert_instance_of Journal, journal
      assert !journal.new_record?
      assert_equal issue.helpdesk_ticket.from_address, last_email.to.first.to_s
      assert !last_email.parts.first.body.to_s.blank?
      journal.reload
      assert_match /This is a reply from mail by default/, journal.notes
    end
  end

  def test_should_assign_user_to_unassigned_issue
    issue = Issue.find(5)
    issue.assigned_to = nil
    contact = Contact.find(1)
    issue.helpdesk_ticket = HelpdeskTicket.new(:customer => contact,
                                               :issue => issue,
                                               :from_address => contact.primary_email,
                                               :ticket_date => Time.now)
    issue.save!
    with_helpdesk_settings('send_note_by_default' => true) do
      journal = submit_email('reply_from_mail_by_default.eml')
      assert_instance_of Journal, journal
      assert_equal journal.user, journal.issue.assigned_to
    end
  end

  def test_should_assign_new_status
    issue = Issue.find(5)
    issue.assigned_to = User.find(2)
    issue.status_id = IssueStatus.last.id
    ContactsSetting[:helpdesk_answered_status, issue.project_id] = IssueStatus.first.id
    contact = Contact.find(1)
    issue.helpdesk_ticket = HelpdeskTicket.new(:customer => contact,
                                               :issue => issue,
                                               :from_address => contact.primary_email,
                                               :ticket_date => Time.now)
    issue.save!
    with_helpdesk_settings('send_note_by_default' => true) do
      journal = submit_email('reply_from_mail_by_default.eml')
      assert_instance_of Journal, journal
      journal.reload
      assert_equal IssueStatus.first, journal.issue.status
    end
  end

  def test_should_autoclose_issue_by_reply_from_email
    # ticket from Anonymous user
    Issue.find(14).update({
                       project_id: 2,
                       priority_id: 4,
                       subject: 'Issue Anonymous',
                       description: 'I need help',
                       tracker_id: 1,
                       assigned_to_id: 2,
                       author_id: 6,
                       status_id: 1
                   })

    ticket = Issue.find(14)
    user = User.find(2)
    project = Project.find(2)
    contact = Contact.find(1)
    close_status = 5

    user.roles_for_project(project).first.add_permission! :send_response
    ContactsSetting[:helpdesk_answered_status, ticket.project_id] = close_status

    ticket.reload.helpdesk_ticket = HelpdeskTicket.new(:customer => contact,
                                                :issue => ticket,
                                                :from_address => contact.primary_email,
                                                :ticket_date => Time.now)
    ticket.save!
    with_helpdesk_settings('send_note_by_default' => true) do
      journal = submit_email('reply_on_redmine_notification.eml')
      assert_instance_of Journal, journal
      journal.reload
      assert_equal 5, ticket.reload.status.id
      assert_equal 'This is a reply from mail.', journal.notes
      assert_equal 'Re: Issue Anonymous [Bug #14]', ActionMailer::Base.deliveries.last.subject
    end
  end

  def test_should_not_send_mail_to_contact_by_default
    issue = Issue.find(5)
    contact = Contact.find(1)
    issue.helpdesk_ticket = HelpdeskTicket.new(:customer => contact,
                                               :issue => issue,
                                               :from_address => contact.primary_email,
                                               :ticket_date => Time.now)
    issue.save!
    with_helpdesk_settings('send_note_by_default' => false) do
      journal = submit_email('reply_from_mail_by_default.eml')
      assert_instance_of Journal, journal
      assert_not_equal contact.email, last_email.to.first.to_s
    end
  end

  def test_should_not_send_mail_to_contact_by_default_with_empty_body
    issue = Issue.find(5)
    contact = Contact.find(1)
    issue.helpdesk_ticket = HelpdeskTicket.new(:customer => contact,
                                               :issue => issue,
                                               :from_address => contact.primary_email,
                                               :ticket_date => Time.now)
    issue.save!
    assert_not_equal 'Closed', issue.status.name
    with_helpdesk_settings('send_note_by_default' => true) do
      Setting.mail_handler_body_delimiters = '---- This should be cutted ----'
      journal = submit_email('reply_from_mail_with_keywords.eml', :allow_override => ['status'])
      assert_instance_of Journal, journal
      assert_nil ActionMailer::Base.deliveries.last
      assert_nil journal.journal_message
    end
  end

  def test_should_receive_to_tagged_response_to_issue
    ActionMailer::Base.deliveries.clear
    issue = Issue.find(1)
    journal = submit_email('reply_from_mail_with_tag.eml', :issue => { :project_id => 'ecookbook' })
    assert_equal Journal, journal.class
    assert !journal.new_record?
    journal.reload
    issue.reload
    assert_equal issue, journal.issue
  end

  def test_should_receive_cc_tagged_response_to_issue
    ActionMailer::Base.deliveries.clear
    issue = Issue.find(2)
    journal = submit_email('reply_from_mail_with_tag_in_cc.eml', :issue => { :project_id => 'ecookbook' })
    assert_equal Journal, journal.class
    assert !journal.new_record?
    journal.reload
    issue.reload
    assert_equal issue, journal.issue
  end
end
