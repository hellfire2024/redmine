# encoding: utf-8
require File.expand_path('../lib/redmine_drawio', __FILE__)
