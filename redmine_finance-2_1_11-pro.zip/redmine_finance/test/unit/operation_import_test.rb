# encoding: utf-8
#
# This file is a part of Redmine Finance (redmine_finance) plugin,
# simple accounting plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_finance is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_finance is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_finance.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class OperationImportTest < ActiveSupport::TestCase
  fixtures :projects, :users, :operation_categories, :accounts, :contacts, :operations

  def setup
    @user = User.find(1)
  end

  def test_open_correct_csv
    assert_difference('Operation.count', 3, 'Should add 3 operations to the database') do
      operation_import = generate_import_with_mapping
      assert operation_import.run, 3
    end
  end

  def test_should_report_error_line
    assert_difference('Operation.count', 2, 'Should add 2 operations to the database') do
      operation_import = generate_import_with_mapping('with_data_malformed.csv')
      assert operation_import.run, 3
      messages = operation_import.items.pluck(:message).compact.map(&:downcase)
      assert messages.include?('account cannot be blank')
    end
  end

  def test_open_csv_with_custom_fields
    cf1 = OperationCustomField.create!(:name => 'License', :field_format => 'string')
    cf2 = OperationCustomField.create!(:name => 'Purchase date', :field_format => 'date')
    operation_import = generate_import_with_mapping('operations_cf.csv')
    operation_import.settings['separator'] = ','
    operation_import.settings['date_format'] = '%Y-%m-%d'
    operation_import.mapping.merge!("cf_#{cf1.id}" => '10', "cf_#{cf2.id}" => '11')
    operation_import.run

    assert_equal 1, operation_import.items.count, 'Should find 1 operation in file'
    operation = Operation.find_by_description('Refund')
    assert_equal '12345', operation.custom_field_value(cf1.id)
    assert_equal '2024-08-11', operation.custom_field_value(cf2.id).to_s
  end

  protected

  def generate_import(fixture_name='operations.csv')
    import = OperationImport.new
    import.user_id = @user.id
    import.file = Rack::Test::UploadedFile.new(fixture_files_path + fixture_name, 'text/csv')
    import.save!
    import
  end

  def generate_import_with_mapping(fixture_name='operations.csv')
    import = generate_import(fixture_name)
    import.settings = {
      'separator' => ',',
      'wrapper' => '"',
      'encoding' => 'UTF-8',
      'date_format' => '%m/%d/%Y',
      'mapping' => {
        'project_id' => '0',
        'operation_date' => '1',
        'income' => '2',
        'expense' => '3',
        'category' => '4',
        'account' => '5',
        'description' => '6',
        'contact' => '7'
      }
    }
    import.save!
    import
  end
end if Redmine::VERSION.to_s >= '4.1'
