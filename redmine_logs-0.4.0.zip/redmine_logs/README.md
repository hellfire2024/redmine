[![build](https://github.com/haru/redmine_logs/actions/workflows/build.yml/badge.svg)](https://github.com/haru/redmine_logs/actions/workflows/build.yml)
[![Maintainability](https://api.codeclimate.com/v1/badges/3fb10c5b2245dd4647e5/maintainability)](https://codeclimate.com/github/haru/redmine_logs/maintainability)
[![codecov](https://codecov.io/gh/haru/redmine_logs/branch/develop/graph/badge.svg?token=SKAL5GLHIX)](https://codecov.io/gh/haru/redmine_logs)

# Redmine Logs Plugin

This is a plugin for Redmine which lets you download log files of Redmine from administration page.

http://www.r-labs.org/projects/logs

## Plugin installation

1. Copy the plugin directory into the plugins directory.

That's all.

