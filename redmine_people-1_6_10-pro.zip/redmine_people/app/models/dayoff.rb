# This file is a part of Redmine People (redmine_people) plugin,
# humanr resources management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_people is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_people is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_people.  If not, see <http://www.gnu.org/licenses/>.

class Dayoff < ApplicationRecord
  extend Redmine::Utils::DateCalculation
  include Redmine::SafeAttributes

  belongs_to :user, class_name: 'Person'
  belongs_to :leave_type

  has_one :information, through: :user
  has_one :manager, through: :information
  has_one :department, through: :information

  validates :user_id, :leave_type_id, :start_date, presence: true
  validates :hours_per_day, numericality: { allow_nil: true, greater_than_or_equal_to: 0, less_than_or_equal_to: 24 }
  validate :check_interval

  after_create :send_create_notification
  after_update :send_approve_notification
  after_update :send_notes_notification

  delegate :color, to: :leave_type

  safe_attributes 'user_id', 'leave_type_id', 'approved', 'start_date', 'end_date', 'hours_per_day', 'notes'

  scope :between, lambda { |from, to|
    condition_sql = <<-SQL.squish
      #{table_name}.start_date >= :from AND #{table_name}.start_date <= :to OR
      :from >= #{table_name}.start_date AND :from <= #{table_name}.end_date
    SQL
    where(condition_sql, from: from.to_datetime, to: to.to_datetime)
  }

  def self.person_dayoffs_by_day(person, start_date, end_date, workday_length=nil)
    workday_length ||= person.workday_length
    dayoffs = person.dayoffs.joins(:leave_type)
                            .where(start_date: start_date..end_date)
                            .where("leave_types.approvable = ? OR dayoffs.approved = ?", false, true)
                            .to_a

    dayoffs_sum_hash = {}

    (start_date.to_date..end_date.to_date).each do |date|
      dayoffs_for_date = dayoffs.select { |dayoff| date >= dayoff.start_date && (dayoff.end_date.nil? || date <= dayoff.end_date) }
      dayoffs_sum = dayoffs_for_date.map { |dayoff| dayoff.hours_per_day || workday_length }.sum
      dayoffs_sum = [dayoffs_sum, workday_length].min
      dayoffs_sum_hash[date] = dayoffs_sum unless dayoffs_sum.zero?
    end

    dayoffs_sum_hash
  end

  def self.person_work_hours_per_day(person, start_date, end_date, workday_length=nil)
    workday_length ||= person.workday_length
    dayoffs_sum_hash = Dayoff.person_dayoffs_by_day(person, start_date, end_date, workday_length)
    holidays = PeopleHoliday.where(is_workday: false).between(start_date, end_date)
    work_hours_sum_hash = {}
    (start_date.to_date..end_date.to_date).each do |date|
      available_work_hours = workday_length - dayoffs_sum_hash[date].to_f
      work_hours_sum_hash[date] = (non_working_week_days.include?(date.cwday) || holidays.any? { |holiday| holiday.covers_date?(date) }) ? 0 : available_work_hours
    end

    work_hours_sum_hash
  end

  def self.person_available_capacity_by_day(person, start_date, end_date, workday_length=nil)
    workday_length ||= person.workday_length
    dayoffs_sum_hash = person_dayoffs_by_day(person, start_date, end_date, workday_length)
    work_hours_sum_hash = person_work_hours_per_day(person, start_date, end_date, workday_length)

    person_capacity_hash = {}

    (start_date.to_date..end_date.to_date).each do |date|
      dayoffs_sum = dayoffs_sum_hash[date].to_f
      work_hours = work_hours_sum_hash[date].to_f

      if dayoffs_sum > 0
        if dayoffs_sum < work_hours
          person_capacity_hash[date] = { type_day: 'part_dayoff', workday_length: workday_length - dayoffs_sum }
        else
          person_capacity_hash[date] = { type_day: 'dayoff', workday_length: 0 }
        end
      else
        person_capacity_hash[date] = { type_day: 'full_workday', workday_length: workday_length }
      end

      if non_working_week_days.include?(date.cwday) && person_capacity_hash[date][:type_day] != 'dayoff'
        person_capacity_hash[date] = { type_day: 'weekend', workday_length: 0 }
      end
    end

    person_capacity_hash
  end

  def self.person_available_capacity_by_day_with_holidays(person, start_date, end_date, workday_length=nil)
    person_capacity_hash = person_available_capacity_by_day(person, start_date, end_date, workday_length)
    holidays = PeopleHoliday.where(is_workday: false).between(start_date, end_date)
    person_capacity_hash.each do |date, capacity|
      if holidays.any? { |holiday| holiday.covers_date?(date) }
        person_capacity_hash[date] = { type_day: 'holiday', workday_length: 0 }
      end
    end
  end

  def start_date
    self[:start_date].try(:to_date)
  end

  def end_date
    self[:end_date].try(:to_date)
  end

  def due_date
    end_date || start_date
  end

  def due_date=(date)
    self.end_date = date
  end

  def name
    [user.name, ' - ', leave_type.name].join
  end

  def duration
    if hours_per_day
      if start_date == due_date
        "#{to_int_if_whole(hours_per_day)} #{l(:field_hours_per_day_abbreviation)}"
      else
        "#{to_int_if_whole(hours_per_day)} #{l(:field_hours_per_day_abbreviation)}" +
          " #{l(:label_people_scheduled_for)} #{l('datetime.distance_in_words.x_days', count: number_of_days)}"
      end
    else
      l('datetime.distance_in_words.x_days', count: number_of_days)
    end
  end

  def number_of_days
    start_date ? (due_date - start_date).to_i + 1 : 0
  end

  def is_approved?
    !leave_type.approvable || approved
  end

  def notified_users
    current_user_id = User.current.id
    [manager, department.try(:head), user].compact.uniq.reject { |u| u.id == current_user_id }
  end

  def recipients
    notified_users.map(&:mail)
  end

  def email_users
    notified_users
  end

  def event_title
    "#{leave_type.name} #{duration} - (#{user})"
  end

  def url_options
    { only_path: false,
      controller: 'dayoffs',
      action: 'index',
      set_filter: 1,
      f: [:user_id],
      op: { user_id: '=' },
      v: { user_id: [user_id] },
      year: start_date.year,
      month: start_date.month,
      dayoff_id: id }
  end

  private

  def check_interval
    if start_date && end_date && end_date < start_date
      errors.add(:end_date, :greater_than_or_equal_to_start_date)
    end
  end

  def send_create_notification
    DayoffsMailer.deliver_dayoff_create(self)
  end

  def send_approve_notification
    if leave_type.approvable && saved_change_to_attribute?(:approved)
      DayoffsMailer.deliver_approve_notification(self)
    end
  end

  def send_notes_notification
    if saved_change_to_attribute?(:notes)
      DayoffsMailer.deliver_notes_notification(self)
    end
  end

  def to_int_if_whole(float_number)
    float_number.to_i == float_number ? float_number.to_i : float_number.round(2)
  end
end
