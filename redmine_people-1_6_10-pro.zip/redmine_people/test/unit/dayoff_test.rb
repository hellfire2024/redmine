# encoding: utf-8
#
# This file is a part of Redmine People (redmine_people) plugin,
# humanr resources management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_people is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_people is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_people.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class DayoffTest < ActiveSupport::TestCase
  include RedminePeople::TestCase::TestHelper

  fixtures :users, :projects, :roles, :members, :member_roles, :email_addresses

  RedminePeople::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_people).directory + '/test/fixtures/',
                                          [:people_information, :departments, :time_entries, :people_holidays])

  def setup
    @admin = User.find(1)
    User.current = @admin
    @person = Person.find(4)
    @leave_type = LeaveType.create!(name: 'Vacation', approvable: true)
    @dayoff = Dayoff.new(
      user: @person,
      leave_type: @leave_type,
      start_date: Date.today,
      end_date: Date.today + 2.days,
      hours_per_day: 8
    )
  end

  def test_should_create_valid_dayoff
    assert @dayoff.valid?
  end

  def test_should_not_create_dayoff_without_user
    @dayoff.user = nil
    assert_not @dayoff.valid?
    assert_includes @dayoff.errors[:user_id], "cannot be blank"
  end

  def test_should_not_create_dayoff_without_leave_type
    @dayoff.leave_type = nil
    assert_not @dayoff.valid?
    assert_includes @dayoff.errors[:leave_type_id], "cannot be blank"
  end

  def test_should_not_create_dayoff_without_start_date
    @dayoff.start_date = nil
    assert_not @dayoff.valid?
    assert_includes @dayoff.errors[:start_date], "cannot be blank"
  end

  def test_should_not_create_dayoff_with_negative_hours_per_day
    @dayoff.hours_per_day = -1
    assert_not @dayoff.valid?
    assert_includes @dayoff.errors[:hours_per_day], "must be greater than or equal to 0"
  end

  def test_should_not_create_dayoff_with_hours_per_day_greater_than_24
    @dayoff.hours_per_day = 25
    assert_not @dayoff.valid?
    assert_includes @dayoff.errors[:hours_per_day], "must be less than or equal to 24"
  end

  def test_should_not_create_dayoff_with_end_date_before_start_date
    @dayoff.end_date = @dayoff.start_date - 1.day
    assert_not @dayoff.valid?
    assert_includes @dayoff.errors[:end_date], "must be greater than or equal to start date"
  end

  def test_should_send_create_notification_after_creating_dayoff
    recipients_count = @dayoff.recipients.count
    assert_difference 'ActionMailer::Base.deliveries.size', recipients_count do
      @dayoff.save
    end
  end

  def test_should_send_approve_notification_after_updating_approval_status
    recipients_count = @dayoff.recipients.count
    @dayoff.save
    @dayoff.approved = true
    assert_difference 'ActionMailer::Base.deliveries.size', recipients_count do
      @dayoff.save
    end
  end

  def test_should_send_notes_notification_after_updating_notes
    recipients_count = @dayoff.recipients.count
    @dayoff.save
    @dayoff.notes = "New note"
    assert_difference 'ActionMailer::Base.deliveries.size', recipients_count do
      @dayoff.save
    end
  end

  def test_should_return_duration_in_days_when_hours_per_day_is_not_set
    @dayoff.hours_per_day = nil
    assert_equal "#{@dayoff.number_of_days} days", @dayoff.duration
  end

  def test_should_return_duration_in_hours_when_hours_per_day_is_set
    @dayoff.hours_per_day = 2
    assert_equal "2 h/d for 3 days", @dayoff.duration
  end

  def test_should_return_name_with_user_and_leave_type
    assert_equal "#{@person.name} - #{@leave_type.name}", @dayoff.name
  end

  def test_should_calculate_correct_number_of_days
    assert_equal 3, @dayoff.number_of_days
  end

  def test_should_correctly_calculate_the_due_date
    assert_equal @dayoff.end_date, @dayoff.due_date
  end

  def test_should_correctly_set_and_get_the_due_date
    new_date = Date.today + 3.days
    @dayoff.due_date = new_date
    assert_equal new_date, @dayoff.end_date
  end

  def test_should_get_notified_users
    department = @dayoff.department
    department.head = Person.second
    assert_includes @dayoff.notified_users, @person
    assert_includes @dayoff.notified_users, @dayoff.manager
    assert_includes @dayoff.notified_users, @dayoff.department.head
  end

  def test_should_return_recipients_for_notifications
    department = @dayoff.department
    department.head = Person.second
    recipients = @dayoff.recipients
    assert_includes recipients, @dayoff.manager.mail
    assert_includes recipients, @dayoff.department.head.mail
    assert_includes recipients, @person.mail
  end

  def test_should_return_event_title_correctly
    assert_equal "#{@leave_type.name} 8 h/d for 3 days - (#{@person})", @dayoff.event_title
  end

  def test_should_return_correct_url_options_for_dayoff
    expected_url = {
      only_path: false,
      controller: 'dayoffs',
      action: 'index',
      set_filter: 1,
      f: [:user_id],
      op: { user_id: '=' },
      v: { user_id: [@dayoff.user_id] },
      year: @dayoff.start_date.year,
      month: @dayoff.start_date.month,
      dayoff_id: @dayoff.id
    }
    assert_equal expected_url, @dayoff.url_options
  end
end
