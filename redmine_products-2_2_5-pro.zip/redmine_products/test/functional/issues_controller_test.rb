# encoding: utf-8
#
# This file is a part of Redmine Products (redmine_products) plugin,
# customer relationship management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_products is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_products is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_products.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class IssuesControllerTest < ActionController::TestCase
  fixtures :projects,
           :users,
           :roles,
           :members,
           :member_roles,
           :issues,
           :issue_statuses,
           :versions,
           :trackers,
           :projects_trackers,
           :issue_categories,
           :enabled_modules,
           :enumerations,
           :attachments,
           :workflows,
           :custom_fields,
           :custom_values,
           :custom_fields_projects,
           :custom_fields_trackers,
           :time_entries,
           :journals,
           :journal_details,
           :queries

  RedmineProducts::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts).directory + '/test/fixtures/', [:contacts,
                                                                                                                    :contacts_projects])

  RedmineProducts::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_products).directory + '/test/fixtures/', [:products,
                                                                                                                    :order_statuses,
                                                                                                                    :orders,
                                                                                                                    :product_lines])

  def setup
    RedmineProducts::TestCase.prepare
    User.current = nil
    @request.session[:user_id] = 1

    @issue = Issue.find(1)
    order = Order.find(1)
    @order_cf = IssueCustomField.create!(name: 'Related order',
                                           field_format: 'order',
                                           is_filter: true,
                                           is_for_all: true,
                                           multiple: true,
                                           tracker_ids: Tracker.pluck(:id))

    CustomValue.create!(custom_field: @order_cf, customized: @issue, value: order.id)
  end

  def test_get_index_with_order
    compatible_request :get, :index, :f => ['status_id', "cf_#{@order_cf.id}", ''],
                       :op => { :status_id => 'o', "cf_#{@order_cf.id}" => '=' },
                       :v => { "cf_#{@order_cf.id}" => ['1'] },
                       :c => ['subject', "cf_#{@order_cf.id}"],
                       :project_id => 'ecookbook'
    assert_response :success
    assert_select 'table.list.issues td.order a', text: "#24 - Sales order for plugin Invoices (Approved): $6,642.00 (Marat Aminov)"
  end

  def test_get_issues_without_orders
    compatible_request :get, :index, :f => ['status_id', "cf_#{@order_cf.id}", ''],
                       :op => { :status_id => '*', "cf_#{@order_cf.id}" => '!*' },
                       :c => ['subject', "cf_#{@order_cf.id}"],
                       :project_id => 'ecookbook'
    assert_response :success
    assert_select 'table.list.issues td.order', count: 0, text: "#24 - Sales order for plugin Invoices (Approved): $6,642.00 (Marat Aminov)"
  end

  def test_show_issue_with_order_field
    compatible_request :get, :show, id: @issue.id
    assert_response :success
    assert_select ".cf_#{@order_cf.id}", text: "Related order:#24 - Sales order for plugin Invoices (Approved): $6,642.00 (Marat Aminov)"
  end
end
