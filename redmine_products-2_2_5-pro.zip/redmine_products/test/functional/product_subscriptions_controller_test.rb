# encoding: utf-8
#
# This file is a part of Redmine Products (redmine_products) plugin,
# customer relationship management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_products is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_products is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_products.  If not, see <http://www.gnu.org/licenses/>.

# encoding: utf-8
require File.expand_path('../../test_helper', __FILE__)

class ProductSubscriptionsControllerTest < ActionController::TestCase
  include RedmineContacts::TestHelper
  include RedmineProducts::TestCase::TestHelper

  fixtures :projects,
           :users,
           :roles,
           :members,
           :member_roles,
           :issues,
           :issue_statuses,
           :versions,
           :trackers,
           :projects_trackers,
           :issue_categories,
           :enabled_modules,
           :enumerations,
           :attachments,
           :workflows,
           :custom_fields,
           :custom_values,
           :custom_fields_projects,
           :custom_fields_trackers,
           :time_entries,
           :journals,
           :journal_details,
           :queries

  RedmineProducts::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts).directory + '/test/fixtures/', [:contacts,
                                                                                                                    :contacts_projects])

  RedmineProducts::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_products).directory + '/test/fixtures/', [:products,
                                                                                                                    :order_statuses,
                                                                                                                    :orders,
                                                                                                                    :product_lines,
                                                                                                                    :product_subscriptions])

  def setup
    RedmineProducts::TestCase.prepare
    @request.session[:user_id] = 1
    @project = Project.find(1)
  end

  def test_get_index
    compatible_request :get, :index, project_id: @project.id
    assert_response :success
    assert_not_nil product_subscriptions_in_list
  end

  def test_index_with_search_filter
    compatible_xhr_request :get, :index, set_filter: 1, search: '3', project_id: @project.id
    assert_response :success
    assert_not_nil product_subscriptions_in_list
    assert_select 'div.header.subscription_number', :content => /TEST_REFERENCE_3/
  end

  def test_get_new
    compatible_xhr_request :get, :new, project_id: @project.id
    assert_response :success
  end

  def test_post_create
    assert_difference 'ProductSubscription.count' do
      compatible_xhr_request :post, :create, project_id: 1,
        product_subscription: { reference_id: 'New subscription reference',
                                start_date: '2021-02-09',
                                expire_date: '2021-03-05' }
    end
    assert_response :success

    subscription = ProductSubscription.last
    assert_not_nil subscription
    assert_equal 1, subscription.author_id
    assert_equal "New subscription reference", subscription.reference_id
    assert_equal Date.parse('2021-02-09'), subscription.start_date
    assert_equal Date.parse('2021-03-05'), subscription.expire_date
  end

  def test_put_update
    compatible_xhr_request :put, :update, id: 1, project_id: 1,
      product_subscription: { reference_id: 'Updated subscription reference',
                              start_date: '2021-02-10',
                              expire_date: '2021-03-06' }
    assert_response :success

    subscription = ProductSubscription.find(1)
    assert_not_nil subscription
    assert_equal 1, subscription.author_id
    assert_equal "Updated subscription reference", subscription.reference_id
    assert_equal Date.parse('2021-02-10'), subscription.start_date
    assert_equal Date.parse('2021-03-06'), subscription.expire_date
  end

  def test_destroy_product_subscription
    assert_difference 'ProductSubscription.count', -1 do
      compatible_xhr_request :delete, :destroy, id: 1, project_id: 1
    end
    assert_response :success

    assert_equal 0, ProductSubscription.where(id: 1).count
  end
end
