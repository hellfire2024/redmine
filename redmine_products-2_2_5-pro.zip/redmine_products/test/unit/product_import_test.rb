# encoding: utf-8
#
# This file is a part of Redmine Products (redmine_products) plugin,
# customer relationship management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_products is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_products is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_products.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class ProductImportTest < ActiveSupport::TestCase
  fixtures :projects, :users

  RedmineProducts::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_products).directory + '/test/fixtures/', [:products,
                                                                                                                    :product_categories,
                                                                                                                    :product_lines])

  def fixture_files_path
    "#{Rails.root}/plugins/redmine_products/test/fixtures/files/"
  end

  def test_open_correct_csv_file
    assert_difference('Product.count', 1, 'Should have 1 product in the database') do
      product_import = generate_import_with_mapping
      assert product_import.run, 1
      assert_equal 1, product_import.items.count, 'Should find 1 deal in file'
    end
    product = Product.last
    assert_equal '44332211',         product.code
    assert_equal 'Test product',     product.name
    assert_equal 'Test_description', product.description
    assert_equal 320.0,              product.price
    assert_equal 'Child category 2', product.category.name
    assert_equal 1,                  product.project.id
    assert_equal 'Inactive',         product.status
    assert_equal 'EUR',              product.currency
  end

  protected

  def generate_import(fixture_name='new_product.csv')
    import = ProductImport.new
    import.user_id = 2
    import.file = Rack::Test::UploadedFile.new(fixture_files_path + fixture_name, 'text/csv')
    import.save!
    import
  end

  def generate_import_with_mapping(fixture_name='new_product.csv')
    import = generate_import(fixture_name)

    import.settings = {
      'separator' => ',',
      'wrapper' => '"',
      'encoding' => 'UTF-8',
      'date_format' => '%m/%d/%Y',
      'mapping' => {'project_id' => '1', 'code' => '1', 'name' => '2', 'description' => '3', 'price' => '4', 'category' => '5', 'author' => '7', 'status' => '8', 'currency' => '9'}
    }
    import.save!
    import
  end
end if Redmine::VERSION.to_s >= '4.1'
