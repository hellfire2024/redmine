class IssueMailsController < ApplicationController
  menu_item :issues

  before_action :find_issues, :authorize_global
  before_action :find_report_templates, only: :new
  before_action :find_attachments, :find_optional_project, only: :send_mail

  def new
    if @issues.count == 1
      @issue = @issues.first
      reports = @report_templates.map { |template| template.generate_reports([@issue]) }.flatten
      reports.each { |report| apply_layout!(report.content, 'reports') }

      @issue_mail = IssueMail.new({
        from: User.current.mail,
        subject: @issue.subject,
        attachments: reports.map(&:create_attachment)
      })
    else
      reports = @report_templates.map { |t| t.generate_reports(@issues, params[:query_id]) }.flatten
      reports.each { |report| apply_layout!(report.content, 'reports') }
      subject = @issues.map(&:subject).join('; ')

      @issue_mail = IssueMail.new({
        from: User.current.mail,
        subject: subject,
        attachments: reports.map(&:create_attachment)
      })
    end
  end

  def send_mail
    @issue_mail = IssueMail.new(params[:issue_mail])
    @issue_mail.attachments = @attachments

    render(:new) && return if @issue_mail.invalid?

    begin
      ReportsMailer.issue_reports(@issue_mail).deliver
    rescue Exception => e
      flash[:error] = l(:notice_email_error, e.message)
      render(:new) && return
    end

    flash[:notice] = l(:notice_email_sent, @issue_mail.to)

    if @issues.count == 1
      redirect_to issue_path(@issues.first)
    else
      redirect_to issues_path(@project)
    end
  end

  def preview
    @text = params[:issue_mail][:message]
    render partial: 'common/preview'
  end

  private

  def find_issues
    @issues = Issue.where(id: params[:issue_ids])
  rescue ActiveRecord::RecordNotFound
    render_404
  end

  def find_optional_project
    find_project_by_project_id if params[:project_id].present?
  end
end
