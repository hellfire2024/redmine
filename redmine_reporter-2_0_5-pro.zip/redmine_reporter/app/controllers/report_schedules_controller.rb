class ReportSchedulesController < ApplicationController
  before_action :find_report_schedule, only: [:edit, :update, :destroy, :test]
  before_action :find_project
  before_action :authorize_global
  before_action :find_recipients, only: [:create, :update]

  def new
    @report_schedule = ReportSchedule.new(project: @project, start_date: User.current.today)
  end

  def create
    @report_schedule = ReportSchedule.new
    @report_schedule.safe_attributes = params[:report_schedule]
    @report_schedule.recipients = @recipients

    if @report_schedule.save
      flash[:notice] = l(:notice_successful_create)
      @report_schedule.project ? redirect_to_report_templates_tab : redirect_to_report_templates_settings
    else
      render :new
    end
  end

  def edit
  end

  def update
    @report_schedule.safe_attributes = params[:report_schedule]
    @report_schedule.recipients = @recipients

    if @report_schedule.save
      flash[:notice] = l(:notice_successful_update)
      @report_schedule.project ? redirect_to_report_templates_tab : redirect_to_report_templates_settings
    else
      render :edit
    end
  end

  def destroy
    @report_schedule.destroy
    flash[:notice] = l(:notice_successful_delete)
    @report_schedule.project ? redirect_to_report_templates_tab : redirect_to_report_templates_settings
  end

  def autocomplete_for_user
    @users = User.active.sorted.like(params[:q]).limit(10)
    @users = @users.to_a
    render layout: false
  end

  def test
    ReportScheduleMailer.deliver_report_schedule(@report_schedule)
    flash[:notice] = l(:notice_successful_test)
    @report_schedule.project ? redirect_to_report_templates_tab : redirect_to_report_templates_settings
  end

  def get_queries
    template_type = ReportTemplate.find(params_template)

    if template_type.is_a?(IssueReportTemplate) || template_type.is_a?(IssueListReportTemplate)
      @queries = ::IssueQuery.where(user_id: User.current.id).pluck(:id, :name)
    elsif template_type.is_a?(TimeEntriesReportTemplate)
      @queries = ::TimeEntryQuery.where(user_id: User.current.id).pluck(:id, :name)
    else
      []
    end

    render json: @queries
  end

  private

  def find_project
    @project = params_project_id.present? ? Project.find(params_project_id) : @report_schedule.try(:project)
  end

  def redirect_to_report_templates_tab
    redirect_to settings_project_path(@report_schedule.try(:project), tab: 'report_templates')
  end

  def redirect_to_report_templates_settings
    redirect_to plugin_settings_path('redmine_reporter', tab: 'report_templates')
  end

  def find_report_schedule
    @report_schedule = ReportSchedule.find(params[:id])
  rescue ActiveRecord::RecordNotFound
    render_404
  end

  def find_recipients
    @recipients = recipient_ids ? User.find(recipient_ids) : []
  rescue ActiveRecord::RecordNotFound
    render_404
  end

  def recipient_ids
    params[:report_schedule][:recipient_ids] if params[:report_schedule]
  end

  def params_project_id
    params[:project_id] || report_schedule_project_id
  end

  def report_schedule_project_id
    params[:report_schedule][:project_id] if params[:report_schedule]
  end

  def params_template
    params[:report_template_id]
  end
end
