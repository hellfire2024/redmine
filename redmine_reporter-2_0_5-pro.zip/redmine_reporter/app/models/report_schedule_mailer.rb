class ReportScheduleMailer < Mailer
  SENDING_METHOD = ('deliver_later').freeze
  MACRO_LIST = ['{{public_link}}'].freeze

  def report_schedule_mail(user, report_schedule)
    report_schedule.reports.each { |x| attachments[x.filename] = x.to_pdf }
    @message_content = message_content(report_schedule)
    mail to: user, subject: report_schedule.email_subject.to_s
  end

  def self.deliver_report_schedule(report_schedule)
    report_schedule.notified_users.each do |user|
      report_schedule_mail(user, report_schedule).send(SENDING_METHOD)
    end
  end

  private

  def report_schedule_public_link_url(schedule)
    case schedule.report_template
    when IssueReportTemplate, IssueListReportTemplate
      preview_issues_report_templates_url(schedule.public_link_params)
    when TimeEntriesReportTemplate
      preview_time_entries_reports_url(schedule.public_link_params)
    end
  end

  def apply_macros(text, report_schedule)
    text.to_s.gsub(/{{public_link}}/, report_schedule_public_link_url(report_schedule))
  end

  def message_content(report_schedule)
    apply_macros(report_schedule.email_template, report_schedule).html_safe
  end
end
