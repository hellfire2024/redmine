class CreateReportSchedules < ActiveRecord::Migration[4.2]
  def change
    create_table :report_schedules do |t|
      t.references :project, index: true, foreign_key: true
      t.references :report_template, foreign_key: true, null: false
      t.references :query, foreign_key: true, null: false

      t.string :repeat, null: false
      t.datetime :start_date, null: false
      t.datetime :end_date

      t.string :email_subject
      t.text :email_template

      t.timestamps null: false
    end

    create_table :report_schedules_users, id: false do |t|
      t.references :report_schedule, index: true, foreign_key: true, null: false
      t.references :user, index: true, foreign_key: true, null: false
    end
  end
end
