class AddOrientationToReportTemplates < ActiveRecord::Migration[4.2]
  def change
    add_column :report_templates, :orientation, :integer, default: 0
  end
end
