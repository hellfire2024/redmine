require 'zip'

module RedmineReporter
  SETTINGS_TABS = [
    { name: 'general', partial: 'settings/reporter/general', label: :label_general },
    { name: 'report_templates', partial: 'report_templates/index', label: :label_reporter_report_templates }
  ]

  def self.settings() Setting.plugin_redmine_reporter end

  def self.public_links?
    settings['public_links'] == '1'
  end

  def self.token(object_ids, report_template_ids)
    str = object_ids.inject('') { |str, id| str + "Object##{id}" }
    str += report_template_ids.inject('') { |str, id| str + "ReportTemplate##{id}" }
    secret = Rails.version > '6.0' ? Rails.application.config.secret_key_base : Rails.application.config.secret_token
    Digest::MD5.hexdigest("#{str}:#{secret}")
  end

  def self.build_zip(reports)
    Zip::OutputStream.write_buffer do |zos|
      reports.each do |report|
        zos.put_next_entry report.filename
        zos.write report.to_pdf
      end
    end.string
  end
end

REDMINE_REPORTER_REQUIRED_FILES = [
  'redmine_reporter/hooks/views_layouts_hook',
  'redmine_reporter/hooks/view_issues_hook',
  'redmine_reporter/hooks/views_context_menus_hook',
  'redmine_reporter/patches/application_controller_patch',
  'redmine_reporter/patches/issue_patch',
  'redmine_reporter/patches/time_entry_patch',
  'redmine_reporter/patches/user_patch',
  'redmine_reporter/patches/application_helper_patch',
  'redmine_reporter/patches/projects_helper_patch',
  'redmine_reporter/liquid/filters',
  'redmine_reporter/liquid/drops/issues_drop',
  'redmine_reporter/liquid/drops/attachment_images_drop'
]

REDMINE_REPORTER_REQUIRED_FILES << 'redmine_reporter/patches/my_page_patch'
REDMINE_REPORTER_REQUIRED_FILES << 'redmine_reporter/patches/my_helper_patch'

base_url = File.dirname(__FILE__)
REDMINE_REPORTER_REQUIRED_FILES.each { |file| require(base_url + '/' + file) }
