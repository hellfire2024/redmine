module RedmineReporter
  module Patches
    module MyControllerPatch
      def self.included(base)
        base.class_eval do
          include InstanceMethods
        end
      end

      module InstanceMethods
        def update_page
          @user = User.current
          block_settings = params[:settings] || {}

          block_settings.each do |block, settings|
            @user.pref.update_block_settings(block, settings)
          end

          @user.pref.save
          @updated_blocks = block_settings.keys

          render partial: 'update_page'
        end
      end
    end
  end
end

unless MyController.included_modules.include?(RedmineReporter::Patches::MyControllerPatch)
  MyController.send(:include, RedmineReporter::Patches::MyControllerPatch)
end
