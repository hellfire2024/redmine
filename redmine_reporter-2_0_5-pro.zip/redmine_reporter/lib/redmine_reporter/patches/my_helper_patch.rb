require 'redmine/my_page'

module RedmineReporter
  module Patches
    module MyHelperPatch
      def self.included(base)
        base.class_eval do
          include InstanceMethods

          alias_method :render_block_without_reporter, :render_block
          alias_method :render_block, :render_block_with_reporter
        end
      end

      module InstanceMethods
        def render_block_with_reporter(block, user)
          return '' if %w(report_by_issues report_by_spent_time).include?(block) && !user.allowed_to?(:view_time_entries, nil, global: true)

          render_block_without_reporter(block, user)
        end
      end
    end
  end
end

unless MyHelper.included_modules.include?(RedmineReporter::Patches::MyHelperPatch)
  MyHelper.send(:include, RedmineReporter::Patches::MyHelperPatch)
end
