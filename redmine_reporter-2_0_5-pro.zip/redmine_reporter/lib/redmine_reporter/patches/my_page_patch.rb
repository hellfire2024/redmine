require 'redmine/my_page'

module RedmineReporter
  module Patches
    module MyPagePatch
      def self.included(base)
        base.extend(ClassMethods)
        base.class_eval do
          class << self
            alias_method :additional_blocks_without_reporter, :additional_blocks
            alias_method :additional_blocks, :additional_blocks_with_reporter

            alias_method :block_options_without_reporter, :block_options
            alias_method :block_options, :block_options_with_reporter
          end
        end
      end

      module ClassMethods
        def additional_blocks_with_reporter
          @@additional_blocks ||= begin
            blocks = additional_blocks_without_reporter
            blocks['report_by_issues'][:max_occurs] = 10
            blocks['report_by_spent_time'][:max_occurs] = 10
            blocks
          end
        end

        def block_options_with_reporter(blocks_in_use=[])
          options = block_options_without_reporter(blocks_in_use)
          unless User.current.allowed_to?(:view_time_entries, nil, global: true)
            options = options.filter { |option| %w(report_by_issues report_by_spent_time).exclude?(option.try(:last).try(:split, '__').try(:first)) }
          end
          options
        end
      end
    end
  end
end

unless Redmine::MyPage.included_modules.include?(RedmineReporter::Patches::MyPagePatch)
  Redmine::MyPage.send(:include, RedmineReporter::Patches::MyPagePatch)
end
