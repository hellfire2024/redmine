require File.expand_path('../../test_helper', __FILE__)

class RedmineReporter::CommonViewsTest <  Redmine::ApiTest::Base
  include Redmine::I18n

  fixtures :projects, :users, :user_preferences, :roles, :members, :member_roles,
           :issues, :issue_statuses, :issue_relations, :versions, :trackers, :projects_trackers,
           :issue_categories, :enabled_modules, :enumerations, :attachments, :workflows

  def test_view_plugin_reporter_settings
    log_user('admin', 'admin')
    get '/settings/plugin/redmine_reporter?tab=report_templates'
    assert_response :success
    assert_select "a", text: "Preview"
  end

  def test_for_no_preview_button_if_there_are_no_issue
    log_user('dlopper', 'foo')
    current_user = User.find(session[:user_id])
    project = current_user.projects.first
    current_user.roles_for_project(project).first.permissions.delete(:view_issues)
    get "/projects/#{project.identifier}/settings/redmine_reporter"
    assert_response :success
    assert_select "a", {count: 0, text: "Preview"}
  end
end
