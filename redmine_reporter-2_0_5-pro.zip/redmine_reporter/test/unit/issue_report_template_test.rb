require File.expand_path('../../test_helper', __FILE__)

class IssueReportTemplateTest < ActiveSupport::TestCase
  fixtures :projects, :users, :user_preferences, :roles, :members, :member_roles,
           :issues, :issue_statuses, :issue_relations, :versions, :trackers, :projects_trackers, :issue_categories, :attachments

  create_fixtures(redmine_reporter_fixtures_directory, [:report_templates])

  def setup
    @template = IssueReportTemplate.find(1)
    @template_with_name = IssueReportTemplate.find(8)
  end

  def test_should_generate_issue_report
    issue = Issue.find(1)
    reports = @template.generate_reports([issue])
    assert reports.size == 1
    check_report @template, reports.first, issue, "<h1>Issue report example</h1><hr>#{issue.subject}"
  end

  def test_should_generate_issue_reports
    issues = Issue.find(1, 2, 3, 4)
    reports = @template.generate_reports(issues)
    assert reports.size == issues.size
    reports.each_with_index { |report, index| check_report(@template, report, issues[index], "<h1>Issue report example</h1><hr>#{issues[index].subject}") }
  end

  def test_should_generate_issue_report_with_name
    User.current = User.find(1)
    issue = Issue.find(1)
    reports = @template_with_name.generate_reports([issue])
    assert reports.size == 1
    check_report @template_with_name, reports.first, issue, "<h1>Issue report example</h1><hr>Redmine Admin"
  end

  private

  def check_report(template, report, issue, expected_content)
    expected_report = Report.new(
      "#{template.name} (##{issue.id})",
      template.filename('.pdf', issue: issue),
      expected_content,
      template.public_link_params(issue),
      report.orientation
    )
    assert_equal expected_report.report_name, report.report_name
    assert_equal expected_report.filename, report.filename
    assert_equal expected_report.content, report.content
    assert_equal expected_report.orientation, report.orientation
  end
end
