require File.expand_path('../../test_helper', __FILE__)

class ReportScheduleTest < ActiveSupport::TestCase
  def test_report_schedule_actual_status_on_repeat_daily
    assert_actual '2020-01-01', repeat: ReportSchedule::DAILY, start_date: '2020-01-01'
    assert_actual '2020-01-02', repeat: ReportSchedule::DAILY, start_date: '2020-01-01'
    assert_actual '2021-01-01', repeat: ReportSchedule::DAILY, start_date: '2020-01-01'
    assert_actual '2020-02-28', repeat: ReportSchedule::DAILY, start_date: '2019-02-28'
    assert_actual '2020-02-29', repeat: ReportSchedule::DAILY, start_date: '2019-02-28'
    assert_actual '2020-01-15', repeat: ReportSchedule::DAILY, start_date: '2020-01-01', end_date: '2020-01-31'

    assert_not_actual '2019-01-01', repeat: ReportSchedule::DAILY, start_date: '2020-01-01'
    assert_not_actual '2019-12-31', repeat: ReportSchedule::DAILY, start_date: '2020-01-01'
    assert_not_actual '2020-02-01', repeat: ReportSchedule::DAILY, start_date: '2020-01-01', end_date: '2020-01-31'
  end

  def test_report_schedule_actual_status_on_repeat_weekly
    assert_actual '2020-01-01', repeat: ReportSchedule::WEEKLY, start_date: '2020-01-01'
    assert_actual '2020-01-08', repeat: ReportSchedule::WEEKLY, start_date: '2020-01-01'
    assert_actual '2020-05-06', repeat: ReportSchedule::WEEKLY, start_date: '2020-01-01'
    assert_actual '2021-05-07', repeat: ReportSchedule::WEEKLY, start_date: '2020-01-31'
    assert_actual '2020-01-20', repeat: ReportSchedule::WEEKLY, start_date: '2020-01-06', end_date: '2020-01-31'

    assert_not_actual '2019-12-25', repeat: ReportSchedule::WEEKLY, start_date: '2020-01-01'
    assert_not_actual '2020-01-02', repeat: ReportSchedule::WEEKLY, start_date: '2020-01-01'
    assert_not_actual '2020-02-03', repeat: ReportSchedule::WEEKLY, start_date: '2020-01-06', end_date: '2020-01-31'
  end

  def test_report_schedule_actual_status_on_repeat_monthly
    assert_actual '2020-01-01', repeat: ReportSchedule::MONTHLY, start_date: '2020-01-01'
    assert_actual '2020-02-01', repeat: ReportSchedule::MONTHLY, start_date: '2020-01-01'
    assert_actual '2020-12-01', repeat: ReportSchedule::MONTHLY, start_date: '2020-01-01'
    assert_actual '2021-03-15', repeat: ReportSchedule::MONTHLY, start_date: '2020-01-15'
    assert_actual '2021-01-31', repeat: ReportSchedule::MONTHLY, start_date: '2020-01-31'

    assert_actual '2019-05-28', repeat: ReportSchedule::MONTHLY, start_date: '2019-02-28'
    assert_actual '2020-02-28', repeat: ReportSchedule::MONTHLY, start_date: '2019-02-28'
    assert_actual '2021-02-28', repeat: ReportSchedule::MONTHLY, start_date: '2020-02-29'
    assert_actual '2024-02-29', repeat: ReportSchedule::MONTHLY, start_date: '2020-02-29'
    assert_actual '2020-02-29', repeat: ReportSchedule::MONTHLY, start_date: '2019-11-30'
    assert_actual '2021-02-28', repeat: ReportSchedule::MONTHLY, start_date: '2019-11-30'
    assert_actual '2020-05-30', repeat: ReportSchedule::MONTHLY, start_date: '2019-11-30'
    assert_actual '2020-02-29', repeat: ReportSchedule::MONTHLY, start_date: '2020-01-31'
    assert_actual '2020-04-30', repeat: ReportSchedule::MONTHLY, start_date: '2020-01-31'

    assert_actual '2020-02-01', repeat: ReportSchedule::MONTHLY, start_date: '2020-01-01', end_date: '2020-02-01'

    assert_not_actual '2019-12-01', repeat: ReportSchedule::MONTHLY, start_date: '2020-01-01'
    assert_not_actual '2020-01-02', repeat: ReportSchedule::MONTHLY, start_date: '2020-01-01'
    assert_not_actual '2020-02-02', repeat: ReportSchedule::MONTHLY, start_date: '2020-01-01'
    assert_not_actual '2020-12-31', repeat: ReportSchedule::MONTHLY, start_date: '2020-01-01'
    assert_not_actual '2020-03-01', repeat: ReportSchedule::MONTHLY, start_date: '2020-01-01', end_date: '2020-02-01'
  end

  def test_report_schedule_actual_status_on_repeat_quarterly
    assert_actual '2020-01-01', repeat: ReportSchedule::QUARTERLY, start_date: '2020-01-01'
    assert_actual '2020-04-01', repeat: ReportSchedule::QUARTERLY, start_date: '2020-01-01'
    assert_actual '2020-07-01', repeat: ReportSchedule::QUARTERLY, start_date: '2020-01-01'
    assert_actual '2020-10-01', repeat: ReportSchedule::QUARTERLY, start_date: '2020-01-01'
    assert_actual '2021-01-01', repeat: ReportSchedule::QUARTERLY, start_date: '2020-01-01'

    assert_actual '2020-04-15', repeat: ReportSchedule::QUARTERLY, start_date: '2020-01-15'
    assert_actual '2021-01-15', repeat: ReportSchedule::QUARTERLY, start_date: '2020-01-15'

    assert_actual '2019-05-28', repeat: ReportSchedule::QUARTERLY, start_date: '2019-02-28'
    assert_actual '2020-02-28', repeat: ReportSchedule::QUARTERLY, start_date: '2019-02-28'
    assert_actual '2021-02-28', repeat: ReportSchedule::QUARTERLY, start_date: '2020-02-29'
    assert_actual '2024-02-29', repeat: ReportSchedule::QUARTERLY, start_date: '2020-02-29'
    assert_actual '2020-02-29', repeat: ReportSchedule::QUARTERLY, start_date: '2019-11-30'
    assert_actual '2021-02-28', repeat: ReportSchedule::QUARTERLY, start_date: '2019-11-30'
    assert_actual '2020-05-30', repeat: ReportSchedule::QUARTERLY, start_date: '2019-11-30'
    assert_actual '2020-02-29', repeat: ReportSchedule::QUARTERLY, start_date: '2019-05-31'
    assert_actual '2019-11-30', repeat: ReportSchedule::QUARTERLY, start_date: '2019-05-31'

    assert_actual '2020-01-01', repeat: ReportSchedule::QUARTERLY, start_date: '2020-01-01', end_date: '2020-06-01'
    assert_actual '2020-04-01', repeat: ReportSchedule::QUARTERLY, start_date: '2020-01-01', end_date: '2020-06-01'

    assert_not_actual '2019-01-01', repeat: ReportSchedule::QUARTERLY, start_date: '2020-01-01'
    assert_not_actual '2020-02-01', repeat: ReportSchedule::QUARTERLY, start_date: '2020-01-01'
    assert_not_actual '2020-03-01', repeat: ReportSchedule::QUARTERLY, start_date: '2020-01-01'
    assert_not_actual '2020-07-01', repeat: ReportSchedule::QUARTERLY, start_date: '2020-01-01', end_date: '2020-06-01'
  end

  def test_report_schedule_actual_status_on_repeat_yearly
    assert_actual '2020-01-01', repeat: ReportSchedule::YEARLY, start_date: '2020-01-01'
    assert_actual '2021-01-01', repeat: ReportSchedule::YEARLY, start_date: '2020-01-01'
    assert_actual '2021-01-15', repeat: ReportSchedule::YEARLY, start_date: '2020-01-15'
    assert_actual '2021-01-31', repeat: ReportSchedule::YEARLY, start_date: '2020-01-31'

    assert_actual '2020-02-28', repeat: ReportSchedule::YEARLY, start_date: '2019-02-28'
    assert_actual '2021-02-28', repeat: ReportSchedule::YEARLY, start_date: '2020-02-29'
    assert_actual '2024-02-29', repeat: ReportSchedule::YEARLY, start_date: '2020-02-29'

    assert_actual '2020-01-01', repeat: ReportSchedule::YEARLY, start_date: '2020-01-01', end_date: '2020-01-01'
    assert_actual '2020-01-01', repeat: ReportSchedule::YEARLY, start_date: '2020-01-01', end_date: '2020-12-31'
    assert_actual '2021-01-01', repeat: ReportSchedule::YEARLY, start_date: '2020-01-01', end_date: '2021-01-01'

    assert_not_actual '2020-02-29', repeat: ReportSchedule::YEARLY, start_date: '2019-02-28'
    assert_not_actual '2019-01-01', repeat: ReportSchedule::YEARLY, start_date: '2020-01-01'
    assert_not_actual '2020-01-02', repeat: ReportSchedule::YEARLY, start_date: '2020-01-01'
    assert_not_actual '2020-12-31', repeat: ReportSchedule::YEARLY, start_date: '2020-01-01'
    assert_not_actual '2021-01-01', repeat: ReportSchedule::YEARLY, start_date: '2020-01-01', end_date: '2020-01-01'
  end

  private

  def assert_actual(date, attributes = {})
    travel_to(date.to_date) { assert ReportSchedule.new(attributes).actual? }
  end

  def assert_not_actual(date, attributes = {})
    travel_to(date.to_date) { assert_not ReportSchedule.new(attributes).actual? }
  end
end
