# This file is a part of Redmine Resources (redmine_resources) plugin,
# resource allocation and management for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_resources is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_resources is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_resources.  If not, see <http://www.gnu.org/licenses/>.

class ResourceIssuesController < ApplicationController
  menu_item :resources

  before_action :find_optional_project
  before_action :find_issue, only: [:edit, :update]
  before_action :update_issue_from_params, :set_user_blocks_to_update, only: :update

  helper :issues
  helper :resource_bookings
  helper :queries
  include QueriesHelper

  def index
    retrieve_query

    if @query.valid?
      respond_to do |format|
        format.html do
          @rb_chart = RedmineResources::Charts::ResourceIssuesChart.new(@project, @query, params)
        end
      end
    end
  end

  def edit
  end

  def update
    calculate_issue_dates

    if @issue.save
      respond_to do |format|
        format.js do
          render_update_chart l(:notice_successful_update)
        end
      end
    end
  end

  private

  # Retrieve query from session or build a new query
  def retrieve_query
    session_key = :resource_issues_query
    if params[:query_id].present?
      cond = 'project_id IS NULL'
      cond << " OR project_id = #{@project.id}" if @project
      @query = ResourceIssuesQuery.where(cond).find(params[:query_id])
      raise ::Unauthorized unless @query.visible?
      @query.project = @project
      session[session_key][:options][:date_from] = params[:date_from].to_date if params[:date_from]
      @query.date_from = session[session_key][:options][:date_from]
    elsif params[:set_filter] || session[session_key].nil? || session[session_key][:project_id] != (@project ? @project.id : nil)
      # Give it a name, required to be valid
      @query = ResourceIssuesQuery.new(name: '_', project: @project)
      @query.build_from_params(params)
      session[session_key] = { project_id: @query.project_id, filters: @query.filters, options: @query.options }
    else
      # retrieve from session
      session[session_key][:options][:date_from] = params[:date_from].to_date if params[:date_from]
      @query = ResourceIssuesQuery.new(name: '_', filters: session[session_key][:filters], options: session[session_key][:options])
      @query.project = @project
    end
    @query
  end

  def update_issue_from_params
    @issue.init_journal(User.current)
    @issue.safe_attributes = params['issue']
  end

  def set_user_blocks_to_update
    retrieve_query

    if @issue.assigned_to_id?
      @query.add_filter('assigned_to_id', '=', [@issue.assigned_to_id.to_s])
    else
      @query.add_filter('assigned_to_id', '!*')
    end

    return unless @query.valid?
    assigned_to_id = @issue.assigned_to_id? ?  @issue.assigned_to_id : 'unassigned_issues'
    @user_blocks = { assigned_to_id => RedmineResources::Charts::ResourceIssuesChart.new(@project, @query) }
    assigned_to_id_was = @issue.assigned_to_id_was

    if @issue.assigned_to_id != assigned_to_id_was
      query = @query.dup

      if assigned_to_id_was
        query.add_filter('assigned_to_id', '=', [assigned_to_id_was.to_s])
      else
        query.add_filter('assigned_to_id', '!*')
        assigned_to_id_was = 'unassigned_issues'
      end

      @user_blocks[assigned_to_id_was] = RedmineResources::Charts::ResourceIssuesChart.new(@project, query)
    end
  end

  def render_update_chart(notice)
    flash.now[:notice] = notice

    if @user_blocks
      render partial: 'update_chart', locals: { resize: true }
    else
      render js: "window.location = '#{index_path}'"
    end
  end

  def index_path
    @project ? project_resource_issues_path(@project) : resource_issues_path
  end

  def find_issue
    @issue = Issue.find(params[:id])
  end

  def calculate_issue_dates
    chart_start_date = @query.date_from
    chart_end_date = @query.date_to

    if params[:start_date_offset] && params[:end_date_offset]
      @issue.start_date = @issue.start_date + params[:start_date_offset].to_i.days
      @issue.due_date = @issue.end_date_by_available_attribute + params[:end_date_offset].to_i.days
    elsif params[:start_date_offset]
      @issue.start_date = [@issue.start_date, chart_start_date].max + params[:start_date_offset].to_i.days
    elsif params[:end_date_offset]
      @issue.due_date = [@issue.end_date_by_available_attribute, chart_end_date].min + params[:end_date_offset].to_i.days
    end
  end
end
