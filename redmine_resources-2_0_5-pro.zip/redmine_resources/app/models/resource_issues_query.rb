# This file is a part of Redmine Resources (redmine_resources) plugin,
# resource allocation and management for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_resources is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_resources is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_resources.  If not, see <http://www.gnu.org/licenses/>.

class ResourceIssuesQuery < ResourceQuery
  include Redmine::Utils::DateCalculation

  CHART_TYPE = 'issues_chart'.freeze
  
  self.queried_class = Issue

  def base_scope(from, to)
    scope = Issue.visible.includes(:assigned_to, :project).
              where(issues_where_clause, from: from, to: to, workday_length: workday_length).
              where.not(start_date: nil)

    if RedmineResources.people_pro_plugin_installed? && filters_require_person_information?
      scope = scope.joins("LEFT JOIN people_information ON people_information.user_id = issues.assigned_to_id")
    end

    scope
  end

  def resource_issues_between(from, to)
    base_scope(from, to).where(statement)
  end

  def resource_issues_by_users(from, to)
    scope = issues_between(from, to)
    if has_filter?('assigned_to_id')
      scope = scope.where(sql_by_filter('assigned_to_id', Issue.table_name, 'assigned_to_id'))
    end
    scope
  end

  def issues_between(from, to)
    base_scope(from, to)
  end

  def chart_resource_issues(from, to)
    resource_issues_between(from, to)
  end

  def date_from; options[:date_from].to_date end
  def date_from=(arg); options[:date_from] = arg.to_s end

  def date_to; options[:date_to].to_date end

  def date_to=(arg)
    months = (arg || User.current.pref[:resource_issues_months]).to_i
    months = (months > 0 && months < 25) ? months : 2
    options[:date_to] = ((date_from >> months) - 1).to_s
  end

  def chart_type
    CHART_TYPE
  end

  def build_from_params(params)
    super
    self.date_from = params[:date_from] || params.dig(:query, :date_from) || RedmineResources.beginning_of_week
    self.line_title_type = params[:line_title_type] || params.dig(:query, :line_title_type) || default_line_title_type
    self.date_to = params[:months]
    self
  end

  private

  def statement
    filters['id'] = filters.delete('issue_id') if value_for('issue_id')

    super
  end

  def line_title_types
    RedmineResources::Charts::ResourceIssuesChart::LINE_TITLE_TYPES
  end

  def default_line_title_type
    RedmineResources::Charts::ResourceIssuesChart::ISSUE_SUBJECT
  end

  def issues_where_clause
    adapter_name = ActiveRecord::Base.connection.adapter_name.downcase

    interval_expression = case adapter_name
    when 'postgresql'
      "(estimated_hours / :workday_length || ' days')::interval"
    when 'mysql2'
      "INTERVAL FLOOR(estimated_hours / :workday_length) DAY"
    when 'sqlserver'
      "CAST(estimated_hours / :workday_length AS INT)"
    when 'sqlite'
      "(estimated_hours / :workday_length)"
    end

    "(start_date >= :from AND start_date <= :to) OR " \
    "(due_date >= :from AND due_date <= :to) OR " \
    "(due_date IS NULL AND estimated_hours IS NOT NULL AND " \
    "start_date + #{interval_expression} >= :from AND " \
    "start_date + #{interval_expression} <= :to)"
  end

  def workday_length
    RedmineResources.default_workday_length
  end
end
