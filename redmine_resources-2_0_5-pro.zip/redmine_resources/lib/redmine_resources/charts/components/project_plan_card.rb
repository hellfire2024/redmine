# This file is a part of Redmine Resources (redmine_resources) plugin,
# resource allocation and management for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_resources is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_resources is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_resources.  If not, see <http://www.gnu.org/licenses/>.

module RedmineResources
  module Charts
    module Components
      class ProjectPlanCard < BaseComponent
        def initialize(is_workday, scheduled_hours, workday_length, workload_percent, options = {})
          @is_workday = is_workday
          @planned_hours = scheduled_hours
          @workday_length = workday_length
          @workload_percent =  workload_percent
          @options = options
        end

        def render
          if @planned_hours > 0
            <<-HTML.html_safe
              <div class="small-booking-card#{'-dayoff' if %i(dayoff holiday).include?(@is_workday)} booking">
                <p class="hours">#{l(:label_resources_f_hour_short, value: @planned_hours)}</p>
                <p class="percent">#{render_percent if @options[:show_percent]}</p>
              </div>
            HTML
          end
        end

        private

        def render_percent
          "#{@workload_percent}%" unless %i(dayoff holiday).include?(@is_workday)
        end
      end
    end
  end
end
