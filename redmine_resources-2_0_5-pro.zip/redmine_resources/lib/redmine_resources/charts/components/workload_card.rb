# This file is a part of Redmine Resources (redmine_resources) plugin,
# resource allocation and management for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_resources is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_resources is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_resources.  If not, see <http://www.gnu.org/licenses/>.

module RedmineResources
  module Charts
    module Components
      class WorkloadCard < BaseComponent
        def initialize(resource_bookings, time_entries, user_capacity)
          @user_capacity = user_capacity
          @interval_type = @user_capacity[:interval_type] || @user_capacity[:day_type]
          @available_workhours = @user_capacity[:available_workhours] || @user_capacity[:workday_length]
          @scheduled_hours = @user_capacity[:scheduled_hours]
          @overload = @user_capacity[:overload]
          @workload_percent = @user_capacity[:workload_percent]

          @resource_bookings = resource_bookings
          @time_entries = time_entries
          @spent_hours = to_int_if_whole(@time_entries.sum(&:hours))
        end

        def render(options = {})
          if @interval_type || @spent_hours > 0
            <<-HTLM.html_safe
              <div class="workload-card #{color_css_class(options)}">
                #{render_workload_percent if options[:show_percent]}
                <div class="tooltip workload">
                  #{render_workload_ratio(options)}
                  #{html_tooltip_for_user}
                </div>
                #{render_spent_time if options[:show_spent_time]}
              </div>
            HTLM
          end
        end

        def render_for_utilization_report(options = {})
          if @interval_type || @spent_hours > 0
            <<-HTLM.html_safe
              <div class="workload-card #{color_css_class(options)}">
                #{render_spent_time if options[:show_spent_time]}
                <div class="tooltip">
                  #{render_planned_hours_and_workday_length_ratio if options[:show_hours]}
                  #{html_tooltip_for_user}
                </div>
                #{render_workload_percent if options[:show_percent]}
              </div>
            HTLM
          end
        end

        private

        def render_workload_ratio(options = {})
          options[:workload_type] == 'hours' ? render_planned_hours_and_workday_length_ratio : render_workload_percent_and_workday_length_ratio
        end

        def render_planned_hours_and_workday_length_ratio
          "<p>#{to_int_if_whole(@scheduled_hours)}/#{to_int_if_whole(@available_workhours)}</p>"
        end

        def render_workload_percent_and_workday_length_ratio
          "<p>#{to_int_if_whole(@workload_percent)}%/#{to_int_if_whole(@available_workhours)}</p>"
        end

        def render_workload_percent
          "<div class='percent'>#{@workload_percent}%</div>"
        end

        def render_spent_time
          if @time_entries.present?
            time_entries_filter = { set_filter: '1', user_id: @time_entries.first.user_id, spent_on: @time_entries.first.spent_on }

            "<div class='spent-time'>
              #{link_to(l(:label_resources_f_hour_short, value: @spent_hours), time_entries_path(time_entries_filter), style: 'color: white;')}
            </div>"
          else
            "<div class='spent-time'>
              #{l(:label_resources_f_hour_short, value: @spent_hours)}
            </div>"
          end
        end

        def html_tooltip_for_user
          s = render_load_tooltip(@overload, @available_workhours)
          s = content_tag(:span, s.html_safe, class: 'tip')
        end

        def color_css_class(options = {})
          options[:workload_type] == 'percent' ? color_css_class_for_percent_workload : color_css_class_for_hours_workload
        end

        def color_css_class_for_hours_workload
          if @interval_type == :dayoff
            'gray'
          elsif @scheduled_hours == @available_workhours
            'full'
          elsif @scheduled_hours > @available_workhours
            'red'
          else
            'green'
          end
        end

        def color_css_class_for_percent_workload
          if @interval_type == :dayoff
            'gray'
          elsif @workload_percent < 95
            'green'
          elsif @workload_percent > 100
            'red'
          else
            'full'
          end
        end
      end
    end
  end
end
