# This file is a part of Redmine Resources (redmine_resources) plugin,
# resource allocation and management for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_resources is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_resources is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_resources.  If not, see <http://www.gnu.org/licenses/>.

module RedmineResources
  module Charts
    module Helpers
      class MonthPlan
        attr_reader :date_title, :allocated_hours, :workload_card, :booked_cards, :unbooked_cards, :interval_type, :spent_hours

        def initialize(date, resource_bookings, time_entries, user_capacity, total_bookings_workday_count)
          @date = date
          @month_start = date.beginning_of_month
          @month_end = date.end_of_month
          @date_title = I18n.l(@month_start, format: '%b %Y')
          @user_capacity = user_capacity[@month_start.strftime('%Y-%m')]
          @total_bookings_workday_count = total_bookings_workday_count
          @resource_bookings = filter_bookings_by_month(resource_bookings)
          @allocated_hours = @user_capacity[:scheduled_hours]
          @time_entries = filter_time_entries_by_week(time_entries)
          @booked_time_entries = find_booked_time_entries
          @unbooked_time_entries = @time_entries - @booked_time_entries
          @spent_hours = @time_entries.sum(&:hours)
          @interval_type = @user_capacity[:interval_type]

          @workload_card =  if @interval_type == :dayoff
                              Components::DayoffCard.new
                            else
                              Components::WorkloadCard.new(@resource_bookings, @time_entries, @user_capacity)
                            end

          @booked_cards = build_booked_cards
          @unbooked_cards = build_unbooked_cards
        end

        private

        def build_booked_cards
          time_entries_by_project_and_issue = @time_entries.group_by do |time_entry|
            key_by(time_entry.project, time_entry.issue)
          end

          @resource_bookings.inject([]) do |booked_cards, resource_booking|
            issue = resource_booking.issue
            project = resource_booking.project
            time_entries = time_entries_by_project_and_issue[key_by(project, issue)] || []

            if @interval_type || time_entries.present?
              planned_hours = @user_capacity[:scheduled_bookings][resource_booking.id]
              workday_count = @total_bookings_workday_count[resource_booking.id]
              booked_cards << Components::BookedCard.new(resource_booking.start_date, issue, project, resource_booking, time_entries, @user_capacity, workday_count, :month)
            end

            booked_cards
          end
        end

        def build_unbooked_cards
          time_entries_by_project_and_issue = @unbooked_time_entries.group_by do |time_entry|
            key_by(time_entry.project, time_entry.issue)
          end

          time_entries_by_project_and_issue.inject([]) do |unbooked_cards, (key, time_entries)|
            issue = time_entries.first.issue
            project = time_entries.first.project
            unbooked_cards << Components::UnbookedCard.new(@date, issue, project, time_entries, :month)
            unbooked_cards
          end
        end

        def find_booked_time_entries
          booked_issue_ids = @resource_bookings.map(&:issue_id).compact
          booked_project_ids = @resource_bookings.select { |rb| rb.issue.blank? }.map(&:project_id)
          @time_entries.select do |time_entry|
            if time_entry.issue_id
              booked_issue_ids.include?(time_entry.issue_id)
            else
              booked_project_ids.include?(time_entry.project_id)
            end
          end
        end

        def key_by(project, issue)
          "#{project.id}-#{issue.try(:id)}"
        end

        def filter_bookings_by_month(resource_bookings)
          resource_bookings.select do |booking|
            booking.interval.begin <= @month_end && booking.interval.end >= @month_start
          end
        end

        def filter_time_entries_by_week(time_entries)
          time_entries.select do |time_entry|
            time_entry.spent_on <= @month_end && time_entry.spent_on >= @month_start
          end
        end

      end
    end
  end
end
