# This file is a part of Redmine Resources (redmine_resources) plugin,
# resource allocation and management for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_resources is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_resources is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_resources.  If not, see <http://www.gnu.org/licenses/>.

module RedmineResources
  module Charts
    module Helpers
      class Plan
        include Redmine::Utils::DateCalculation

        attr_reader :date_title, :today_css_class, :week_day_css_class, :is_workday,
                    :workload_card, :booked_cards, :unbooked_cards, :allocated_hours, :spent_hours, :project_day_plan

        def initialize(date, resource_bookings, time_entries, user_capacity, total_bookings_workday_count, options = {})
          @date = date
          @user_capacity = user_capacity
          @is_workday = user_capacity[:day_type]
          @workday_length = user_capacity[:workday_length]
          @scheduled_hours = user_capacity[:scheduled_hours]
          @overload = user_capacity[:overload]
          @workload_percent = user_capacity[:workload_percent]
          @options = options
          @total_bookings_workday_count = total_bookings_workday_count
          @date_title = I18n.l(@date, format: '%a, %d')

          @today_css_class = 'today' if @date == User.current.today
          @week_day_css_class = 'week-end' if @user_capacity[:day_type] == :weekend
          @week_day_css_class = 'holiday' if @user_capacity[:day_type] == :holiday
          @resource_bookings = resource_bookings
          @time_entries = time_entries
          @booked_time_entries = find_booked_time_entries(@resource_bookings, @time_entries)
          @unbooked_time_entries = @time_entries - @booked_time_entries
          @spent_hours = @time_entries.sum(&:hours)
          if @is_workday == :dayoff
            @allocated_hours = 0
            @workload_card = Components::DayoffCard.new
          else
            @allocated_hours = @resource_bookings.sum(&:booking_value)
            @workload_card = Components::WorkloadCard.new(@resource_bookings, @time_entries, @user_capacity)
          end
          @booked_cards = build_booked_cards(@date, @is_workday, @resource_bookings, @booked_time_entries)
          @unbooked_cards = build_unbooked_cards(@date, @unbooked_time_entries)
          @project_day_plan = build_project_plan_card
        end

        private

        def build_booked_cards(date, is_workday, resource_bookings, time_entries)
          time_entries_by_project_and_issue = time_entries.group_by do |time_entry|
            key_by(time_entry.project, time_entry.issue)
          end

          resource_bookings.inject([]) do |booked_cards, resource_booking|
            issue = resource_booking.issue
            project = resource_booking.project
            time_entries = time_entries_by_project_and_issue[key_by(project, issue)] || []

            if is_workday || time_entries.present?
              booked_cards << Components::BookedCard.new(date, 
                issue, 
                project, 
                resource_booking, 
                time_entries, 
                @user_capacity, 
                @total_bookings_workday_count[resource_booking.id], 
                :day,
                @options)
            end

            booked_cards
          end
        end

        def build_project_plan_card
          @booked_cards.group_by { |card| card.project }.each_with_object({}) do |(project, cards), result|
            scheduled_hours = cards.sum { |card| card.planned_hours }
            workload_percent = @workday_length > 0 ? (scheduled_hours / @workday_length * 100).round : 0
            project_plan = Components::ProjectPlanCard.new(@is_workday, scheduled_hours, @workday_length, workload_percent, @options)

            result[project] = project_plan
          end
        end

        def build_unbooked_cards(date, time_entries)
          time_entries_by_project_and_issue = time_entries.group_by do |time_entry|
            key_by(time_entry.project, time_entry.issue)
          end

          time_entries_by_project_and_issue.inject([]) do |unbooked_cards, (key, time_entries)|
            issue = time_entries.first.issue
            project = time_entries.first.project
            unbooked_cards << Components::UnbookedCard.new(date, issue, project, time_entries, :day)
            unbooked_cards
          end
        end

        def find_booked_time_entries(resource_bookings, time_entries)
          booked_issue_ids = resource_bookings.map(&:issue_id).compact
          booked_project_ids = resource_bookings.select { |rb| rb.issue.blank? }.map(&:project_id)
          time_entries.select do |time_entry|
            if time_entry.issue_id
              booked_issue_ids.include?(time_entry.issue_id)
            else
              booked_project_ids.include?(time_entry.project_id)
            end
          end
        end

        def key_by(project, issue)
          "#{project.id}-#{issue.try(:id)}"
        end
      end
    end
  end
end
