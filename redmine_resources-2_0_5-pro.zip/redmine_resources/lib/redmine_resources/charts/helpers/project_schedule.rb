# This file is a part of Redmine Resources (redmine_resources) plugin,
# resource allocation and management for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_resources is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_resources is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_resources.  If not, see <http://www.gnu.org/licenses/>.

module RedmineResources
  module Charts
    module Helpers
      class ProjectSchedule
        include Redmine::Utils::DateCalculation

        attr_reader :project, :user_schedules, :capacity_hours, :allocated_hours, :spent_hours

        def initialize(project, date_from, date_to, resource_bookings, time_entries, options = {})
          @project = project
          @date_from = date_from
          @date_to = date_to
          @resource_bookings = resource_bookings
          @time_entries = time_entries
          @options = options
          @zoom = @options[:zoom].to_i
          @user_schedules = build_user_schedules(@date_from, @date_to, @resource_bookings, @time_entries)
          @capacity_hours = @user_schedules.sum(&:capacity_hours)
          @allocated_hours = @resource_bookings.sum(&:booking_value)
          @spent_hours = @time_entries.sum(&:hours)
        end

        def workload_cards
          @workload_cards ||=
            @user_schedules.map(&:plans).transpose
              .map { |plans| Components::ProjectWorkloadCard.new(plans, @zoom) }
        end

        def versions_cards
          @versions_cards ||= begin
            return [] if versions.blank?

            case @zoom
            when 1
              version_groups_by_month = versions.group_by { |version| version.effective_date.month }
              months = (@date_from..@date_to).map(&:month).uniq

              months.map do |month|
                Components::VersionsCard.new(version_groups_by_month[month].to_a)
              end
            when 2
              version_groups_by_week = versions.group_by { |version| version.effective_date.cweek }
              weeks = (@date_from..@date_to).map(&:cweek).uniq

              weeks.map do |week|
                Components::VersionsCard.new(version_groups_by_week[week].to_a)
              end
            else
              version_groups_by_due_date = versions.group_by(&:effective_date)

              (@date_from..@date_to).map do |day|
                Components::VersionsCard.new(version_groups_by_due_date[day].to_a)
              end
            end
          end
        end

        private

        def versions
          @versions ||=
            (project ? project.versions : Version)
              .where("#{Version.table_name}.effective_date BETWEEN ? AND ?", @date_from, @date_to)
              .to_a
        end

        def build_user_schedules(date_from, date_to, resource_bookings, time_entries)
          resource_bookings_groups_by_user = resource_bookings.group_by(&:assigned_to)
          time_entries_groups_by_user = time_entries.group_by(&:user)
          @users = resource_bookings_groups_by_user.keys | time_entries_groups_by_user.keys
          users_ids = resource_bookings.pluck(:assigned_to_id) | time_entries.pluck(:user_id)
          people_capacity_map = RedmineResources.users_capacity_map(users_ids, date_from, date_to)

          @users.map do |user|
            Helpers::UserSchedule.new(
              user,
              people_capacity_map[user.id],
              date_from,
              date_to,
              resource_bookings_groups_by_user[user].to_a,
              time_entries_groups_by_user[user].to_a,
              @options
            )
          end
        end

      end
    end
  end
end
