# This file is a part of Redmine Resources (redmine_resources) plugin,
# resource allocation and management for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_resources is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_resources is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_resources.  If not, see <http://www.gnu.org/licenses/>.

module RedmineResources
  module Charts
    module Helpers
      class UserSchedule
        include Redmine::Utils::DateCalculation
        WORKWEEK = :workweek
        WORKMONTH = :workmonth
        DAYOFF = :dayoff
        WORKDAY = :workday
        WEEKEND = :weekend
        HOLIDAY = :holiday

        attr_reader :user, :resource_bookings, :plans, :capacity_hours, :total_allocated_hours , :allocated_hours, :spent_hours, :workload_percent, :plans_group_by_project

        def initialize(user, user_capacity_map, date_from, date_to, resource_bookings, time_entries, options = {})
          raise ArgumentError unless user

          @user = user
          @date_from = date_from
          @date_to = date_to
          @resource_bookings = resource_bookings
          @time_entries = time_entries
          @user_capacity_map = user_capacity_map
          @person_capacity_hash = user_line_map_hash(user, resource_bookings)
          @options = options
          @zoom = options[:zoom].to_i || 3
          @zoom = 3 if options[:chart_type] == 'utilization_report'

          @plans = build_plans(@resource_bookings)
          @total_allocated_hours = @plans.sum(&:allocated_hours)

          @plans_group_by_project = {}
          @resource_bookings.group_by(&:project).each do |project, resource_bookings|
            plans = build_plans(resource_bookings)
            @plans_group_by_project[project] = plans
          end
          @capacity_hours = @person_capacity_hash.sum { |date, data| data[:workday_length] }
          @allocated_hours = @person_capacity_hash.sum { |date, data| data[:scheduled_hours] }
          @spent_hours = @time_entries.sum(&:hours)
          @workload_percent = @capacity_hours == 0 ? 0 : (@total_allocated_hours / @capacity_hours * 100).to_i
        end

        private

        def build_plans(resource_bookings)
          case @zoom
          when 1 # range - year, one column per month
            build_monthly_plans(resource_bookings)
          when 2 # range - month, one column per week
            build_weekly_plans(resource_bookings)
          else # range - week, one column per day
            build_daily_plans(resource_bookings)
          end
        end

        def build_monthly_plans(resource_bookings)
          user_plan_by_months = {}
          user_capacity = user_line_map_hash_group_by_month

          (@date_from..@date_to).map do |day|
            month = day.strftime('%Y-%m')
            user_plan_by_months[month] ||= MonthPlan.new(day, resource_bookings, @time_entries, user_capacity, @total_bookings_workday_count)
          end

          user_plan_by_months.values
        end

        def build_weekly_plans(resource_bookings)
          user_plan_by_weeks = {}
          user_capacity = user_line_map_hash_group_by_week

          (@date_from..@date_to).map do |day|
            user_plan_by_weeks[day.cweek] ||= WeekPlan.new(day, resource_bookings, @time_entries, user_capacity, @total_bookings_workday_count)
          end

          user_plan_by_weeks.values
        end

        def build_daily_plans(resource_bookings)
          (@date_from..@date_to).map do |day|
            resource_bookings_by_day = resource_bookings.select { |rb| rb.interval.cover?(day) }
            time_entries_by_day = @time_entries.select { |time_entry| time_entry.spent_on == day }

            Plan.new(day, resource_bookings_by_day, time_entries_by_day, @person_capacity_hash[day], @total_bookings_workday_count, @options)
          end
        end

        def user_line_map_hash(user, resource_bookings)
          @total_bookings_workday_count = {}

          @user_capacity_map.each do |date, capacity|
            workday_length = capacity[:workday_length]
            scheduled_hours_hash = scheduled_hours_for(date, user, resource_bookings, capacity[:day_type], workday_length)
            capacity.merge!(scheduled_hours_hash)
            scheduled_hours = capacity[:scheduled_hours]
            scheduled_bookings = capacity[:scheduled_bookings]
            capacity[:overload] = (workday_length - scheduled_hours)

            scheduled_bookings.each do |booking_id, hours|
              if %i(workday part_dayoff).include? capacity[:day_type]
                @total_bookings_workday_count[booking_id] ||= 0
                @total_bookings_workday_count[booking_id] += 1
              end
            end

            if workday_length > 0 && scheduled_hours > 0
              capacity[:workload_percent] = (scheduled_hours / workday_length * 100).round
            else
              capacity[:workload_percent] = 0
            end
          end
        end

        def user_line_map_hash_group_by_week
          user_plan_by_weeks = {}

          @person_capacity_hash.each do |date, capacity|
            week_number = date.cweek
            user_plan_by_weeks[week_number] ||= {
              interval_type: capacity[:day_type] == DAYOFF ? DAYOFF : WORKWEEK,
              available_workhours: 0,
              scheduled_hours: 0,
              scheduled_bookings: {},
              bookings_workdays_count: {},
              overload: 0,
              workload_percent: 0
            }

            week_data = user_plan_by_weeks[week_number]

            if week_data[:interval_type] == DAYOFF && capacity[:day_type] == DAYOFF
              week_data[:interval_type] = DAYOFF
            else
              week_data[:interval_type] = WORKWEEK
            end

            week_data[:available_workhours] += capacity[:workday_length]
            week_data[:scheduled_hours] += capacity[:scheduled_hours]
            week_data[:overload] += capacity[:overload]

            capacity[:scheduled_bookings].each do |booking_id, hours|
              week_data[:scheduled_bookings][booking_id] ||= 0
              week_data[:scheduled_bookings][booking_id] += hours

              week_data[:bookings_workdays_count][booking_id] ||= 0
              week_data[:bookings_workdays_count][booking_id] += 1
            end

            if week_data[:available_workhours] > 0 && week_data[:scheduled_hours] > 0
              week_data[:workload_percent] = ((week_data[:scheduled_hours] / week_data[:available_workhours]) * 100).round
            end
          end

          calculate_workload_percent_by_bookings(user_plan_by_weeks)

          user_plan_by_weeks
        end

        def user_line_map_hash_group_by_month
          user_plan_by_months = {}

          @person_capacity_hash.each do |date, capacity|
            month = date.strftime('%Y-%m')
            user_plan_by_months[month] ||= {
              interval_type: capacity[:day_type] == DAYOFF ? DAYOFF : WORKMONTH,
              available_workhours: 0,
              scheduled_hours: 0,
              scheduled_bookings: {},
              bookings_workdays_count: {},
              overload: 0,
              workload_percent: 0
            }

            month_data = user_plan_by_months[month]

            if month_data[:interval_type] == DAYOFF && capacity[:day_type] == DAYOFF
              month_data[:interval_type] = DAYOFF
            else
              month_data[:interval_type] = WORKMONTH
            end

            month_data[:available_workhours] += capacity[:workday_length]
            month_data[:scheduled_hours] += capacity[:scheduled_hours]
            month_data[:overload] += capacity[:overload]

            capacity[:scheduled_bookings].each do |booking_id, hours|
              month_data[:scheduled_bookings][booking_id] ||= 0
              month_data[:scheduled_bookings][booking_id] += hours

              month_data[:bookings_workdays_count][booking_id] ||= 0
              month_data[:bookings_workdays_count][booking_id] += 1
            end

            if month_data[:available_workhours] > 0 && month_data[:scheduled_hours] > 0
              month_data[:workload_percent] = ((month_data[:scheduled_hours] / month_data[:available_workhours]) * 100).round
            end
          end

          calculate_workload_percent_by_bookings(user_plan_by_months)

          user_plan_by_months
        end

        def scheduled_hours_for(date, user, resource_bookings, day_type, workday_length)
          bookings_for_date = resource_bookings.select { |rb| rb.interval.cover?(date) }
          return { scheduled_hours: 0, scheduled_bookings: {} } if bookings_for_date.empty?

          scheduled_bookings = {}
          workload_percent_by_bookings = {}
          total_hours = 0

          bookings_for_date.each do |rb|
            hours = rb.daily_hours(workday_length)
            scheduled_bookings[rb.id] = hours
            workload_percent_by_bookings[rb.id] = workday_length > 0 ? (hours / workday_length * 100).round(2) : 0
            total_hours += hours
          end

          { scheduled_hours: total_hours, scheduled_bookings: scheduled_bookings, workload_percent_by_bookings: workload_percent_by_bookings }
        end

        def calculate_workload_percent_by_bookings(plan_data)
          plan_data.each do |key, data|
            workload_percent_by_bookings = {}
            available_workhours = data[:available_workhours]
            data[:scheduled_bookings].each do |booking_id, hours|
              workload_percent_by_bookings[booking_id] = available_workhours > 0 ? (hours / available_workhours * 100).round(2) : 0
            end

            data.merge!(workload_percent_by_bookings: workload_percent_by_bookings)
          end
        end
      end
    end
  end
end
