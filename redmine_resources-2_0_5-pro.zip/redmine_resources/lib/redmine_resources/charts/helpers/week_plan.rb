# This file is a part of Redmine Resources (redmine_resources) plugin,
# resource allocation and management for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_resources is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_resources is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_resources.  If not, see <http://www.gnu.org/licenses/>.

module RedmineResources
  module Charts
    module Helpers
      class WeekPlan
        attr_reader :date_title, :allocated_hours, :workload_card, :booked_cards, :unbooked_cards, :interval_type, :spent_hours

        def initialize(week_start, resource_bookings, time_entries, user_capacity, total_bookings_workday_count)
          @week_start = week_start
          @week_end = [@week_start.end_of_week, @week_start.end_of_month].min
          @user_capacity = user_capacity[@week_start.cweek]
          @total_bookings_workday_count = total_bookings_workday_count
          start_date_title = I18n.l(@week_start, format: '%-d %b')
          end_date_title = I18n.l(@week_end, format: '%-d %b')
          @date_title = if @week_start == @week_end
                          start_date_title
                        else
                          "#{start_date_title} - #{end_date_title}"
                        end

          @resource_bookings = filter_bookings_by_week(resource_bookings)
          @time_entries = filter_time_entries_by_week(time_entries)
          @booked_time_entries = find_booked_time_entries
          @unbooked_time_entries = @time_entries - @booked_time_entries
          @spent_hours = @time_entries.sum(&:hours)
          @interval_type = @user_capacity[:interval_type]
          @allocated_hours = @user_capacity[:scheduled_hours]

          @workload_card =  if @interval_type == :dayoff
                              Components::DayoffCard.new
                            else
                              Components::WorkloadCard.new(@resource_bookings, @time_entries, @user_capacity)
                            end

          @booked_cards = build_booked_cards
          @unbooked_cards = build_unbooked_cards
        end

        private

        def build_booked_cards
          time_entries_by_project_and_issue = @time_entries.group_by do |time_entry|
            key_by(time_entry.project, time_entry.issue)
          end

          @resource_bookings.inject([]) do |booked_cards, resource_booking|
            issue = resource_booking.issue
            project = resource_booking.project
            time_entries = time_entries_by_project_and_issue[key_by(project, issue)] || []

            if @interval_type || time_entries.present?
              planned_hours = @user_capacity[:scheduled_bookings][resource_booking.id]
              workday_count = @total_bookings_workday_count[resource_booking.id]
              booked_cards << Components::BookedCard.new(resource_booking.start_date, issue, project, resource_booking, time_entries, @user_capacity, workday_count, :week)
            end

            booked_cards
          end
        end

        def build_unbooked_cards
          time_entries_by_project_and_issue = @unbooked_time_entries.group_by do |time_entry|
            key_by(time_entry.project, time_entry.issue)
          end

          time_entries_by_project_and_issue.inject([]) do |unbooked_cards, (key, time_entries)|
            issue = time_entries.first.issue
            project = time_entries.first.project
            unbooked_cards << Components::UnbookedCard.new(@week_start, issue, project, time_entries, :week)
            unbooked_cards
          end
        end

        def find_booked_time_entries
          booked_issue_ids = @resource_bookings.map(&:issue_id).compact
          booked_project_ids = @resource_bookings.select { |rb| rb.issue.blank? }.map(&:project_id)
          @time_entries.select do |time_entry|
            if time_entry.issue_id
              booked_issue_ids.include?(time_entry.issue_id)
            else
              booked_project_ids.include?(time_entry.project_id)
            end
          end
        end

        def key_by(project, issue)
          "#{project.id}-#{issue.try(:id)}"
        end

        def filter_bookings_by_week(resource_bookings)
          resource_bookings.select do |booking|
            booking.interval.begin <= @week_end && booking.interval.end >= @week_start
          end
        end

        def filter_time_entries_by_week(time_entries)
          time_entries.select do |time_entry|
            time_entry.spent_on <= @week_end && time_entry.spent_on >= @week_start
          end
        end
      end
    end
  end
end
