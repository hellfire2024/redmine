# encoding: utf-8
#
# This file is a part of Redmine Resources (redmine_resources) plugin,
# resource allocation and management for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_resources is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_resources is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_resources.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class ResourceBookingsControllerTest < ActionController::TestCase
  include Redmine::I18n

  fixtures :projects, :users, :user_preferences, :roles, :members, :member_roles,
           :issues, :issue_statuses, :issue_relations, :versions, :trackers, :projects_trackers,
           :issue_categories, :enabled_modules, :enumerations, :workflows, :email_addresses

  create_fixtures(Redmine::Plugin.find(:redmine_resources).directory + '/test/fixtures/', [:resource_bookings])
  create_fixtures(Redmine::Plugin.find(:redmine_people).directory + '/test/fixtures/', [:leave_types, :dayoffs]) if RedmineResources.people_plugin_installed?

  def setup
    @admin = User.find(1)
    @user = User.find(2)
    @second_user = User.find(3)
    @project = Project.find(1)
    @second_project = Project.find(2)
    @five_project = Project.find(5)
    @issue_6 = Issue.find(6)
    @group = Group.first

    Version.create(name: '1.0.1.1', project_id: @project.id, due_date: '2019-01-10')
    TimeEntry.create(user_id: @user.id, activity_id: 1, project_id: @project.id, spent_on: '2019-01-10', hours: 5)

    EnabledModule.create(project: @project, name: 'resources')
    EnabledModule.create(project: @five_project, name: 'resources')

    @resource_booking_params = {
      project_id: 2,
      assigned_to_id: @user.id,
      issue_id: 1,
      start_date: '2019-01-01',
      end_date: '2019-01-31',
      booking_value: 6,
      booking_type: 'hours',
      notes: 'New booking'
    }
  end

  # === Action :index ===

  def test_should_get_index_for_admin
    @request.session[:user_id] = @admin.id
    # From top menu Resources
    check_get_index :success
    # From project menu Resources
    check_get_index :success, project_id: @project.identifier
  end

  def test_should_get_index_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :view_resources
    check_get_index :success
    check_get_index :success, project_id: @project.identifier
  end

  def test_should_not_access_index_without_permission
    @request.session[:user_id] = @user.id
    check_get_index :forbidden
    check_get_index :forbidden, project_id: @project.identifier
  end

  def test_should_not_access_index_for_anonymous
    check_get_index :redirect
    check_get_index :redirect, project_id: @project.identifier
  end

  def test_should_get_allocation_chart_with_error_message_if_invalid_query
    @request.session[:user_id] = @admin.id
    check_get_index :success, {
      set_filter: 1,
      chart_type: 'allocation_chart',
      date_from: '2024-01-01',
      months: 2,
      f: ['issue_id'],
      op: {'issue_id' => '='},
      v: {'issue_id' => [""]}
    }

    assert_select '#query_form'
    assert_select '#errorExplanation'
  end

  def test_should_get_allocation_chart_with_filter_by_issue
    @request.session[:user_id] = @admin.id
    booking = ResourceBooking.find(1)
    issue = booking.issue
    date_from = booking.start_date.beginning_of_month.strftime('%Y-%m-%d')

    check_get_index :success, {
      set_filter: 1,
      chart_type: 'allocation_chart',
      date_from: date_from,
      months: 2,
      f: ['issue_id'],
      op: {'issue_id' => '='},
      v: {'issue_id' => [issue.id.to_s]}
    }

    assert_select '.resource-planning-chart' do
      assert_select "div #issue-#{issue.id}"
      assert_select "div.issues-group .issue-subject", count: 1
    end
  end

  def test_should_get_allocation_chart_with_dayly_scale_by_default
    @request.session[:user_id] = @admin.id
    check_get_index :success, {
      set_filter: 1,
    }

    assert_select 'table.resource-planning-chart' do
      assert_select 'div.gantt_hdr.bookings-column.nwday'
    end
  end
  def test_should_get_allocation_table_group_by_user
    @request.session[:user_id] = @admin.id
    check_get_index :success, {
      set_filter: 1,
      chart_type: 'allocation_table',
      group_by: 'user',
      date_from: '2019-01-01'
    }
    assert_select '#allocation-table' do
      assert_select 'tr.user-group.group.open'
    end
  end

  def test_should_get_allocation_table_group_by_project
    @request.session[:user_id] = @admin.id
    with_settings display_subprojects_issues: '0' do
      check_get_index :success, {
        set_filter: 1,
        chart_type: 'allocation_table',
        group_by: 'project',
        date_from: '2019-01-01',
        zoom: 3
      }
      assert_select '#allocation-table' do
        assert_select 'tr.project-group.group.open'
      end
    end
  end

  def test_should_get_allocation_table_when_no_data
    @request.session[:user_id] = @admin.id
    check_get_index :success, {
      set_filter: 1,
      chart_type: 'allocation_table',
      group_by: 'project',
      date_from: '2020-01-01'
    }
    assert_select '#allocation-table', 0
    assert_select 'p.nodata'
  end

  def test_should_get_allocation_table_with_weekly_scale
    @request.session[:user_id] = @admin.id
    check_get_index :success, {
      set_filter: 1,
      chart_type: 'allocation_table',
      group_by: 'user',
      date_from: '2019-01-01',
      zoom: 2
    }
    assert_select '#allocation-table' do
      assert_select 'tr.user-group.group.open'
      assert_select 'thead th', text: '1 Jan - 6 Jan'
    end
  end

  def test_should_get_allocation_table_with_monthly_scale
    @request.session[:user_id] = @admin.id
    check_get_index :success, {
      set_filter: 1,
      chart_type: 'allocation_table',
      group_by: 'user',
      date_from: '2019-01-01',
      show_versions: 1,
      show_project_names: 1,
      show_spent_time: 1,
      show_percent: 1,
      zoom: 1
    }
    assert_select '#allocation-table' do
      assert_select 'tr.user-group.group.open'
      assert_select 'thead th', text: 'Jan 2019'
    end
  end

  def test_should_get_index_with_ghost_bookings
    @issue_6.update_attribute(:assigned_to_id, @group.id)

    show_all_options = {
      line_title_type: 'issue_subject',
      query: {
        show_issues: 1,
        show_versions: 1,
        show_ghost_bookings: 1,
        date_from: Date.today - 1.year
      },
      months: 24
    }

    @request.session[:user_id] = @admin.id
    # From top menu Resources
    check_get_index :success, show_all_options
    # From project menu Resources
    check_get_index :success, show_all_options.merge(project_id: @project.identifier)
  ensure
    @issue_6.update_attribute(:assigned_to_id, nil)
  end

  def test_should_get_index_with_ghost_bookings_on_weekends
    @issue_6.update(assigned_to: @user, start_date: Date.today.end_of_week - 1.day, due_date: Date.today.end_of_week)

    show_all_options = {
      line_title_type: 'issue_subject',
      query: {
        show_issues: 1,
        show_versions: 1,
        show_ghost_bookings: 1,
        date_from: Date.today - 1.year
      },
      months: 24
    }

    @request.session[:user_id] = @admin.id
    # From top menu Resources
    check_get_index :success, show_all_options
    # From project menu Resources
    check_get_index :success, show_all_options.merge(project_id: @project.identifier)
  ensure
    @issue_6.update(assigned_to: nil, start_date: Date.today, due_date: Date.today + 1.day)
  end

  def test_should_get_index_with_ghost_bookings_for_issue_without_start_date
    @issue_6.update(assigned_to: @user, start_date: nil, due_date: Date.today.end_of_week)

    show_all_options = {
      line_title_type: 'issue_subject',
      query: {
        show_issues: 1,
        show_versions: 1,
        show_ghost_bookings: 1,
        date_from: Date.today - 1.week
      },
      months: 1
    }

    @request.session[:user_id] = @admin.id
    # From top menu Resources
    check_get_index :success, show_all_options
    # From project menu Resources
    check_get_index :success, show_all_options.merge(project_id: @project.identifier)
  ensure
    @issue_6.update(assigned_to: nil, start_date: Date.today, due_date: Date.today + 1.day)
  end

  def test_should_get_utilization_report_group_by_issue
    @request.session[:user_id] = @admin.id
    check_get_index :success, {
      set_filter: 1,
      chart_type: 'utilization_report',
      group_by: 'issue',
      query: {
        date_from: '2018-12-01'
      }
    }
    assert_select '#utilization-report-chart' do
      assert_select 'tr.workload-data'
      assert_select 'td div.small-booking-card.editable'
    end
  end

  def test_should_get_utilization_report_group_by_issue_and_show_percent_in_booked_card
    @request.session[:user_id] = @admin.id
    Setting.plugin_redmine_people['workday_length'] = 8.0 if RedmineResources.people_plugin_installed?

    check_get_index :success, {
      set_filter: 1,
      chart_type: 'utilization_report',
      group_by: 'issue',
      query: {
        date_from: '2018-12-01',
        show_percent: 1
      }
    }
    assert_select '#utilization-report-chart' do
      assert_select 'tr.workload-data' do
        assert_select 'td' do
          assert_select 'div.small-booking-card' do |booking_cards|
            percentages = booking_cards.map { |card| card.at('p.percent').text }
            assert_includes percentages, '50%' # first booking workload 50%
            assert_includes percentages, '25%' # second booking workload 25%
          end
        end
      end
    end
  end

  def test_should_get_utilization_report_group_by_project
    @request.session[:user_id] = @admin.id
    check_get_index :success, {
      set_filter: 1,
      chart_type: 'utilization_report',
      group_by: 'project',
      query: {
        date_from: '2018-12-01'
      }
    }
    assert_select '#utilization-report-chart' do
      assert_select 'td div.small-booking-card.editable', 0
      assert_select 'td div.small-booking-card'
    end
  end

  def test_should_get_utilization_report_in_project
    @request.session[:user_id] = @admin.id
    resource_booking = ResourceBooking.first
    check_get_index :success, {
      set_filter: 1,
      project_id: resource_booking.project.identifier,
      chart_type: 'utilization_report',
      group_by: 'project',
      query: {
        date_from: '2018-12-01'
      }
    }
    assert_select '#utilization-report-chart' do
      assert_select 'td div.small-booking-card.editable', 0
      assert_select 'td div.small-booking-card'
    end
  end

  def test_should_get_allocation_chart_with_dayly_scale
    booking = ResourceBooking.find(1)
    date_from = booking.start_date - 1.day

    @request.session[:user_id] = @admin.id
    check_get_index :success, {
      set_filter: 1,
      chart_type: 'allocation_chart',
      group_by: 'user',
      date_from: date_from,
      zoom: 3
    }
    assert_select 'table.resource-planning-chart' do
      assert_select 'div.gantt_hdr.bookings-column', text: '29'
      assert_select 'div.booking-bar' do
        assert_select 'div.issue-subject-title', text: "\u00A0" + booking.issue.subject
      end
    end
  end  
  
  def test_should_get_allocation_chart_with_weekly_scale
    booking = ResourceBooking.find(1)
    date_from = booking.start_date - 1.day

    @request.session[:user_id] = @admin.id
    check_get_index :success, {
      set_filter: 1,
      chart_type: 'allocation_chart',
      group_by: 'user',
      date_from: date_from,
      zoom: 2
    }
    assert_select 'table.resource-planning-chart' do
      assert_select 'div.gantt_hdr.bookings-column', text: '26 - 2'
      assert_select 'div.booking-bar' do
        assert_select 'div.issue-subject-title', text: "\u00A0" + booking.issue.subject
      end
    end
  end  

  def test_should_get_allocation_chart_with_monthly_scale
    booking = ResourceBooking.find(1)
    date_from = booking.start_date - 1.day

    @request.session[:user_id] = @admin.id
    check_get_index :success, {
      set_filter: 1,
      chart_type: 'allocation_chart',
      group_by: 'user',
      date_from: date_from,
      zoom: 1
    }
    assert_select 'table.resource-planning-chart' do
      assert_select 'div.gantt_hdr.bookings-column', text: 'Nov'
      assert_select 'div.booking-bar' do
        assert_select 'div.issue-subject-title', text: "\u00A0" + booking.issue.subject
      end
    end
  end

  def test_should_get_allocation_chart_with_columns
    booking = ResourceBooking.find(1)
    date_from = booking.start_date - 1.day

    @request.session[:user_id] = @admin.id
    check_get_index :success, {
      set_filter: 1,
      chart_type: 'allocation_chart',
      group_by: 'user',
      date_from: date_from,
      zoom: 3,
      draw_selected_columns: 1,
      c: %w(allocated_hours capacity_hours available_hours percent_allocated)
    }

    assert_select 'table.resource-planning-chart' do
      assert_select 'div.gantt_allocated_hours_container'
      assert_select 'div.gantt_capacity_hours_container'
      assert_select 'div.gantt_available_hours_container'
      assert_select 'div.gantt_percent_allocated_container'
    end
  end

  if RedmineResources.people_pro_plugin_installed?
    def test_should_get_allocation_chart_with_dayoff
      Setting.plugin_redmine_people['workday_length'] = 8.0
      booking = ResourceBooking.find(1)
      date_from = booking.start_date - 1.day
      user = booking.assigned_to
      Dayoff.create(user_id: user.id, leave_type_id: 1, approved: true, start_date: booking.start_date + 1.day, end_date: booking.start_date + 7.day)
      @request.session[:user_id] = @admin.id
      check_get_index :success, {
        set_filter: 1,
        chart_type: 'allocation_chart',
        group_by: 'user',
        date_from: date_from
      }
      assert_select "a[href*='/dayoffs/new']"
      assert_select 'table.resource-planning-chart' do
        assert_select '.dayoff-bar'
      end
    end

    def test_should_get_allocation_chart_without_dayoff_if_dayoff_not_approved
      booking = ResourceBooking.find(1)
      date_from = booking.start_date - 1.day
      user = booking.assigned_to
      user.dayoffs.delete_all
      Dayoff.create(user_id: user.id, leave_type_id: 1, start_date: booking.start_date + 1.day, end_date: booking.start_date + 7.day)
      @request.session[:user_id] = @admin.id
      check_get_index :success, {
        set_filter: 1,
        chart_type: 'allocation_chart',
        group_by: 'user',
        date_from: date_from
      }
      assert_select "a[href*='/dayoffs/new']"
      assert_select 'table.resource-planning-chart' do
        assert_select '.dayoff-bar', 0
      end
    end

    def test_should_get_allocation_chart_with_dayoff_column
      booking = ResourceBooking.find(1)
      date_from = booking.start_date - 1.day

      @request.session[:user_id] = @admin.id
      check_get_index :success, {
        set_filter: 1,
        chart_type: 'allocation_chart',
        group_by: 'user',
        date_from: date_from,
        zoom: 3,
        draw_selected_columns: 1,
        c: %w(dayoffs_count)
      }

      assert_select 'table.resource-planning-chart' do
        assert_select 'div.gantt_dayoffs_count_container'
      end
    end

    def test_should_get_allocation_table_with_dayoff
      @request.session[:user_id] = @admin.id
   
      Dayoff.create(user_id: @user.id, leave_type_id: 1, approved: true, start_date: '2019-01-02', end_date:'2019-01-03')
      check_get_index :success, {
        set_filter: 1,
        chart_type: 'allocation_table',
        group_by: 'user',
        date_from: '2019-01-01',
        show_versions: 1,
        show_project_names: 1,
        show_spent_time: 1,
        show_percent: 1,
        zoom: 3
      }
      assert_select '#allocation-table' do
        assert_select 'tr.user-group.group.open'
        assert_select 'thead th', text: 'Tue, 01'
        assert_select 'div.workload-card.dayoff'
      end   
    end   
  end

  # === Action :new ===

  def test_should_get_new_for_admin
    @request.session[:user_id] = @admin.id
    # From top menu Resources
    check_get_new :success
    # From project menu Resources
    check_get_new :success, project_id: @project.identifier
  end

  def test_should_get_new_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :add_booking
    check_get_new :success
    check_get_new :success, project_id: @project.identifier
  end

  def test_should_not_access_new_without_permission
    @request.session[:user_id] = @user.id
    check_get_new :forbidden
    check_get_new :forbidden, project_id: @project.identifier
  end

  def test_should_not_access_new_for_anonymous
    check_get_new :unauthorized
    check_get_new :unauthorized, project_id: @project.identifier
  end

  def test_should_get_new_with_modal_window
    @request.session[:user_id] = @admin.id
    project_name = @project.name
    user_name = @project.users.first.name
    check_get_modal_window(:new, user_name, project_name)
  end

  # === Action :create ===

  def test_should_create_resource_bookings_for_admin
    @request.session[:user_id] = @admin.id
    # Creating from top menu Resources
    should_create_resource_booking resource_booking: @resource_booking_params
    # Creating from project menu Resources
    should_create_resource_booking resource_booking: @resource_booking_params, project_id: @project.identifier
  end

  def test_should_create_resource_bookings_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :add_booking
    should_create_resource_booking resource_booking: @resource_booking_params
    should_create_resource_booking resource_booking: @resource_booking_params, project_id: @project.identifier
  end

  def test_should_not_create_resource_bookings_without_permission
    @request.session[:user_id] = @user.id
    should_not_create_resource_booking :forbidden, resource_booking: @resource_booking_params
    should_not_create_resource_booking :forbidden, resource_booking: @resource_booking_params, project_id: @project.identifier
  end

  def test_should_not_create_resource_bookings_for_anonymous
    should_not_create_resource_booking :unauthorized, resource_booking: @resource_booking_params
    should_not_create_resource_booking :unauthorized, resource_booking: @resource_booking_params, project_id: @project.identifier
  end

  def test_should_send_mail_after_create_resource_booking
    @request.session[:user_id] = @admin.id
    ActionMailer::Base.deliveries.clear
    with_settings :notified_events => %w(resource_updated) do
      assert_difference(-> { ActionMailer::Base.deliveries.size }, 2) do
        should_create_resource_booking resource_booking: @resource_booking_params
      end
    end
  end

  # === Action :edit ===

  def test_should_get_edit_for_admin
    @request.session[:user_id] = @admin.id
    # From top menu Resources
    check_get_edit :success, id: 1
    # From project menu Resources
    check_get_edit :success, id: 1, project_id: @project.identifier
  end

  def test_should_get_edit_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :edit_booking
    check_get_edit :success, id: 1
    check_get_edit :success, id: 1, project_id: @project.identifier
  end

  def test_should_not_access_edit_without_permission
    @request.session[:user_id] = @user.id
    check_get_edit :forbidden, id: 1
    check_get_edit :forbidden, id: 1, project_id: @project.identifier
  end

  def test_should_not_access_edit_for_anonymous
    check_get_edit :unauthorized, id: 1
    check_get_edit :unauthorized, id: 1, project_id: @project.identifier
  end

  def test_should_not_access_edit_for_missing_resource_booking
    @request.session[:user_id] = @admin.id
    check_get_edit :missing, id: 777
    check_get_edit :missing, id: 999, project_id: @project.identifier
  end

  def test_should_get_edit_with_modal_window
    @request.session[:user_id] = @admin.id
    project_name = @project.name
    user_name = @user.name
    check_get_modal_window(:edit, user_name, project_name, params = {id: 1})
  end

  # === Action :update ===

  def test_should_update_resource_booking_for_admin
    @request.session[:user_id] = @admin.id
    # From top menu Resources
    should_update_resource_booking id: 1, resource_booking: @resource_booking_params
    # From project menu Resources
    should_update_resource_booking id: 1, project_id: @project.identifier, resource_booking: @resource_booking_params
  end

  def test_should_update_resource_booking_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :edit_booking
    should_update_resource_booking id: 1, resource_booking: @resource_booking_params
    should_update_resource_booking id: 1, project_id: @project.identifier, resource_booking: @resource_booking_params
  end

  def test_should_not_update_resource_booking_without_permission
    @request.session[:user_id] = @user.id
    should_not_update_resource_booking :forbidden, id: 1, resource_booking: @resource_booking_params
    should_not_update_resource_booking :forbidden, id: 1, project_id: @project.identifier, resource_booking: @resource_booking_params
  end

  def test_should_not_update_resource_booking_without_start_date
    @request.session[:user_id] = @admin.id
    rb_params = @resource_booking_params.merge(start_date: '')
    should_not_update_resource_booking :success, id: 1, resource_booking: rb_params
    should_not_update_resource_booking :success, id: 1, project_id: @project.identifier, resource_booking: rb_params
  end

  def test_should_not_update_resource_booking_for_anonymous
    should_not_update_resource_booking :unauthorized, id: 1, resource_booking: @resource_booking_params
    should_not_update_resource_booking :unauthorized, id: 1, project_id: @project.identifier, resource_booking: @resource_booking_params
  end

  def test_should_send_mail_after_update_resource_booking
    @request.session[:user_id] = @admin.id
    ActionMailer::Base.deliveries.clear
    with_settings :notified_events => %w(resource_updated) do
      assert_difference(-> { ActionMailer::Base.deliveries.size }, 2) do
        should_update_resource_booking id: 1, resource_booking: @resource_booking_params
      end
    end
  end

  def test_should_update_resource_booking_with_date_offsets
    @request.session[:user_id] = @admin.id
    should_update_resource_booking id: 1, start_date_offset: 10
    should_update_resource_booking id: 1, start_date_offset: -10

    should_update_resource_booking id: 1, end_date_offset: 10
    should_update_resource_booking id: 1, end_date_offset: -10

    should_update_resource_booking id: 1, start_date_offset: 10, end_date_offset: 10

    should_update_resource_booking id: 1, project_id: @project.identifier, start_date_offset: 10
  end

  def test_should_update_resource_booking_when_end_date_more_than_issue_due_date
    @request.session[:user_id] = @admin.id
    rb_params = @resource_booking_params.merge(start_date: Date.today, end_date: 11.day.from_now.to_date)
    should_update_resource_booking id: 1, resource_booking: rb_params
    should_validate_with_warnings ResourceBooking.find(1)

    should_update_resource_booking id: 1, project_id: @project.identifier, resource_booking: rb_params
    should_validate_with_warnings ResourceBooking.find(1)
  end

  def test_validation_by_issue_estimated_hours
    @request.session[:user_id] = @admin.id
    Setting.plugin_redmine_people['workday_length'] = 8.0 if RedmineResources.people_pro_plugin_installed?

    rb_params = @resource_booking_params.merge(end_date: 10.day.from_now.to_date)
    assert Issue.find(rb_params[:issue_id]).update(estimated_hours: 200)

    should_update_resource_booking id: 1, resource_booking: rb_params
    should_validate_with_warnings ResourceBooking.find(1)

    should_update_resource_booking id: 1, project_id: @project.identifier, resource_booking: rb_params
    should_validate_with_warnings ResourceBooking.find(1)
  end

  # === Action :destroy ===

  def test_should_destroy_resource_booking_for_admin
    @request.session[:user_id] = @admin.id
    # From top menu Resources
    should_destroy_resource_booking(id: 1)
    # From project menu Resources
    should_destroy_resource_booking(id: 2, project_id: @project.identifier)
  end

  def test_should_destroy_resource_booking_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :edit_booking
    should_destroy_resource_booking(id: 1)
    should_destroy_resource_booking(id: 2, project_id: @project.identifier)
  end

  def test_should_not_destroy_resource_booking_without_permission
    @request.session[:user_id] = @user.id
    should_not_destroy_resource_booking :forbidden, id: 1
    should_not_destroy_resource_booking :forbidden, id: 2, project_id: @project.identifier
  end

  def test_should_not_destroy_resource_booking_for_anonymous
    should_not_destroy_resource_booking :unauthorized, id: 1
    should_not_destroy_resource_booking :unauthorized, id: 2, project_id: @project.identifier
  end
  # === Action :split ===

  def test_should_split_resource_booking_for_admin
    @request.session[:user_id] = @admin.id
    should_split_resource_booking id: 1, split_offset: 20
    should_split_resource_booking id: 1, split_offset: 10, project_id: @project.identifier
  end

  def test_should_split_resource_booking_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :edit_booking
    should_split_resource_booking id: 1, split_offset: 20
    should_split_resource_booking id: 1, split_offset: 10, project_id: @project.identifier
  end

  def test_should_not_split_resource_booking_without_permission
    @request.session[:user_id] = @user.id
    should_not_split_resource_booking :forbidden, id: 1, split_offset: 20
    should_not_split_resource_booking :forbidden, id: 1, split_offset: 10, project_id: @project.identifier
  end

  def test_should_not_split_resource_booking_for_anonymous
    should_not_split_resource_booking :unauthorized, id: 1, split_offset: 20
    should_not_split_resource_booking :unauthorized, id: 1, split_offset: 10, project_id: @project.identifier
  end

  # === Action :issues_autocomplete ===

  def test_should_get_issues_autocomplete
    @request.session[:user_id] = @admin.id

    # Search by different projects
    should_get_issues_autocomplete(
      Issue.build_issues_select2_data(Issue.where(id: [1, 2, 3, 7, 8, 11, 12]), @user),
      project_id: @project.id, user_id: @user.id, q: ''
    )

    should_get_issues_autocomplete(
      Issue.build_issues_select2_data(Issue.where(id: 4), @user),
      project_id: @second_project.id, user_id: @user.id, q: ''
    )

    # Search with different users
    should_get_issues_autocomplete(
      Issue.build_issues_select2_data(Issue.where(id: [1, 2, 3, 7, 8, 11, 12]), @second_user),
      project_id: @project.id, user_id: @second_user.id, q: ''
    )

    # Search by issue id
    should_get_issues_autocomplete(
      Issue.build_issues_select2_data(Issue.where(id: [1, 3]), @user),
      project_id: @project.id, user_id: @user.id, q: '1'
    )
    should_get_issues_autocomplete(
      Issue.build_issues_select2_data(Issue.where(id: 1), @user),
      project_id: @project.id, user_id: @user.id, q: '#1'
    )

    # Search with different query strings
    should_get_issues_autocomplete([], project_id: @project.id, user_id: @user.id, q: 'z')
    should_get_issues_autocomplete(
      Issue.build_issues_select2_data(Issue.where(id: [7, 8, 11, 12]), @user),
      project_id: @project.id, user_id: @user.id, q: 'issue'
    )
  end

  def test_should_not_access_issues_autocomplete_for_anonymous
    check_get_xhr_request :issues_autocomplete, :unauthorized, project_id: @project.id, user_id: @admin.id, q: ''
  end

  private

  def check_get_xhr_request(action, response_status, params = {})
    compatible_xhr_request :get, action, params
    assert_response response_status
  end

  def check_get_index(response_status, params = {})
    compatible_request :get, :index, params
    assert_response response_status
  end

  def check_get_new(response_status, params = {})
    check_get_xhr_request :new, response_status, params
  end

  def check_get_edit(response_status, params = {})
    check_get_xhr_request :edit, response_status, params
  end

  def check_get_modal_window(action, user_name, project_name, params = {})
    compatible_xhr_request :get, action, params = {id: 1}
    assert_response :success
    assert_match /selected=\\\"selected\\\">#{project_name}</, response.body
    assert_match /resource_booking_assigned_to_id/, response.body
    assert_match /selected=\\\"selected\\\">#{user_name}</, response.body
    assert_match /resource_booking_booking_type/, response.body
  end

  def should_create_resource_booking(params)
    assert_difference('ResourceBooking.count') do
      compatible_xhr_request :post, :create, params
    end
    assert_response :success
    assert_equal flash[:notice], l(:notice_successful_create)
  end

  def should_not_create_resource_booking(response_status, params)
    assert_difference('ResourceBooking.count', 0) do
      compatible_xhr_request :post, :create, params
    end
    assert_response response_status
  end

  def should_update_resource_booking(params)
    rb_prev = ResourceBooking.find(params[:id])

    compatible_xhr_request :post, :update, params
    assert_response :success
    assert_equal flash[:notice], l(:notice_successful_update)

    rb_current = ResourceBooking.find(params[:id])
    (params[:resource_booking] || []).each do |attr, val|
      assert_equal rb_current.send(attr), val, "Incorrect resource booking attribute: #{attr}"
    end

    if params[:start_date_offset]
      assert_equal rb_current.start_date, rb_prev.start_date + params[:start_date_offset].days
    end

    if params[:end_date_offset]
      assert_equal rb_current.end_date, rb_prev.end_date + params[:end_date_offset].days
    end
  end

  def should_not_update_resource_booking(response_status, params)
    resource_booking = ResourceBooking.find(params[:id])
    compatible_xhr_request :post, :update, params

    assert_response response_status
    assert_equal resource_booking.updated_at, resource_booking.reload.updated_at
  end

  def should_destroy_resource_booking(params)
    assert_difference('ResourceBooking.count', -1) do
      compatible_xhr_request :delete, :destroy, params
    end
    assert_response :success
    assert_equal flash[:notice], l(:notice_successful_delete)
  end

  def should_not_destroy_resource_booking(response_status, params)
    assert_difference('ResourceBooking.count', 0) do
      compatible_xhr_request :delete, :destroy, params
    end
    assert_response response_status
  end

  def should_get_issues_autocomplete(expected_groups, params)
    check_get_xhr_request :issues_autocomplete, :success, params
    assert_equal expected_groups.to_json, response.body
  end

  def should_split_resource_booking(params)
    assert_difference('ResourceBooking.count') do
      compatible_xhr_request :post, :split, params
    end
    assert_response :success
    assert_equal flash[:notice], l(:notice_successful_create)

    resource_booking = ResourceBooking.find(params[:id])
    split_date = resource_booking.start_date + params[:split_offset].days
    assert_equal resource_booking.end_date, split_date - 1.day
    assert_equal ResourceBooking.order('id DESC').first.start_date, split_date
  end

  def should_not_split_resource_booking(response_status, params)
    resource_booking = ResourceBooking.find(params[:id])
    assert_difference('ResourceBooking.count', 0) do
      compatible_xhr_request :post, :split, params
    end
    assert_response response_status
    assert_equal resource_booking.updated_at, resource_booking.reload.updated_at
  end

  def should_validate_with_warnings(resource_booking, number_of_warnings = 1)
    assert resource_booking.valid?
    assert_equal number_of_warnings, resource_booking.warnings.size
  end
end
