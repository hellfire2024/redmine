# encoding: utf-8
#
# This file is a part of Redmine Resources (redmine_resources) plugin,
# resource allocation and management for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_resources is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_resources is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_resources.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class ResourceIssuesControllerTest < ActionController::TestCase
  include Redmine::I18n

  fixtures :projects, :users, :user_preferences, :roles, :members, :member_roles,
           :issues, :issue_statuses, :issue_relations, :versions, :trackers, :projects_trackers,
           :issue_categories, :enabled_modules, :enumerations, :workflows, :email_addresses

  def setup
    @admin = User.find(1)
    @user = User.find(2)
    @second_user = User.find(3)
    @project = Project.find(1)
    @issue_1 = Issue.find(1)
    @issue_2 = Issue.find(2)
    @issue_3 = Issue.find(3)

    EnabledModule.create(project: @project, name: 'resources')

    @issue_params = {
      assigned_to_id: 3,
      start_date: '2023-07-14',
      due_date: '2023-07-20',
      estimated_hours: "8.0"
    }
  end

  # === Action :index ===

  def test_should_get_index_for_admin
    @request.session[:user_id] = @admin.id
    check_get_index :success
    check_get_index :success, project_id: @project.identifier
  end

  def test_should_get_index_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :view_resource_issues
    check_get_index :success
    check_get_index :success, project_id: @project.identifier
  end

  def test_should_not_access_index_without_permission
    @request.session[:user_id] = @user.id
    check_get_index :forbidden
    check_get_index :forbidden, project_id: @project.identifier
  end

  def test_should_not_access_index_for_anonymous
    check_get_index :redirect
    check_get_index :redirect, project_id: @project.identifier
  end

  def test_should_get_allocation_chart_with_query_params
    @request.session[:user_id] = @admin.id
    check_get_index :success, {
      set_filter: 1,
      months: 3,
      date_from: '2023-01-01'
    }
    assert_select '#gantt_area', 1
  end

  # === Action :edit ===

  def test_should_get_edit_for_admin
    @request.session[:user_id] = @admin.id
    # From top menu Resources
    check_get_edit :success, id: 1
    # From project menu Resources
    check_get_edit :success, id: 1, project_id: @project.identifier
  end

  def test_should_get_edit_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :edit_resource_issues
    check_get_edit :success, id: 1
    check_get_edit :success, id: 1, project_id: @project.identifier
  end

  def test_should_not_access_edit_without_permission
    @request.session[:user_id] = @user.id
    check_get_edit :forbidden, id: 1
    check_get_edit :forbidden, id: 1, project_id: @project.identifier
  end

  def test_should_not_access_edit_for_anonymous
    check_get_edit :unauthorized, id: 1
    check_get_edit :unauthorized, id: 1, project_id: @project.identifier
  end

  # # === Action :update ===

  def test_should_update_issue_date_for_admin
    @request.session[:user_id] = @admin.id
    # From top menu Resources
    should_update_resource_issue id: 1, issue: @issue_params
    # From project menu Resources
    should_update_resource_issue id: 1, project_id: @project.identifier, issue: @issue_params
  end

  def test_should_not_update_issue_for_anonymous
    should_not_update_resource_issue :unauthorized, id: 1, issue: @issue_params
    should_not_update_resource_issue :unauthorized, id: 1, project_id: @project.identifier, issue: @issue_params
  end

  def test_should_update_issue_with_date_offsets
    @request.session[:user_id] = @admin.id
    should_update_resource_issue id: 1, start_date_offset: 10
    should_update_resource_issue id: 1, start_date_offset: -10

    should_update_resource_issue id: 1, end_date_offset: 10
    should_update_resource_issue id: 1, end_date_offset: -10

    should_update_resource_issue id: 1, start_date_offset: 10, end_date_offset: 10

    should_update_resource_issue id: 1, project_id: @project.identifier, start_date_offset: 10
  end

  private

  def check_get_xhr_request(action, response_status, params = {})
    compatible_xhr_request :get, action, params
    assert_response response_status
  end

  def check_get_index(response_status, params = {})
    compatible_request :get, :index, params
    assert_response response_status
  end

  def check_get_edit(response_status, params = {})
    check_get_xhr_request :edit, response_status, params
  end

  def should_update_resource_issue(params)
    issue_prev = Issue.find(params[:id])
    compatible_xhr_request :post, :update, params
    assert_response :success

    issue_current = Issue.find(params[:id])
    (params[:issue] || []).each do |attr, val|
      assert_equal issue_current.send(attr).to_s, val.to_s, "Incorrect issue attribute: #{attr}"
    end

    if params[:start_date_offset]
      assert_equal issue_current.start_date, issue_prev.start_date + params[:start_date_offset].days
    end

    if params[:end_date_offset]
      assert_equal issue_current.due_date, issue_prev.end_date_by_available_attribute + params[:end_date_offset].days
    end
  end

  def should_not_update_resource_issue(response_status, params)
    issue = Issue.find(params[:id])
    compatible_xhr_request :post, :update, params

    assert_response response_status
    assert_equal issue.updated_on, issue.reload.updated_on
  end
end
