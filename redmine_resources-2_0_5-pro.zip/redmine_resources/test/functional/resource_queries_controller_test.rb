# encoding: utf-8
#
# This file is a part of Redmine Resources (redmine_resources) plugin,
# resource allocation and management for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_resources is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_resources is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_resources.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class ResourceQueriesControllerTest < ActionController::TestCase
  include Redmine::I18n

  fixtures :projects, :users, :roles, :members, :member_roles

  def setup
    @admin = User.find(1)
    @user = User.find(2)
    @project = Project.find(1)
    @query_params = { name: 'Test Query', visibility: ResourceQuery::VISIBILITY_PRIVATE }
    @chart_types = ResourceBookingQuery::CHART_TYPES.dup << ResourceIssuesQuery::CHART_TYPE
  end

  def test_should_get_new_for_all_chart_types
    @request.session[:user_id] = @admin.id
    @chart_types.each do |chart_type|
      get :new, params: { chart_type: chart_type }
      assert_response :success
      assert_select 'h2', text: l(:label_query_new)
      assert_select "input[name='chart_type'][value='#{chart_type}']", true, "Expected input for chart_type #{chart_type}"
    end
  end

  def test_should_create_query_for_all_chart_types
    @request.session[:user_id] = @admin.id
    @chart_types.each do |chart_type|
      if chart_type == ResourceIssuesQuery::CHART_TYPE
        assert_difference 'ResourceIssuesQuery.count', 1, "Expected query to be created for chart_type #{chart_type}" do
          post :create, params: { query: @query_params, chart_type: chart_type }
        end
        query = ResourceIssuesQuery.last
        assert_redirected_to resource_issues_path(query_id: query.id)
      else
        assert_difference 'ResourceBookingQuery.count', 1, "Expected query to be created for chart_type #{chart_type}" do
          post :create, params: { query: @query_params, chart_type: chart_type }
        end
        query = ResourceBookingQuery.last
        assert_redirected_to resource_bookings_path(query_id: query.id)
      end

      assert_equal 'Test Query', query.name
      assert_equal chart_type, query.chart_type
    end
  end

  def test_should_not_create_query_without_name
    @request.session[:user_id] = @admin.id
    assert_no_difference 'ResourceBookingQuery.count' do
      post :create, params: { project_id: @project.id, query: { visibility: ResourceQuery::VISIBILITY_PRIVATE } }
    end
    assert_select '#errorExplanation'
  end

  def test_should_get_edit_for_all_chart_types
    @chart_types.each do |chart_type|
      query = if chart_type == ResourceIssuesQuery::CHART_TYPE
                ResourceIssuesQuery.create!(name: "Edit Test Query #{chart_type}", project: @project, user: @admin)
              else
                ResourceBookingQuery.create!(name: "Edit Test Query #{chart_type}", project: @project, user: @admin, chart_type: chart_type)
              end

      @request.session[:user_id] = @admin.id
      get :edit, params: { id: query.id }
      assert_response :success
      assert_select 'input[value=?]', "Edit Test Query #{chart_type}"
      assert_select "input[name='chart_type'][value='#{chart_type}']", true, "Expected input for chart_type #{chart_type}"
    end
  end

  def test_should_update_query
    query = ResourceBookingQuery.create!(name: 'Update Test Query', project: @project, user: @admin, chart_type: 'allocation_chart')
    @request.session[:user_id] = @admin.id
    put :update, params: { id: query.id, query: { name: 'Updated Query Name' } }
    assert_redirected_to resource_bookings_path(query_id: query.id, project_id: @project.identifier)
    assert_equal 'Updated Query Name', query.reload.name
  end

  def test_should_not_update_query_with_invalid_data
    query = ResourceBookingQuery.create!(name: 'Update Test Query', project: @project, user: @admin)
    @request.session[:user_id] = @admin.id
    put :update, params: { id: query.id, query: { name: '' } }
    assert_select 'input[value=""]'
    assert_select '#errorExplanation'
  end

  def test_should_destroy_query
    query = ResourceBookingQuery.create!(name: 'Delete Test Query', project: @project, user: @admin)
    @request.session[:user_id] = @admin.id
    assert_difference 'ResourceBookingQuery.count', -1 do
      delete :destroy, params: { id: query.id }
    end
    assert_redirected_to resource_bookings_path(set_filter: 1, project_id: @project.identifier)
  end

  private

  def check_get_index(expected_status, params = {})
    get :index, params: params
    assert_response expected_status
  end
end
