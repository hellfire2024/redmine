# encoding: utf-8
#
# This file is a part of Redmine Resources (redmine_resources) plugin,
# resource allocation and management for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_resources is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_resources is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_resources.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class ResourceBookingsHelperTest < ActionView::TestCase
  include ResourceBookingsHelper

  fixtures :projects, :users

  def setup
    @project = Project.find(1)
    @admin = User.find(1)
    @query_private = ResourceBookingQuery.create!(name: 'Private Query', project: @project, user: @admin, visibility: ResourceQuery::VISIBILITY_PRIVATE)
    @query_public = ResourceBookingQuery.create!(name: 'Public Query', project: @project, user: @admin, visibility: ResourceQuery::VISIBILITY_PUBLIC)
    @issues_query_private = ResourceIssuesQuery.create!(name: 'Private Issues Query', project: @project, user: @admin, visibility: ResourceQuery::VISIBILITY_PRIVATE)
    @issues_query_public = ResourceIssuesQuery.create!(name: 'Public Issues Query', project: @project, user: @admin, visibility: ResourceQuery::VISIBILITY_PUBLIC)
  end
  def test_render_sidebar_resource_queries
    @sidebar_queries = [@query_private, @query_public, @issues_query_private, @issues_query_public]

    rendered_output = render_sidebar_resource_queries

    assert_includes rendered_output, l(:label_my_queries)
    assert_includes rendered_output, l(:label_query_plural)
    assert_includes rendered_output, @query_private.name
    assert_includes rendered_output, @query_public.name
    assert_includes rendered_output, @issues_query_private.name
    assert_includes rendered_output, @issues_query_public.name
  end

  def test_resource_query_links_for_private_queries
    queries = [@query_private, @issues_query_private]
    title = l(:label_my_queries)

    rendered_output = resource_query_links(title, queries)

    assert_includes rendered_output, "<h3>#{title}</h3>"
    queries.each do |query|
      css_class = query == @query ? 'query selected' : 'query'
      controller = query.is_a?(ResourceIssuesQuery) ? 'resource_issues' : 'resource_bookings'
      expected_link = url_for(controller: controller, action: 'index', project_id: @project, query_id: query.id)
      assert_includes rendered_output, expected_link
      assert_includes rendered_output, query.name
    end
  end

  def test_resource_query_links_for_public_queries
    queries = [@query_public, @issues_query_public]
    title = l(:label_query_plural)

    rendered_output = resource_query_links(title, queries)

    assert_includes rendered_output, "<h3>#{title}</h3>"
    queries.each do |query|
      css_class = query == @query ? 'query selected' : 'query'
      controller = query.is_a?(ResourceIssuesQuery) ? 'resource_issues' : 'resource_bookings'
      expected_link = url_for(controller: controller, action: 'index', project_id: @project, query_id: query.id)
      assert_includes rendered_output, expected_link
      assert_includes rendered_output, query.name
    end
  end
end
