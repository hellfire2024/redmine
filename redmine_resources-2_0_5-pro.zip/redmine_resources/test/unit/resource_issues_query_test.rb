# encoding: utf-8
#
# This file is a part of Redmine Resources (redmine_resources) plugin,
# resource allocation and management for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_resources is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_resources is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_resources.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class ResourceIssuesQueryTest < ActiveSupport::TestCase
  fixtures :projects, :users, :user_preferences, :roles, :members, :member_roles,
           :issues, :issue_statuses, :issue_relations, :versions, :trackers, :projects_trackers,
           :issue_categories, :enabled_modules, :enumerations, :workflows, :email_addresses

  create_fixtures(Redmine::Plugin.find(:redmine_people).directory + '/test/fixtures/', [:departments]) if RedmineResources.people_pro_plugin_installed?

  def setup
    @admin = User.find(1)
    @user = User.find(2)
    @project = Project.find(1)
    @query = ResourceIssuesQuery.new
    @from_date = '2023-01-01'.to_date
    @to_date = '2023-12-31'.to_date
  end

  def test_base_scope_includes_project_and_user
    scope = @query.base_scope(@from_date, @to_date)

    assert_includes scope.includes_values, :project, 'Projects should be included in base scope'
    assert_includes scope.includes_values, :assigned_to, 'Users (assigned_to) should be included in base scope'
  end

  def test_resource_issues_between_dates
    results = @query.resource_issues_between(@from_date, @to_date)

    results.each do |issue|
      assert issue.start_date && issue.start_date >= @from_date && issue.start_date <= @to_date ||
             issue.due_date && issue.due_date >= @from_date && issue.due_date <= @to_date,
             "Issue dates should be within the specified range"
    end
  end

  def test_resource_issues_by_users_with_assigned_to_filter
    @query.add_filter('assigned_to_id', '=', [@user.id.to_s])
    results = @query.resource_issues_by_users(@from_date, @to_date)

    results.each do |issue|
      assert_equal @user, issue.assigned_to, 'Returned issues should be assigned to the specified user'
    end
  end

  def test_chart_resource_issues
    results = @query.chart_resource_issues(@from_date, @to_date)

    results.each do |issue|
      assert issue.start_date && issue.start_date >= @from_date && issue.start_date <= @to_date ||
             issue.due_date && issue.due_date >= @from_date && issue.due_date <= @to_date,
             "Issue dates should be within the specified range for chart resource issues"
    end
  end

  def test_date_from_and_date_to
    @query.date_from = @from_date
    @query.date_to = 12

    assert_equal @from_date, @query.date_from
    assert_equal (@from_date >> 12 - 1).end_of_month, @query.date_to, "Date to should be 12 months after date from"
  end

  def test_build_from_params
    params = {
      date_from: @from_date.to_s,
      months: '12',
      line_title_type: 'issue_subject'
    }

    query = ResourceIssuesQuery.new
    query.build_from_params(params)

    assert_equal @from_date, query.date_from
    assert_equal (@from_date >> 12 - 1).end_of_month, query.date_to
    assert_equal 'issue_subject', query.line_title_type
  end

  def test_resource_issues_by_issue_id
    issue = Issue.find(1)
    @query.add_filter('issue_id', '=', [issue.id.to_s])
    results = @query.resource_issues_between(@from_date, @to_date)

    results.each do |result|
      assert_equal issue, result, 'Returned issue should match the specified issue_id'
    end
  end
end
