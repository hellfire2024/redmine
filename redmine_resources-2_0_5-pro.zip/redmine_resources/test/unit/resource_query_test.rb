# encoding: utf-8
#
# This file is a part of Redmine Resources (redmine_resources) plugin,
# resource allocation and management for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_resources is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_resources is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_resources.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class ResourceQueryTest < ActiveSupport::TestCase

  fixtures :projects, :users, :user_preferences, :roles, :members, :member_roles,
           :issues, :issue_statuses, :issue_relations, :versions, :trackers, :projects_trackers,
           :issue_categories, :enabled_modules, :enumerations, :workflows, :email_addresses

  create_fixtures(Redmine::Plugin.find(:redmine_resources).directory + '/test/fixtures/', [:resource_bookings])
  create_fixtures(Redmine::Plugin.find(:redmine_people).directory + '/test/fixtures/', [:departments]) if RedmineResources.people_pro_plugin_installed?

  def setup
    @admin = User.find(1)
    @user = User.find(2)
    @second_user = User.find(3)
    @project = Project.find(1)
    @second_project = Project.find(2)

    EnabledModule.create(project: @project, name: 'resources')
    EnabledModule.create(project: @second_project, name: 'resources')

    # Allow view resources for developers (user 3 in project 1 & user 2 in project 2)
    Role.where(id: [2]).each do |r|
      r.permissions << :view_resources
      r.save
    end
  end

  def test_initial_filters
    query = ResourceQuery.new

    assert_includes query.available_filters.keys, 'assigned_to_id'
    assert_includes query.available_filters.keys, 'project_id'
    assert_includes query.available_filters.keys, 'issue_id'
    if RedmineResources.people_pro_plugin_installed?
      assert_includes query.available_filters.keys, 'person.manager_id'
      assert_includes query.available_filters.keys, 'person.people_tags'
      assert_includes query.available_filters.keys, 'person.job_title'
      assert_includes query.available_filters.keys, 'person.workday_length'
      assert_includes query.available_filters.keys, 'person.department_id'
    end
  end

  def test_initial_filters_in_project
    query = ResourceQuery.new(project: @project)

    assert_includes query.available_filters.keys, 'assigned_to_id'
    assert_includes query.available_filters.keys, 'issue_id'
    assert_not_includes query.available_filters.keys, 'project_id'
  end

  def test_filter_values_for_assigned_to
    query = ResourceQuery.new(project: @project)
    assigned_to_filter = query.available_filters['assigned_to_id']
    values = assigned_to_filter[:values]

    if User.current.logged?
      assert values.any? { |v| v == ['<< me >>', 'me'] || v == ['<< Me >>', 'me'] }
    end

    user_names = values.map { |v| v.first }
    assert_equal user_names.sort, user_names.sort
  end
  def test_sql_for_person_people_tags_field
    query = ResourceQuery.new

    result = query.sql_for_person_people_tags_field('person.people_tags', '=', ['tag1', 'tag2'])
    expected_sql = "( #{Person.table_name}.id IN (#{Person.all.tagged_with(['tag1', 'tag2']).pluck(:id).push(0).join(',')}) )"
    assert_equal result, expected_sql
  end if RedmineResources.people_pro_plugin_installed?

  def test_group_by_project
    query = ResourceQuery.new(group_by: 'project')
    assert query.group_by_project?
    assert_not query.group_by_user?
  end

  def test_group_by_user
    query = ResourceQuery.new(group_by: 'user')
    assert query.group_by_user?
    assert_not query.group_by_project?
  end
end
