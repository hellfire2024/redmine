# Wiki Extensions plugin for Redmine
# Copyright (C) 2009-2010  Haruyuki Iida
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

require File.dirname(__FILE__) + '/../test_helper'
require "wiki_extensions_emoticons"

class EmoticonsTest < ActiveSupport::TestCase
  fixtures :wiki_extensions_comments

  context "emoticons" do
    setup do
      @emoticons = WikiExtensionsEmoticons::Emoticons.new
    end

    should "not returns nil." do
      assert_not_nil(@emoticons.emoticons)
    end
  end
end
