# This file is a part of Redmine ZenEdit (redmine_zenedit) plugin,
# editing enhancement plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_zenedit is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_zenedit is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_zenedit.  If not, see <http://www.gnu.org/licenses/>.

class ZenDraftController < ApplicationController
  include RedmineZenedit::Helpers::ZeneditHelper
  before_action :build_subject_from_params, except: [:other_drafts]
  before_action :restore_subject, only: :create
  skip_before_action :check_if_login_required, only: [:other_drafts]
  def show
    @subject = draft.try(:restore)
    result = @subject.attributes
    result.merge!(notes: @subject.notes, draft_checklists: @subject.draft_checklists) if @subject_name == 'issue'
    result.merge!(content_text: @subject.new_content_text) if @subject_name == 'wiki_page'
    render json: result
  end

  def create
    return unless @subject.save_draft

    head :ok
  end

  def destroy
    return unless draft.destroy
    render json: { status: 200 }, status: 200
  end

  def other_drafts
    return head :not_found unless RedmineZenedit.draft_enabled?

    @issue =  Issue.where(id: params[:id], project_id: params[:project_id]).first
    @issue ||= Issue.new(project_id: params[:project_id])
    return head :not_found unless @issue

    @other_drafts = @issue.other_drafts(User.find_by(id: params[:user_id]))
    respond_to do |format|
      format.api
      format.any { head :ok }
    end
  end

  private

  def build_subject_from_params
    @subject_name = unsafe_params['issue'].present? ? 'issue' : 'wiki_page'
    @subject = @subject_name.classify.constantize.new
    @subject.id = unsafe_params[@subject_name]['id']
    @subject.safe_attributes = (unsafe_params[@subject_name] || {}).deep_dup
    @subject.project_id = unsafe_params[@subject_name]['project_id'] if @subject_name == 'issue'
    @subject.wiki_id = unsafe_params[@subject_name]['wiki_id'] if @subject_name == 'wiki_page'
  end

  def unsafe_params
    if params.respond_to?(:to_unsafe_h)
      params.to_unsafe_h
    else
      params
    end
  end

  def draft
    @draft ||= @subject.last_draft
  end

  def restore_subject
    @subject = from_draft if draft

    if @subject_name == 'issue'
      if params['issue']['notes']
        @subject.init_journal(User.current)
        @subject.notes = params['issue']['notes']
      else
        @subject.notes = nil
      end
      @subject.draft_checklists = checklists_attributes_to_draft(params['issue']['checklists_attributes']) if RedmineZenedit.use_checklist? &&
                                                                                                              params['issue']['checklists_attributes']
    else
      @subject.new_content_text = params[@subject_name]['text']
    end
    @subject
  end

  def from_draft
    draft.restore.tap do |from_draft|
      safe_assignment(from_draft)
      from_draft.id = @subject.id
    end
  end

  def safe_assignment(draft_subject)
    assignment_params = (unsafe_params[@subject_name] || {})
    assignment_params.each do |key, value|
      begin
        draft_subject.send("#{key}=", value)
      rescue
        next
      end
    end
  end
end
