# encoding: utf-8
#
# This file is a part of Redmine ZenEdit (redmine_zenedit) plugin,
# editing enhancement plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_zenedit is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_zenedit is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_zenedit.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class IssuesControllerTest < ActionController::TestCase
  fixtures :projects,
           :users,
           :roles,
           :members,
           :member_roles,
           :issues,
           :issue_statuses,
           :versions,
           :trackers,
           :projects_trackers,
           :issue_categories,
           :enabled_modules,
           :enumerations,
           :attachments,
           :workflows,
           :custom_fields,
           :custom_values,
           :custom_fields_projects,
           :custom_fields_trackers,
           :time_entries,
           :journals,
           :journal_details,
           :queries,
           :email_addresses

  def setup
    user = User.find(1)
    user.pref.update(no_self_notified: false)
    user.pref.update(auto_watch_on: []) if Redmine::VERSION.to_s >= '5.0'
    User.current = user

    @request.session[:user_id] = 1
  end

  def create_draft
    Issue.new(subject: 'draft for new issue', project: Project.first).save_draft
  end

  #<LIGHT>
  def test_no_drafts_are_shown
    # Skip this in pro mode
    return
    create_draft
    compatible_request :get, :new
    assert_select('#zen-draft', false)
  end
  #</LIGHT>
  def test_draft_is_shown_on_new
    create_draft
    compatible_request :get, :new, project_id: Project.find(1)
    assert_select('#zen-draft')
  end

  def test_draft_is_not_shown_on_xhr
    create_draft
    compatible_xhr_request :post, :new, project_id: Project.find(1)
    assert_no_match(/<div id=\\\"zen-draft\\\">/, response.body)
  end

  def test_draft_form_corresponding_project_is_shown_on_new
    create_draft
    compatible_request :get, :new, project_id: 1
    assert_select('#zen-draft')
  end

  def test_draft_from_other_project_is_not_shown_on_new
    Issue.new(subject: 'draft for new issue', project: Project.find(2)).save_draft
    compatible_request :get, :new, project_id: 1
    assert_select('#zen-draft', false)
  end

  def test_no_draft_on_new_if_draft_refers_to_other_issue
    issue = Issue.find(2)
    issue.subject = 'draft for issue 2'
    issue.save_draft

    compatible_request :get, :new
    assert_select('#zen-draft', false)
  end

  def test_no_draft_on_new_if_there_are_none
    compatible_request :get, :new
    assert_select('#zen-draft', false)
  end

  def test_draft_is_shown_on_edit
    issue = Issue.find(1)
    issue.subject = 'draft for issue 1'
    issue.save_draft

    compatible_request :get, :edit, id: 1
    assert_select('#zen-draft')
  end

  def test_no_draft_on_edit_if_draft_refers_to_other_issue
    issue = Issue.find(1)
    issue.subject = 'draft for issue 1'
    issue.save_draft

    compatible_request :get, :edit, id: 2
    assert_select('#zen-draft', false)
  end

  def test_draft_is_shown_on_show
    issue = Issue.find(1)
    issue.subject = 'draft for issue 1'
    issue.save_draft

    compatible_request :get, :show, id: 1
    assert_select('#zen-draft')
  end

  def test_no_draft_on_show_if_draft_refers_to_other_issue
    Issue.new(subject: 'draft for new issue').save_draft
    compatible_request :get, :show, id: 1
    assert_select('#zen-draft', false)
  end

  def test_draft_is_removed_on_create
    project = Project.find(1)
    issue = Issue.new(subject: 'hello', project: project)
    issue.save_draft

    assert_difference 'Redmineup::ActsAsDraftable::Draft.count', -1 do
      compatible_request :post, :create, issue: issue.attributes
    end
  end

  def test_draft_is_removed_on_update
    issue = Issue.find(2)
    issue.subject = 'changed subject'
    issue.save_draft

    assert_difference 'Redmineup::ActsAsDraftable::Draft.count', -1 do
      compatible_request :put, :update, id: 2, issue: { subject: issue.subject }
    end
  end

  def test_draft_not_show_if_issue_has_save_conflict
    original_issue = Issue.find(1)
    updated_issue = Issue.find(1)

    updated_issue.subject = 'draft for Updated issue'
    compatible_request :put, :update, id: 1, issue: { subject: updated_issue.subject, lock_version: '1' }.merge(last_journal_id: '1')

    original_issue.subject = 'draft for Original issue'
    original_issue.save_draft

    compatible_request :put, :update, id: 1, issue: { subject: original_issue.subject, lock_version: '1' }.merge(last_journal_id: '1')

    assert_match /The issue has been updated by an other user while you were editing it/, response.body
    assert_select "div#zen-draft", false
  end

  def test_post_create_with_mentions
    User.find(1).pref.update(no_self_notified: false)
    check_mentions_on :create, ['admin@somenet.foo'], description: 'This is the description'
    check_mentions_on :create, %w(admin@somenet.foo jsmith@somenet.foo), description: '@jsmith hello!'
    check_mentions_on :create, %w(admin@somenet.foo jsmith@somenet.foo), description: '@jsmith, hello!'
    check_mentions_on :create, %w(admin@somenet.foo jsmith@somenet.foo), description: 'Hello @jsmith!'
    check_mentions_on :create, %w(admin@somenet.foo jsmith@somenet.foo), description: 'Hi @jsmith please fix this bug.'
    check_mentions_on :create, %w(admin@somenet.foo jsmith@somenet.foo), description: 'Hi @jsmith, please fix this bug.'
    check_mentions_on :create, %w(admin@somenet.foo jsmith@somenet.foo rhill@somenet.foo), description: '@jsmith @rhill hello!'
    check_mentions_on :create, %w(admin@somenet.foo jsmith@somenet.foo rhill@somenet.foo), description: '@jsmith, @rhill, hello!'

    # Special cases
    check_mentions_on :create, ['admin@somenet.foo'], description: 'Hi, @gmail' # Not exist a user with login gmail
    check_mentions_on :create, ['admin@somenet.foo'], description: 'Emails: jsmith@gmail.com and email@jsmith.com'
    check_mentions_on :create, %w(admin@somenet.foo jsmith@somenet.foo), description: 'Hi @jsmith, you can use email example@rhill.com'
    check_mentions_on :create, defined?(Redmine::Acts::Mentionable) ? %w(admin@somenet.foo jsmith@somenet.foo) : ['admin@somenet.foo'], description: '@jsmith@rhill hi @jsmith@rhill jsmith@rhill @@jsmith@ @ hi @, @@'
    check_mentions_on :create, defined?(Redmine::Acts::Mentionable) ? %w(admin@somenet.foo jsmith@somenet.foo) : ['admin@somenet.foo'], description: '@jsmith@gmail.com and @jsmith-@rhill_@gmail.com'

    # The mentioned user will not receive a notification, because he can not view private issues
    check_mentions_on :create, ['admin@somenet.foo'], is_private: true, description: '@jsmith, hello!'
  end if Redmine::VERSION.to_s < '5.0'

  def test_post_update_with_mentions
    User.find(1).pref.update(no_self_notified: true)
    check_mentions_on :update, ['jsmith@somenet.foo'], description: 'This is the description', notes: 'This is the note'
    check_mentions_on :update, %w(jsmith@somenet.foo rhill@somenet.foo), description: '@rhill hello!'
    check_mentions_on :update, defined?(Redmine::Acts::Mentionable) ? %w(jsmith@somenet.foo) : %w(jsmith@somenet.foo rhill@somenet.foo), description: '@rhill, hello!'
    check_mentions_on :update, %w(jsmith@somenet.foo rhill@somenet.foo), notes: '@rhill hello!'
    check_mentions_on :update, %w(jsmith@somenet.foo rhill@somenet.foo), notes: '@rhill, hello!'
    check_mentions_on :update, %w(jsmith@somenet.foo rhill@somenet.foo dlopper@somenet.foo), description: 'Hi @dlopper!', notes: 'Hi @rhill, please fix this bug.'
    check_mentions_on :update, %w(jsmith@somenet.foo rhill@somenet.foo dlopper@somenet.foo), notes: '@rhill @dlopper hello!'
    check_mentions_on :update, %w(jsmith@somenet.foo rhill@somenet.foo dlopper@somenet.foo), notes: '@rhill, @dlopper, hello!'
    check_mentions_on :update, %w(jsmith@somenet.foo), notes: 'Hi @admin, I found bug.'

    # Special cases
    check_mentions_on :update, ['jsmith@somenet.foo'], notes: 'Hi, @gmail' # Not exist a user with login gmail
    check_mentions_on :update, ['jsmith@somenet.foo'], description: 'Emails: jsmith@gmail.com and email@jsmith.com'
    check_mentions_on :update, ['jsmith@somenet.foo'], description: 'Hi @admin, you can use email example@rhill.com'
    check_mentions_on :update, ['jsmith@somenet.foo'], description: '@jsmith@rhill hi @jsmith@rhill jsmith@rhill @@jsmith@ @ hi @, @@'
    check_mentions_on :update, ['jsmith@somenet.foo'], description: '@jsmith@gmail.com and @jsmith-@rhill_@gmail.com'

    # The mentioned user will not receive a notification, because he can not view private issues
    check_mentions_on :update, defined?(Redmine::Acts::Mentionable) ? %w(jsmith@somenet.foo rhill@somenet.foo) : ['jsmith@somenet.foo'], is_private: true, notes: '@rhill, hello!'
  end if Redmine::VERSION.to_s < '5.0'

  # Issue view indicator should be hidden if assigned user hasn't yet viewed issue
  # but the view is committed
  def test_issue_view_indicator_should_be_hide
    issue2 = Issue.find(2)
    with_settings plugin_redmine_zenedit: { 'view_indicator' => '0' } do
      set_issue_as_viewed issue2
      assert issue2.reload.viewed?
      assert_no_match /viewed/, response.body
    end
  end

  def test_issue_view_indicator_should_be_show
    issue2 = Issue.find(2)
    with_settings plugin_redmine_zenedit: { 'view_indicator' => '1' } do
      set_issue_as_viewed issue2.reload
      assert issue2.reload.viewed?
      assert_match /viewed/, response.body
    end
  end

  def test_issue_viewed_filter_by_viewed
    user3 = User.find(3)
    issue2 = Issue.find(2)
    params = params_for_filter('=', user3.id)

    with_settings plugin_redmine_zenedit: { 'view_indicator' => '1' } do
      issue2.view request.remote_addr, user3
      assert issue2.reload.viewed?

      compatible_request :get, :index, params
      assert_response :success

      assert_select "#issue-2"
      assert_select "#issue-1", false
    end
  end

  private

  def check_mentions_on(action, notified_emails, issue_options)
    ActionMailer::Base.deliveries.clear

    if action == :update
      compatible_request :put, :update, id: 5, issue: issue_options
      assert_redirected_to controller: 'issues', action: 'show', id: 5
    else
      issue_options[:subject] = 'This is a new issue with mentions'
      compatible_request :post, :create, project_id: 3, issue: issue_options

      issue = Issue.where(subject: issue_options[:subject]).order(:id).last
      assert_not_nil issue
      assert_redirected_to controller: 'issues', action: 'show', id: issue
    end

    expected_emails_number = notified_emails.size

    assert_equal expected_emails_number, ActionMailer::Base.deliveries.size, 'An email should have been sent'

    ActionMailer::Base.deliveries.each do |mail|
      assert_not_nil mail
      emails = [mail.to, mail.bcc, mail.cc].flatten.compact
      assert_equal 1, emails.size
    end
  end

  def params_for_filter(operator, user_id)
    {
        "set_filter"=>"1",
        "project_id"=>"1",
        "f"=>["status_id", "viewed_by_id", ""],
        "op"=>{"status_id"=>"*", "viewed_by_id"=>"#{operator}"},
        "v"=>{"viewed_by_id"=>["#{user_id}"]}
    }
  end

  def set_issue_as_viewed(issue, viewed = true)
    @request.session[:user_id] = User.find(3).id
    compatible_request :get, :show, id: issue.id
    assert_response :success
    assert_equal issue.viewed?, viewed
  end
end
